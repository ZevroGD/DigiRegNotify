package personal.digiregnotify

import android.content.Context
import org.json.JSONObject
import java.util.Calendar

/**
 * Notices edited and deleted homework by comparing each check with the previous one, and
 * records it in [ItemHistory] so the Homework screen can show it on the item itself.
 * (It no longer writes to the separate change log.)
 */
object ChangeDetector {

    private const val PREFS = "digireg_change_snapshot"
    private const val KEY = "snapshot2" // new format; the old "snapshot" is simply ignored

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(item: DashboardItem) = "${item.type}:${item.id}"

    private class Snap(val title: String, val subtitle: String, val deadline: String, val label: String)

    /** Developer menu: forget the stored snapshot; the next check just records a new baseline. */
    fun resetBaseline(context: Context) {
        prefs(context).edit().remove(KEY).apply()
    }

    fun trackChanges(context: Context, items: List<DashboardItem>) {
        val current = items.filter { it.type == "gradeGroup" }.associateBy { key(it) }

        val raw = prefs(context).getString(KEY, null)
        val previous: Map<String, Snap> = if (raw != null) {
            try {
                val obj = JSONObject(raw)
                obj.keys().asSequence().associateWith { k ->
                    val o = obj.getJSONObject(k)
                    Snap(o.optString("title"), o.optString("subtitle"), o.optString("deadline"), o.optString("label"))
                }
            } catch (e: Exception) {
                emptyMap()
            }
        } else {
            emptyMap()
        }

        // An empty feed after a non-empty one is almost certainly a stale-session artifact,
        // not a teacher deleting everything: change nothing, keep the old snapshot.
        if (current.isEmpty() && previous.isNotEmpty()) return

        val snapshot = JSONObject()
        for ((k, item) in current) {
            snapshot.put(k, JSONObject().put("title", item.title).put("subtitle", item.subtitle)
                .put("deadline", item.deadline ?: "").put("label", item.label))
        }
        prefs(context).edit().putString(KEY, snapshot.toString()).apply()

        ItemHistory.importOldChangeLog(context, current)

        if (raw == null) return // first run only records a baseline

        val now = System.currentTimeMillis()
        val todayStart = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val furthestDue = current.values.mapNotNull { DueDateFormat.parse(it.deadline)?.time }.maxOrNull()

        // Edited: the text or due date changed (ticking the box doesn't count).
        for ((k, item) in current) {
            val old = previous[k] ?: continue
            if (old.title != item.title || old.subtitle != item.subtitle || old.deadline != (item.deadline ?: "")) {
                DevLog.i("Changes", "edited: $k")
                ItemHistory.addVersion(context, k, ItemVersion(now, old.title, old.subtitle, old.deadline))
            }
        }

        // Deleted: gone from the feed although it was still due and within the date range the
        // feed currently covers. An item whose day has passed, or that lies beyond the feed's
        // window, just dropped out of view — that isn't a deletion.
        for ((k, old) in previous) {
            if (k in current) continue
            val due = DueDateFormat.parse(old.deadline)?.time ?: continue
            if (due >= todayStart && furthestDue != null && due <= furthestDue) {
                DevLog.i("Changes", "deleted: $k")
                ItemHistory.addDeleted(
                    context, DeletedHomework(k, old.label, old.title, old.subtitle, old.deadline, now)
                )
            }
        }

        ItemHistory.prune(context, todayStart)
    }
}
