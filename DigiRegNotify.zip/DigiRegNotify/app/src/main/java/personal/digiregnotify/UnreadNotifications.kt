package personal.digiregnotify

import org.json.JSONArray

/**
 * One entry of POST /api/notification/unread — the same request the real site's home
 * screen makes to show unread messages and new marks (the dashboard itself only carries
 * homework). Example titles: "Neue Mitteilung · <subject>", "Neue Bewertung · M · <test> · 8".
 */
data class UnreadNotification(
    val notificationId: String,
    val type: String,      // "message" or "grade" (others are ignored by callers)
    val objectId: Long,    // message id for messages
    val title: String,
    val subTitle: String,  // for messages: "<weekday, date> · <sender>"
    val timeSent: String
) {
    /** Message subject: the part of the title after "Neue Mitteilung · ". */
    val messageSubject: String get() = title.substringAfter(" · ", title).trim()

    /** Message sender: the part of the subtitle after the date. */
    val messageSender: String get() = subTitle.substringAfterLast(" · ", "").trim()

    /** Grade text without the "Neue Bewertung · " prefix, e.g. "M · 1.Schularbeit · 8". */
    val gradeText: String get() = title.substringAfter(" · ", title).trim()

    /** A new mark or observation (what the unread list calls a grade or an observation). */
    val isMark: Boolean get() = type == "grade" || type == "observation" || type == "criticalObservation"

    companion object {
        private val MARK_SHAPE = Regex("^\\d{1,2}([.,]\\d+)?[+\\-]?$|^\\d{1,2}/\\d{1,2}$")

        /**
         * Splits "M · 1.Schularbeit · 8" into the mark ("8") and the rest. The mark is empty when
         * the text doesn't end in something that looks like one (an observation's text doesn't).
         */
        fun splitMark(text: String): Pair<String, String> {
            val last = if (text.contains(" · ")) text.substringAfterLast(" · ").trim() else ""
            return if (MARK_SHAPE.matches(last)) last to text.substringBeforeLast(" · ").trim() else "" to text
        }

        fun parse(json: String): List<UnreadNotification> {
            val array = JSONArray(json)
            val result = mutableListOf<UnreadNotification>()
            for (i in 0 until array.length()) {
                val n = array.optJSONObject(i) ?: continue
                result.add(
                    UnreadNotification(
                        notificationId = n.optString("id"),
                        type = n.optString("type"),
                        objectId = n.optLong("objectId"),
                        title = n.optString("title"),
                        subTitle = n.optString("subTitle"),
                        timeSent = n.optString("timeSent")
                    )
                )
            }
            return result
        }
    }
}
