## What's new

**New**
- **Updates from inside the app.** With *Check automatically* on (Settings → Updates), the app looks for a new release about twice a day and sends a notification. Tapping it, or just opening the app, shows a popup with the version, the release notes and a Download button. When the download finishes it opens the installer chosen under Developer menu → Update installer, or the system installer if none is chosen. *Check for update* does the same on demand. It needs a read-only GitHub token (see the README), stored encrypted on the phone.

**Changed**
- A quieter, more minimal interface: the explanatory sentences under settings, on the sign-in screen, in the subject list and above the charts are gone, and the sign-in button is simply "Sign in".
- The search, messages and menu buttons at the top of Home now have the same colour and size (the search icon used to look darker and the envelope brighter).
- The search field has an X button that clears it, puts the cursor back in the field and brings up the keyboard. Opening the search also brings up the keyboard straight away.
- Settings moved from the menu grid to a gear in the menu's top right corner, so the four menu tiles form an even grid.
- Cards now have an outline in your palette's colour (a soft version of the primary colour) instead of a fixed grey-beige one, so the theme shows on every card, including with the Custom theme.
- The colour wheel's triangle now points up (white at the top, black at the bottom left, the pure colour at the bottom right) and stays that way while you change the hue.
- The Custom theme now has 1,728 prepared colours instead of 204, so the colour you get is much closer to the one you picked. Before, muted colours such as greyish blues could turn into plain grey or a much brighter blue.
