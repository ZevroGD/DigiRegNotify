package personal.digiregnotify

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

class MarksActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var chart: MultiLineChartView
    private lateinit var dropdownAdapter: SubjectDropdownAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView
    private lateinit var dropdownRecycler: RecyclerView
    private lateinit var chevron: TextView

    private var subjects: List<SubjectSummary> = emptyList()
    private val thicknessBySubject = mutableMapOf<Int, Int>() // default 3, 1..5
    private var dropdownExpanded = false

    private val isoDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_marks)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.marksEmptyText)
        swipeRefresh = findViewById(R.id.marksSwipeRefresh)
        chart = findViewById(R.id.combinedChart)
        chevron = findViewById(R.id.subjectsDropdownChevron)

        dropdownRecycler = findViewById(R.id.marksRecyclerView)
        dropdownAdapter = SubjectDropdownAdapter(emptyList()) { subjectId, newThickness ->
            thicknessBySubject[subjectId] = newThickness
            renderChart()
            renderDropdown()
        }
        dropdownRecycler.layoutManager = LinearLayoutManager(this)
        dropdownRecycler.adapter = dropdownAdapter

        findViewById<ImageButton>(R.id.marksBackButton).setOnClickListener { finish() }
        findViewById<android.widget.LinearLayout>(R.id.subjectsDropdownHeader).setOnClickListener {
            dropdownExpanded = !dropdownExpanded
            dropdownRecycler.visibility = if (dropdownExpanded) RecyclerView.VISIBLE else RecyclerView.GONE
            chevron.text = if (dropdownExpanded) "▴" else "▾"
        }
        swipeRefresh.setOnRefreshListener { loadMarks() }
        loadMarks()
    }

    private fun loadMarks() {
        if (!api.hasCredentials()) {
            emptyText.text = "Sign in from the main screen first"
            emptyText.visibility = TextView.VISIBLE
            swipeRefresh.isRefreshing = false
            return
        }
        if (!NetworkUtil.isConnected(this)) {
            swipeRefresh.isRefreshing = false
            emptyText.text = "No internet connection right now"
            emptyText.visibility = TextView.VISIBLE
            return
        }

        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            val (firstJson, secondJson) = api.fetchAllSubjectsBothSemesters()
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (firstJson == null) {
                    emptyText.text = ErrorText.friendly(api.lastError, "load marks")
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@MarksActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    return@withContext
                }

                val merged = try {
                    val first = AllSubjectsParser.parse(firstJson)
                    if (secondJson != null) {
                        AllSubjectsParser.merge(first, AllSubjectsParser.parse(secondJson))
                    } else {
                        // Semester switch failed — still show what we have, but say so.
                        Toast.makeText(
                            this@MarksActivity,
                            "Could only load one semester (the other failed to switch)",
                            Toast.LENGTH_LONG
                        ).show()
                        first
                    }
                } catch (e: Exception) {
                    emptyText.text = "Could not read the marks data"
                    emptyText.visibility = TextView.VISIBLE
                    return@withContext
                }

                subjects = merged.filter { it.grades.isNotEmpty() }.sortedBy { it.name }
                for (s in subjects) thicknessBySubject.putIfAbsent(s.subjectId, 3)

                renderChart()
                renderDropdown()

                emptyText.visibility = if (subjects.isEmpty()) TextView.VISIBLE else TextView.GONE
                emptyText.text = "No grades found yet"
            }
        }
    }

    private fun renderChart() {
        val series = subjects.map { s ->
            ChartSeries(
                subjectId = s.subjectId,
                points = s.grades.mapNotNull { g ->
                    val date = try {
                        isoDate.parse(g.date)?.time
                    } catch (e: Exception) {
                        null
                    }
                    date?.let { it to g.value }
                },
                color = SubjectColors.colorFor(this, s.subjectId),
                strokeWidthDp = (thicknessBySubject[s.subjectId] ?: 3).toFloat()
            )
        }
        chart.setSeries(series)
    }

    private fun renderDropdown() {
        val rows = subjects.map { s ->
            SubjectRowState(
                subjectId = s.subjectId,
                name = s.name,
                average = s.averageYear ?: s.averageSemester,
                color = SubjectColors.colorFor(this, s.subjectId),
                thickness = thicknessBySubject[s.subjectId] ?: 3
            )
        }
        dropdownAdapter.updateRows(rows)
    }
}
