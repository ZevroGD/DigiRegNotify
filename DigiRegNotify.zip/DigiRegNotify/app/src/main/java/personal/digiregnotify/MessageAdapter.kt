package personal.digiregnotify

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class MessageAdapter(private var messages: List<MessageSummary>) :
    RecyclerView.Adapter<MessageAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val unreadDot: View = view.findViewById(R.id.messageUnreadDot)
        val from: TextView = view.findViewById(R.id.messageFrom)
        val subject: TextView = view.findViewById(R.id.messageSubject)
        val preview: TextView = view.findViewById(R.id.messagePreview)
    }

    fun updateMessages(newMessages: List<MessageSummary>) {
        messages = newMessages
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val m = messages[position]
        holder.from.text = m.fromName.ifBlank { "Unknown sender" }
        holder.subject.text = m.subject.ifBlank { "(no subject)" }
        holder.preview.text = m.bodyPreview

        val color = ContextCompat.getColor(
            holder.itemView.context,
            if (m.isUnread) R.color.forest else R.color.hairline
        )
        (holder.unreadDot.background.mutate() as GradientDrawable).setColor(color)
    }

    override fun getItemCount(): Int = messages.size
}
