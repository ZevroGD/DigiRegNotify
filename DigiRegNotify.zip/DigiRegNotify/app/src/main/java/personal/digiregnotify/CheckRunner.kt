package personal.digiregnotify

import android.content.Context
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

sealed class CheckResult {
    data class Success(
        val totalItems: Int,
        val newItems: Int,
        val newMessages: Int = 0,
        val timetableChanged: Boolean = false,
        /** Everything parsed from the dashboard, so callers (e.g. the Homework screen) can
         *  show what the check just fetched instead of making a second request. */
        val items: List<DashboardItem> = emptyList()
    ) : CheckResult()

    object NoConnection : CheckResult()
    data class Failure(val message: String) : CheckResult()
}

object CheckRunner {

    private const val TAG = "DigiReg"

    /**
     * One full check: dashboard (new grades / homework / teacher notes), unread messages,
     * and timetable changes. Used by both the scheduled alarm and the manual button, so
     * "run a check" always means exactly the same thing.
     */
    fun performCheck(
        context: Context,
        source: CheckStatus.Source = CheckStatus.Source.REFRESH
    ): CheckResult {
        val result = try {
            runCheck(context)
        } catch (e: Exception) {
            CheckResult.Failure(e.message ?: "Unknown error")
        }
        CheckStatus.record(context, source, result)
        return result
    }

    private fun runCheck(context: Context): CheckResult {
        val api = RegisterApi(context)
        if (!api.hasCredentials()) return CheckResult.Failure("Not signed in")

        if (!NetworkUtil.isConnected(context)) {
            return CheckResult.NoConnection
        }

        val dashboardJson = api.fetchDashboardWithAutoLogin()
            ?: return CheckResult.Failure(api.lastError ?: "Could not log in or fetch data")

        val differ = DashboardDiffer(context)
        val items = differ.parseItems(dashboardJson)
        val newItems = differ.findNewItems(items)

        // Isolated: a bug here should never break the main check above.
        try {
            ChangeDetector.trackChanges(context, items)
        } catch (e: Exception) {
            Log.w(TAG, "Change detection failed", e)
        }

        val filtered = newItems.filter { item ->
            when (item.type) {
                "grade" -> NotificationPrefs.isGradesEnabled(context)
                "gradeGroup", "observation" -> NotificationPrefs.isHomeworkEnabled(context)
                else -> true
            }
        }
        // Separate notifications per kind, so each has a single, unambiguous tap target
        // (Marks for grades, Home for homework/notes) instead of one that can't deep-link.
        val (newGrades, newHomework) = filtered.partition { it.type == "grade" }
        NotificationHelper.notifyNewGrades(context, newGrades)
        NotificationHelper.notifyNewHomework(context, newHomework)

        // The extras below must never break the main check above, so each is isolated.
        val newMessages = try {
            checkMessages(context, api)
        } catch (e: Exception) {
            Log.w(TAG, "Message check failed", e)
            0
        }
        val timetableChanged = try {
            checkTimetable(context, api)
        } catch (e: Exception) {
            Log.w(TAG, "Timetable check failed", e)
            false
        }

        return CheckResult.Success(items.size, filtered.size, newMessages, timetableChanged, items)
    }

    /**
     * Notifies about unread messages and new marks we haven't announced yet. Uses the single
     * unread-notification request the real site's home screen makes — it already carries
     * sender, subject and the mark itself, so no separate inbox download is needed.
     * Returns how many messages were announced.
     */
    private fun checkMessages(context: Context, api: RegisterApi): Int {
        val unreadJson = api.fetchUnreadNotifications() ?: return 0
        val all = UnreadNotification.parse(unreadJson)
        val messages = all.filter { it.type == "message" }.associateBy { it.notificationId }
        val grades = all.filter { it.type == "grade" }.associateBy { it.notificationId }

        // Always record what we've seen, even with a toggle off, so switching it on
        // later doesn't suddenly announce old items.
        val newMessageIds = ChangeTracker.newMessageNotificationIds(context, messages.keys)
        val newGradeIds = ChangeTracker.newGradeNotificationIds(context, grades.keys)

        if (newGradeIds.isNotEmpty() && NotificationPrefs.isGradesEnabled(context)) {
            NotificationHelper.notifyNewGradeTexts(context, newGradeIds.mapNotNull { grades[it]?.gradeText })
        }

        if (newMessageIds.isEmpty() || !NotificationPrefs.isMessagesEnabled(context)) return 0
        val toShow = newMessageIds.mapNotNull { messages[it] }
            .map { MessagePreview(it.objectId, it.messageSender, it.messageSubject) }
        NotificationHelper.notifyMessages(context, toShow)
        return toShow.size
    }

    /** Compares this and next week's timetable with the last check. Returns true if it notified. */
    private fun checkTimetable(context: Context, api: RegisterApi): Boolean {
        if (!NotificationPrefs.isCalendarEnabled(context)) {
            // So that switching it back on starts from a fresh baseline.
            ChangeTracker.clearTimetableSnapshot(context)
            return false
        }

        val format = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val monday = Calendar.getInstance()
        monday.add(Calendar.DAY_OF_YEAR, -((monday.get(Calendar.DAY_OF_WEEK) + 5) % 7))
        val thisWeek = format.format(monday.time)
        monday.add(Calendar.DAY_OF_YEAR, 7)
        val nextWeek = format.format(monday.time)

        // Need both weeks, otherwise a half snapshot would look like lessons vanishing.
        val first = api.fetchCalendarWeek(thisWeek) ?: return false
        val second = api.fetchCalendarWeek(nextWeek) ?: return false
        val a = TimetableParser.parseWeek(first)
        val b = TimetableParser.parseWeek(second)

        val summary = TimetableChanges.detect(
            context = context,
            lessons = a.lessons + b.lessons,
            fetchedDates = (a.dates + b.dates).toSet(),
            today = format.format(Calendar.getInstance().time)
        ) ?: return false

        NotificationHelper.notifyTimetableChanged(context, summary)
        return true
    }
}
