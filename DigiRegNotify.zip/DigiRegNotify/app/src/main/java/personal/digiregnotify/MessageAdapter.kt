package personal.digiregnotify

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class MessageAdapter(
    private var messages: List<MessageSummary>,
    private val onExpanded: (MessageSummary) -> Unit // called when an unread message is opened
) : RecyclerView.Adapter<MessageAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val unreadDot: View = view.findViewById(R.id.messageUnreadDot)
        val from: TextView = view.findViewById(R.id.messageFrom)
        val subject: TextView = view.findViewById(R.id.messageSubject)
        val preview: TextView = view.findViewById(R.id.messagePreview)
        val panel: LinearLayout = view.findViewById(R.id.messagePanel)
    }

    // Which messages are open, so they stay open when the list is refreshed.
    private val openIds = mutableSetOf<Long>()

    /** Opens a message from outside (the "new message" notification); shown when the list is next drawn. */
    fun openMessage(messageId: Long) {
        if (openIds.add(messageId)) {
            val position = messages.indexOfFirst { it.id == messageId }
            if (position >= 0) notifyItemChanged(position)
        }
    }

    fun updateMessages(newMessages: List<MessageSummary>) {
        messages = newMessages
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val m = messages[position]
        holder.from.text = m.fromName.ifBlank { "Unknown sender" }
        holder.subject.text = m.subject.ifBlank { "(no subject)" }
        holder.preview.text = m.bodyPreview

        val color = ContextCompat.getColor(
            holder.itemView.context,
            if (m.isUnread) R.color.forest else R.color.hairline
        )
        (holder.unreadDot.background.mutate() as GradientDrawable).setColor(color)

        Attachments.fillMessagePanel(holder.panel, m)
        holder.panel.visibility = if (m.id in openIds) View.VISIBLE else View.GONE
        holder.panel.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
        holder.panel.alpha = 1f

        holder.itemView.setOnClickListener {
            if (m.id in openIds) {
                openIds.remove(m.id)
                Expand.collapse(holder.panel)
            } else {
                openIds.add(m.id)
                Expand.expand(holder.panel)
                if (m.isUnread) onExpanded(m)
            }
        }
    }

    override fun getItemCount(): Int = messages.size
}
