package personal.digiregnotify

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeworkActivity : AppCompatActivity() {

    private lateinit var api: RegisterApi
    private lateinit var adapter: HomeworkAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homework)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.homeworkEmptyText)
        swipeRefresh = findViewById(R.id.swipeRefresh)

        val recyclerView = findViewById<RecyclerView>(R.id.homeworkRecyclerView)
        adapter = HomeworkAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        swipeRefresh.setOnRefreshListener { loadHomework() }
        loadHomework()
    }

    private fun loadHomework() {
        if (!api.hasCredentials()) {
            emptyText.text = "Sign in from the main screen first"
            emptyText.visibility = TextView.VISIBLE
            swipeRefresh.isRefreshing = false
            return
        }

        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            val dashboardJson = api.fetchDashboardWithAutoLogin()
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (dashboardJson == null) {
                    emptyText.text = "Could not load homework — check your connection or login"
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@HomeworkActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    return@withContext
                }
                val differ = DashboardDiffer(this@HomeworkActivity)
                val allItems = differ.parseItems(dashboardJson)
                val homework = allItems
                    .filter { it.type == "gradeGroup" }
                    .sortedBy { it.deadline ?: "9999" }

                adapter.updateItems(homework)
                emptyText.visibility = if (homework.isEmpty()) TextView.VISIBLE else TextView.GONE
                emptyText.text = "No homework found"
            }
        }
    }
}
