package personal.digiregnotify

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class MessageAdapter(
    private var messages: List<MessageSummary>,
    private val onExpanded: (MessageSummary) -> Unit // called when an unread message is opened
) : RecyclerView.Adapter<MessageAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val unreadDot: View = view.findViewById(R.id.messageUnreadDot)
        val from: TextView = view.findViewById(R.id.messageFrom)
        val subject: TextView = view.findViewById(R.id.messageSubject)
        val preview: TextView = view.findViewById(R.id.messagePreview)
        val panel: LinearLayout = view.findViewById(R.id.messagePanel)
    }

    // Which messages are open, so they stay open when the list is refreshed.
    private val openIds = mutableSetOf<Long>()

    /** Opens a message from outside (the "new message" notification); shown when the list is next drawn. */
    fun openMessage(messageId: Long) {
        if (openIds.add(messageId)) {
            val position = messages.indexOfFirst { it.id == messageId }
            if (position >= 0) notifyItemChanged(position)
        }
    }

    fun updateMessages(newMessages: List<MessageSummary>) {
        messages = newMessages
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val m = messages[position]
        holder.from.text = m.fromName.ifBlank { "Unknown sender" }
        holder.subject.text = m.subject.ifBlank { "(no subject)" }
        holder.preview.text = m.bodyPreview
        // The short preview is only for a closed message; open, the full text below replaces it.
        holder.preview.visibility = if (m.id in openIds) View.GONE else View.VISIBLE
        holder.preview.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
        holder.preview.alpha = PREVIEW_ALPHA

        val color = ContextCompat.getColor(
            holder.itemView.context,
            if (m.isUnread) R.color.forest else R.color.hairline
        )
        (holder.unreadDot.background.mutate() as GradientDrawable).setColor(color)

        Attachments.fillMessagePanel(holder.panel, m)
        holder.panel.visibility = if (m.id in openIds) View.VISIBLE else View.GONE
        holder.panel.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
        holder.panel.alpha = 1f

        holder.itemView.setOnClickListener {
            if (m.id in openIds) {
                openIds.remove(m.id)
                Expand.collapse(holder.panel)
                // The preview dims back down from the full text's colour as it returns.
                Expand.expand(holder.preview, restAlpha = PREVIEW_ALPHA, fromAlpha = 1f)
            } else {
                openIds.add(m.id)
                Expand.expand(holder.panel)
                // The preview brightens to the full text's colour while it slides away, so the
                // text that replaces it doesn't change colour underneath it.
                Expand.collapse(holder.preview, restAlpha = PREVIEW_ALPHA, toAlpha = 1f)
                if (m.isUnread) onExpanded(m)
            }
        }
    }

    override fun getItemCount(): Int = messages.size

    private companion object {
        const val PREVIEW_ALPHA = 0.6f // as in item_message.xml
    }
}
