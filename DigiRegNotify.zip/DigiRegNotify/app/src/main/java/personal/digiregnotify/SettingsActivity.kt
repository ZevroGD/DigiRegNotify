package personal.digiregnotify

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : BaseActivity() {

    private lateinit var api: RegisterApi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        api = RegisterApi(this)

        setUpChecking()
        setUpNotifications()
        setUpTheme()
        setUpAmoled()
        setUpPalette()
        setUpUpdates()

        findViewById<MaterialButton>(R.id.signOutButton).setOnClickListener {
            AlarmScheduler.cancel(this)
            api.clearCredentials()
            Toast.makeText(this, "Stopped and signed out", Toast.LENGTH_SHORT).show()
            finish()
        }

        findViewById<ImageButton>(R.id.backButton).setOnClickListener { finish() }
        findViewById<MaterialButton>(R.id.developerMenuButton).setOnClickListener {
            startActivity(Intent(this, DeveloperActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.manageSubjectsButton).setOnClickListener {
            startActivity(Intent(this, SubjectSettingsActivity::class.java))
        }
    }

    private fun setUpChecking() {
        val slider = findViewById<Slider>(R.id.intervalSlider)
        val valueText = findViewById<TextView>(R.id.intervalValueText)
        val pollingSwitch = findViewById<MaterialSwitch>(R.id.pollingSwitch)

        val steps = AlarmScheduler.INTERVAL_STEPS_MINUTES
        val currentMinutes = AlarmScheduler.getIntervalMinutes(this)
        slider.value = steps.indexOf(currentMinutes).coerceAtLeast(0).toFloat()
        valueText.text = AlarmScheduler.intervalLabel(currentMinutes)

        val pollingEnabled = AlarmScheduler.isPollingEnabled(this)
        pollingSwitch.isChecked = pollingEnabled
        slider.isEnabled = pollingEnabled

        pollingSwitch.setOnCheckedChangeListener { _, isChecked ->
            slider.isEnabled = isChecked
            AlarmScheduler.setPollingEnabled(this, isChecked)
            if (isChecked) {
                if (api.hasCredentials()) AlarmScheduler.scheduleRepeating(this)
            } else {
                AlarmScheduler.cancel(this)
            }
        }

        slider.addOnChangeListener { _, value, fromUser ->
            val minutes = steps[value.toInt().coerceIn(0, steps.size - 1)]
            valueText.text = AlarmScheduler.intervalLabel(minutes)
            if (fromUser) {
                AlarmScheduler.setIntervalMinutes(this, minutes)
                if (api.hasCredentials() && AlarmScheduler.isPollingEnabled(this)) {
                    AlarmScheduler.scheduleRepeating(this)
                }
            }
        }

        findViewById<MaterialButton>(R.id.openNotificationSettingsButton).setOnClickListener {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:$packageName"))
            }
            startActivity(intent)
        }

        findViewById<MaterialButton>(R.id.checkNowButton).setOnClickListener { runManualCheck() }
    }

    private fun runManualCheck() {
        val button = findViewById<MaterialButton>(R.id.checkNowButton)
        button.isEnabled = false
        button.text = "Checking…"

        CoroutineScope(Dispatchers.IO).launch {
            val result = CheckRunner.performCheck(this@SettingsActivity, CheckStatus.Source.MANUAL)
            withContext(Dispatchers.Main) {
                button.isEnabled = true
                button.text = "Check now"

                val message = when (result) {
                    is CheckResult.Success ->
                        "Checked OK — ${result.totalItems} items, ${result.newItems} new"
                    is CheckResult.NoConnection ->
                        "No internet connection right now"
                    is CheckResult.Failure ->
                        "Check failed:\n\n${result.message}"
                }

                SlideDialogBuilder(this@SettingsActivity)
                    .setTitle("Check result")
                    .setMessage(message)
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    private fun setUpNotifications() {
        val gradesSwitch = findViewById<MaterialSwitch>(R.id.notifyGradesSwitch)
        val homeworkSwitch = findViewById<MaterialSwitch>(R.id.notifyHomeworkSwitch)
        val messagesSwitch = findViewById<MaterialSwitch>(R.id.notifyMessagesSwitch)
        val calendarSwitch = findViewById<MaterialSwitch>(R.id.notifyCalendarSwitch)

        gradesSwitch.isChecked = NotificationPrefs.isGradesEnabled(this)
        homeworkSwitch.isChecked = NotificationPrefs.isHomeworkEnabled(this)
        messagesSwitch.isChecked = NotificationPrefs.isMessagesEnabled(this)
        calendarSwitch.isChecked = NotificationPrefs.isCalendarEnabled(this)

        gradesSwitch.setOnCheckedChangeListener { _, isChecked ->
            NotificationPrefs.setGradesEnabled(this, isChecked)
        }
        homeworkSwitch.setOnCheckedChangeListener { _, isChecked ->
            NotificationPrefs.setHomeworkEnabled(this, isChecked)
        }
        messagesSwitch.setOnCheckedChangeListener { _, isChecked ->
            NotificationPrefs.setMessagesEnabled(this, isChecked)
        }
        calendarSwitch.setOnCheckedChangeListener { _, isChecked ->
            NotificationPrefs.setCalendarEnabled(this, isChecked)
        }
    }

    private fun setUpTheme() {
        val systemButton = findViewById<MaterialButton>(R.id.themeSystemButton)
        val lightButton = findViewById<MaterialButton>(R.id.themeLightButton)
        val darkButton = findViewById<MaterialButton>(R.id.themeDarkButton)

        val currentButtonId = when (ThemeManager.getMode(this)) {
            ThemeManager.MODE_LIGHT -> R.id.themeLightButton
            ThemeManager.MODE_DARK -> R.id.themeDarkButton
            else -> R.id.themeSystemButton
        }
        findViewById<com.google.android.material.button.MaterialButtonToggleGroup>(R.id.themeToggleGroup)
            .check(currentButtonId)

        systemButton.setOnClickListener { ThemeManager.setMode(this, ThemeManager.MODE_SYSTEM) }
        lightButton.setOnClickListener { ThemeManager.setMode(this, ThemeManager.MODE_LIGHT) }
        darkButton.setOnClickListener { ThemeManager.setMode(this, ThemeManager.MODE_DARK) }
    }


    private fun setUpAmoled() {
        val amoledSwitch = findViewById<MaterialSwitch>(R.id.amoledSwitch)
        amoledSwitch.isChecked = PaletteManager.isAmoledEnabled(this)
        amoledSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked != PaletteManager.isAmoledEnabled(this)) {
                PaletteManager.setAmoledEnabled(this, isChecked)
                recreate()
            }
        }
    }

    private fun setUpPalette() {
        val container = findViewById<android.widget.LinearLayout>(R.id.paletteContainer)
        val selectedKey = PaletteManager.getSelectedKey(this)
        val inflater = layoutInflater

        container.removeAllViews()
        for (palette in PaletteManager.palettes) {
            val swatchView = inflater.inflate(R.layout.item_palette_swatch, container, false)

            val card = swatchView.findViewById<com.google.android.material.card.MaterialCardView>(R.id.swatchCard)
            val primaryView = swatchView.findViewById<android.view.View>(R.id.swatchPrimary)
            val secondaryView = swatchView.findViewById<android.view.View>(R.id.swatchSecondary)
            val label = swatchView.findViewById<TextView>(R.id.swatchLabel)

            // Resolve from color RESOURCES (not fixed literals) so the preview
            // matches whichever of light/dark mode is actually active right now.
            val isCustom = palette.key == PaletteManager.CUSTOM_KEY
            val primaryColor = if (isCustom) PaletteManager.getCustomPrimary(this)
                else androidx.core.content.ContextCompat.getColor(this, palette.previewPrimaryRes)
            val secondaryColor = if (isCustom) PaletteManager.getCustomSecondary(this)
                else androidx.core.content.ContextCompat.getColor(this, palette.previewSecondaryRes)

            primaryView.setBackgroundColor(primaryColor)
            // The dot has a real oval shape (dot_shape.xml) — tint it in place
            // rather than setBackgroundColor, which would flatten it to a square.
            (secondaryView.background.mutate() as android.graphics.drawable.GradientDrawable)
                .setColor(secondaryColor)
            label.text = palette.displayName

            val isSelected = palette.key == selectedKey
            card.strokeWidth = if (isSelected) 4 else 2
            card.strokeColor = if (isSelected) {
                secondaryColor
            } else {
                androidx.core.content.ContextCompat.getColor(this, R.color.hairline)
            }

            swatchView.setOnClickListener {
                if (isCustom) {
                    // Always opens the color picker; saving it selects the Custom palette.
                    CustomThemeDialog.show(this) { recreate() }
                } else if (palette.key != PaletteManager.getSelectedKey(this)) {
                    PaletteManager.setSelectedKey(this, palette.key)
                    recreate()
                }
            }

            container.addView(swatchView)
            (swatchView.layoutParams as android.widget.LinearLayout.LayoutParams).marginEnd = 12
        }
    }
    // ---- Updates ---------------------------------------------------------------------------

    private fun setUpUpdates() {
        val status = findViewById<TextView>(R.id.updateStatusText)
        val autoSwitch = findViewById<MaterialSwitch>(R.id.updateAutoSwitch)
        status.text = "Version ${UpdateChecker.currentVersion(this)}"
        autoSwitch.isChecked = UpdateChecker.isAutoCheckEnabled(this)
        autoSwitch.setOnCheckedChangeListener { _, checked -> UpdateChecker.setAutoCheck(this, checked) }
        findViewById<MaterialButton>(R.id.updateTokenButton).setOnClickListener { showAccessDialog() }
        findViewById<MaterialButton>(R.id.checkUpdateButton).setOnClickListener { runUpdateCheck() }
    }

    /** Optional GitHub token (raises GitHub's request limit). Saved encrypted on this phone. */
    private fun showAccessDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_github_access, null)
        val hasToken = UpdateChecker.hasToken(this)
        val tokenField = view.findViewById<android.widget.EditText>(R.id.tokenField)
        tokenField.hint = if (hasToken) "Token (saved; type to replace)" else "Token (optional)"
        view.findViewById<MaterialButton>(R.id.createTokenButton).setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/settings/personal-access-tokens/new")))
            } catch (e: android.content.ActivityNotFoundException) {
                Toast.makeText(this, "Couldn't open the browser", Toast.LENGTH_SHORT).show()
            }
        }

        val builder = SlideDialogBuilder(this)
            .setTitle("GitHub access")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                UpdateChecker.saveToken(this, tokenField.text.toString())
            }
            .setNegativeButton("Cancel", null)
        if (hasToken) {
            builder.setNeutralButton("Remove token") { _, _ -> UpdateChecker.clearToken(this) }
        }
        builder.show()
    }

    private fun runUpdateCheck() {
        val button = findViewById<MaterialButton>(R.id.checkUpdateButton)
        val status = findViewById<TextView>(R.id.updateStatusText)
        button.isEnabled = false
        button.text = "Checking…"
        CoroutineScope(Dispatchers.IO).launch {
            val result = UpdateChecker.check(this@SettingsActivity)
            withContext(Dispatchers.Main) {
                button.isEnabled = true
                button.text = "Check for update"
                when (result) {
                    is UpdateResult.NoConnection -> status.text = "No connection"
                    is UpdateResult.UpToDate -> status.text = "Up to date · ${result.version}"
                    is UpdateResult.Available -> {
                        status.text = "Update available · ${result.info.version}"
                        UpdateDialogs.show(this@SettingsActivity, result.info)
                    }
                    is UpdateResult.Failure -> {
                        status.text = "Couldn't check"
                        Toast.makeText(this@SettingsActivity, result.message, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }
}
