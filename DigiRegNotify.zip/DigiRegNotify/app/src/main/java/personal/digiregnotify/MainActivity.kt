package personal.digiregnotify

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var usernameInput: TextInputEditText
    private lateinit var passwordInput: TextInputEditText
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var api: RegisterApi

    private val notificationPermissionRequestCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        api = RegisterApi(this)

        usernameInput = findViewById(R.id.usernameInput)
        passwordInput = findViewById(R.id.passwordInput)
        statusText = findViewById(R.id.statusText)
        statusDot = findViewById(R.id.statusDot)

        refreshStatus()
        requestNotificationPermissionIfNeeded()

        findViewById<MaterialButton>(R.id.saveButton).setOnClickListener { onSave() }
        findViewById<MaterialButton>(R.id.testButton).setOnClickListener { onTestNow() }
        findViewById<MaterialButton>(R.id.homeworkButton).setOnClickListener {
            startActivity(Intent(this, HomeworkActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.marksButton).setOnClickListener {
            startActivity(Intent(this, MarksActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.stopButton).setOnClickListener { stopCheckingAndSignOut() }
        findViewById<ImageButton>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus() // interval may have changed in Settings
    }

    private fun refreshStatus() {
        val signedIn = api.hasCredentials()
        statusText.text = if (signedIn) {
            "Signed in · checking every ${AlarmScheduler.getIntervalHours(this)}h"
        } else {
            "Not signed in"
        }
        val dotColor = ContextCompat.getColor(this, if (signedIn) R.color.forest else R.color.brick)
        (statusDot.background.mutate() as GradientDrawable).setColor(dotColor)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    notificationPermissionRequestCode
                )
            }
        }
    }

    private fun requestExactAlarmPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(AlarmManager::class.java)
            if (!am.canScheduleExactAlarms()) {
                Toast.makeText(
                    this,
                    "Please allow exact alarms so checks stay on schedule",
                    Toast.LENGTH_LONG
                ).show()
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        }
    }

    private fun onSave() {
        val username = usernameInput.text.toString().trim()
        val password = passwordInput.text.toString()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter your username and password", Toast.LENGTH_SHORT).show()
            return
        }

        api.saveCredentials(username, password)

        val saveButton = findViewById<MaterialButton>(R.id.saveButton)
        saveButton.isEnabled = false
        statusText.text = "Checking your login…"

        CoroutineScope(Dispatchers.IO).launch {
            val loginOk = api.login()
            withContext(Dispatchers.Main) {
                saveButton.isEnabled = true
                if (loginOk) {
                    requestExactAlarmPermissionIfNeeded()
                    AlarmScheduler.scheduleRepeating(this@MainActivity)
                    passwordInput.text?.clear()
                    refreshStatus()
                    Toast.makeText(
                        this@MainActivity,
                        "Login OK. Checking every ${AlarmScheduler.getIntervalHours(this@MainActivity)} hour(s).",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    statusText.text = "Login failed — check your username/password"
                    Toast.makeText(
                        this@MainActivity,
                        "Login failed. Nothing scheduled yet — fix your username/password and save again.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun onTestNow() {
        if (!api.hasCredentials()) {
            Toast.makeText(this, "Save your credentials first", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Checking now…", Toast.LENGTH_SHORT).show()
        CoroutineScope(Dispatchers.IO).launch {
            val ok = api.login()
            val result = if (ok) {
                val dashboard = api.fetchDashboard()
                if (dashboard != null) {
                    val differ = DashboardDiffer(this@MainActivity)
                    val items = differ.parseItems(dashboard)
                    val newItems = differ.findNewItems(items)
                    NotificationHelper.notifyNewItems(this@MainActivity, newItems)
                    "Checked OK — ${items.size} items, ${newItems.size} new"
                } else {
                    "Login OK, but dashboard fetch failed"
                }
            } else {
                "Login failed — check your username/password"
            }
            withContext(Dispatchers.Main) {
                Toast.makeText(this@MainActivity, result, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun stopCheckingAndSignOut() {
        AlarmScheduler.cancel(this)
        api.clearCredentials()
        refreshStatus()
        Toast.makeText(this, "Stopped and signed out", Toast.LENGTH_SHORT).show()
    }
}
