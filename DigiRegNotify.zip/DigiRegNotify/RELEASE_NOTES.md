## What's new

**New**
- **Interactive grade chart.** Tap the chart on the Marks screen to open it full screen. Drag a finger along it to move a cursor from day to day; every mark of that day shows as a coloured label (subject, kind, mark). Month names run along the bottom, and a Legend lets you show or hide each subject.

**Changed**
- Single marks are now written as on the school's scale: 6.5 is `6/7`, 8.25 is `8+`, 9.75 is `10-`. This applies to the chart labels, the marks listed under each subject, and marks in History. Averages stay plain numbers.
- The Custom theme now lets you pick any two of 56 colours from a grid (primary and secondary), with a live preview.

**Fixed**
- The Custom theme could turn the whole screen white after saving.

---

*Earlier in 1.1:* attachments on homework and messages, a History screen, edit and delete markers, a Developer menu, new-mark notifications, a redesigned Marks screen, slide-down animations and a tile-style More menu.
