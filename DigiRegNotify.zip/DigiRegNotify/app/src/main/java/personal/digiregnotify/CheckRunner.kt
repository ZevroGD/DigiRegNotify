package personal.digiregnotify

import android.content.Context
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

sealed class CheckResult {
    data class Success(
        val totalItems: Int,
        val newItems: Int,
        val newMessages: Int = 0,
        val timetableChanged: Boolean = false,
        /** Everything parsed from the dashboard, so callers (e.g. the Homework screen) can
         *  show what the check just fetched instead of making a second request. */
        val items: List<DashboardItem> = emptyList()
    ) : CheckResult()

    object NoConnection : CheckResult()
    /** [unreachable]: the school's server couldn't be reached at all, so retrying right away is pointless. */
    data class Failure(val message: String, val unreachable: Boolean = false) : CheckResult()
}

object CheckRunner {

    private const val TAG = "DigiReg"

    /**
     * One full check: dashboard (new grades / homework / teacher notes), unread messages,
     * and timetable changes. Used by both the scheduled alarm and the manual button, so
     * "run a check" always means exactly the same thing.
     */
    fun performCheck(
        context: Context,
        source: CheckStatus.Source = CheckStatus.Source.REFRESH
    ): CheckResult {
        val result = try {
            runCheck(context)
        } catch (e: Exception) {
            CheckResult.Failure(e.message ?: "Unknown error")
        }
        CheckStatus.record(context, source, result)
        return result
    }

    private fun runCheck(context: Context): CheckResult {
        val api = RegisterApi(context)
        if (!api.hasCredentials()) return CheckResult.Failure("Not signed in")

        if (!NetworkUtil.isConnected(context)) {
            return CheckResult.NoConnection
        }

        val dashboardJson = api.fetchDashboardWithAutoLogin()
            ?: return api.lastError.let { CheckResult.Failure(it ?: "Could not log in or fetch data", ErrorText.isUnreachable(it)) }

        val differ = DashboardDiffer(context)
        val items = differ.parseItems(dashboardJson)
        // Keep a copy for when the school's server can't be reached. An empty list could be a
        // stale-session artifact, so it never replaces a good copy.
        if (items.isNotEmpty()) DashboardCache.save(context, dashboardJson)
        val newItems = differ.findNewItems(items)

        // Isolated: a bug here should never break the main check above.
        try {
            ChangeDetector.trackChanges(context, items)
        } catch (e: Exception) {
            Log.w(TAG, "Change detection failed", e)
        }

        val filtered = newItems.filter { item ->
            when (item.type) {
                "grade" -> NotificationPrefs.isGradesEnabled(context)
                "gradeGroup", "observation" -> NotificationPrefs.isHomeworkEnabled(context)
                else -> true
            }
        }
        // Separate notifications per kind, so each has a single, unambiguous tap target
        // (Marks for grades, Home for homework/notes) instead of one that can't deep-link.
        val (newGrades, newHomework) = filtered.partition { it.type == "grade" }
        NotificationHelper.notifyNewHomework(context, newHomework)

        // The extras below must never break the main check above, so each is isolated.
        val messageCheck = try {
            checkMessages(context, api)
        } catch (e: Exception) {
            Log.w(TAG, "Message check failed", e)
            MessageCheck(0, 0)
        }
        val newMessages = messageCheck.messages
        // A new grade shows up in both the dashboard and the site's unread list, and the unread
        // list carries the mark itself. It announces them first; the dashboard's version is only
        // posted when that didn't cover them all, so a grade isn't announced twice (the second
        // notification would replace the first).
        if (newGrades.size > messageCheck.gradesAnnounced) {
            NotificationHelper.notifyNewGrades(context, newGrades)
        }
        val timetableChanged = try {
            checkTimetable(context, api)
        } catch (e: Exception) {
            Log.w(TAG, "Timetable check failed", e)
            false
        }

        return CheckResult.Success(items.size, filtered.size, newMessages, timetableChanged, items)
    }

    /**
     * Notifies about unread messages and new marks we haven't announced yet. Uses the single
     * unread-notification request the real site's home screen makes — it already carries
     * sender, subject and the mark itself, so no separate inbox download is needed.
     * Returns how many messages were announced.
     */
    private class MessageCheck(val messages: Int, val gradesAnnounced: Int)

    private fun checkMessages(context: Context, api: RegisterApi): MessageCheck {
        val unreadJson = api.fetchUnreadNotifications() ?: return MessageCheck(0, 0)
        val all = UnreadNotification.parse(unreadJson)
        val messages = all.filter { it.type == "message" }.associateBy { it.notificationId }
        val grades = all.filter { it.type == "grade" }.associateBy { it.notificationId }
        val observations = all.filter { it.type == "observation" || it.type == "criticalObservation" }
            .associateBy { it.notificationId }

        // Always record what we've seen, even with a toggle off, so switching it on
        // later doesn't suddenly announce old items.
        val newMessageIds = ChangeTracker.newMessageNotificationIds(context, messages.keys)
        val newGradeIds = ChangeTracker.newGradeNotificationIds(context, grades.keys)
        val newObservationIds = ChangeTracker.newObservationNotificationIds(context, observations.keys)

        if (newObservationIds.isNotEmpty() && NotificationPrefs.isGradesEnabled(context)) {
            NotificationHelper.notifyNewObservations(context, newObservationIds.mapNotNull { observations[it]?.gradeText })
        }

        var gradesAnnounced = 0
        if (newGradeIds.isNotEmpty() && NotificationPrefs.isGradesEnabled(context)) {
            val texts = newGradeIds.mapNotNull { grades[it]?.gradeText }
            NotificationHelper.notifyNewGradeTexts(context, texts)
            gradesAnnounced = texts.size
        }

        if (newMessageIds.isEmpty() || !NotificationPrefs.isMessagesEnabled(context)) return MessageCheck(0, gradesAnnounced)
        val toShow = newMessageIds.mapNotNull { messages[it] }
            .map { MessagePreview(it.objectId, it.messageSender, it.messageSubject) }
        NotificationHelper.notifyMessages(context, toShow)
        return MessageCheck(toShow.size, gradesAnnounced)
    }

    /** Compares this and next week's timetable with the last check. Returns true if it notified. */
    private fun checkTimetable(context: Context, api: RegisterApi): Boolean {
        if (!NotificationPrefs.isCalendarEnabled(context)) {
            // So that switching it back on starts from a fresh baseline.
            ChangeTracker.clearTimetableSnapshot(context)
            return false
        }

        val format = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val monday = Calendar.getInstance()
        monday.add(Calendar.DAY_OF_YEAR, -((monday.get(Calendar.DAY_OF_WEEK) + 5) % 7))
        val thisWeek = format.format(monday.time)
        monday.add(Calendar.DAY_OF_YEAR, 7)
        val nextWeek = format.format(monday.time)

        // Need both weeks, otherwise a half snapshot would look like lessons vanishing.
        val first = api.fetchCalendarWeek(thisWeek) ?: return false
        val second = api.fetchCalendarWeek(nextWeek) ?: return false
        val a = TimetableParser.parseWeek(first)
        val b = TimetableParser.parseWeek(second)
        OfflineCache.save(context, "timetable-$thisWeek", first)
        OfflineCache.save(context, "timetable-$nextWeek", second)

        val summary = TimetableChanges.detect(
            context = context,
            lessons = a.lessons + b.lessons,
            fetchedDates = (a.dates + b.dates).toSet(),
            today = format.format(Calendar.getInstance().time)
        ) ?: return false

        NotificationHelper.notifyTimetableChanged(context, summary)
        return true
    }
}
