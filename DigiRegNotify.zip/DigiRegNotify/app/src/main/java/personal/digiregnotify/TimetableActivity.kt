package personal.digiregnotify

import android.app.AlertDialog
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * A real grid: periods down the side, days across the top, each cell holding however many
 * lessons actually land there (normally one, more if a group is split). A cell's height
 * grows with its content automatically — that's just how a wrap_content row works, no
 * special-casing needed — and the whole grid fits one screen width using weighted columns,
 * so the header row and every body row always line up without any horizontal-scroll syncing.
 */
class TimetableActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView
    private lateinit var weekLabelText: TextView
    private lateinit var headerRow: LinearLayout
    private lateinit var gridBody: LinearLayout

    private val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val weekLabelFormat = SimpleDateFormat("d MMM", Locale.getDefault())
    private val density by lazy { resources.displayMetrics.density }

    private var weekStart: Calendar = mondayOf(Calendar.getInstance())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timetable)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.timetableEmptyText)
        swipeRefresh = findViewById(R.id.timetableSwipeRefresh)
        weekLabelText = findViewById(R.id.weekLabelText)
        headerRow = findViewById(R.id.gridHeaderRow)
        gridBody = findViewById(R.id.gridBody)

        findViewById<ImageButton>(R.id.timetableBackButton).setOnClickListener { finish() }
        findViewById<TextView>(R.id.prevWeekButton).setOnClickListener { shiftWeek(-7) }
        findViewById<TextView>(R.id.nextWeekButton).setOnClickListener { shiftWeek(7) }
        swipeRefresh.setOnRefreshListener { loadWeek() }

        loadWeek()
    }

    private fun shiftWeek(days: Int) {
        weekStart.add(Calendar.DAY_OF_YEAR, days)
        loadWeek()
    }

    private fun loadWeek() {
        if (!api.hasCredentials()) {
            emptyText.text = "Sign in from the main screen first"
            emptyText.visibility = TextView.VISIBLE
            swipeRefresh.isRefreshing = false
            return
        }

        val monday = weekStart.time
        val sunday = Calendar.getInstance().apply { time = monday; add(Calendar.DAY_OF_YEAR, 6) }.time
        weekLabelText.text = "${weekLabelFormat.format(monday)} – ${weekLabelFormat.format(sunday)}"

        if (!NetworkUtil.isConnected(this)) {
            swipeRefresh.isRefreshing = false
            emptyText.text = "No internet connection right now"
            emptyText.visibility = TextView.VISIBLE
            return
        }

        swipeRefresh.isRefreshing = true
        val startDate = isoFormat.format(monday)

        CoroutineScope(Dispatchers.IO).launch {
            val json = api.fetchCalendarWeek(startDate)
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (json == null) {
                    emptyText.text = ErrorText.friendly(api.lastError, "load the timetable")
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@TimetableActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    return@withContext
                }

                val week = try {
                    TimetableParser.parseWeek(json)
                } catch (e: Exception) {
                    emptyText.text = "Could not read the timetable data"
                    emptyText.visibility = TextView.VISIBLE
                    return@withContext
                }

                buildGrid(week)
                emptyText.visibility = if (week.lessons.isEmpty()) TextView.VISIBLE else TextView.GONE
                emptyText.text = "No lessons found for this week"
            }
        }
    }

    private fun dp(value: Int): Int = (value * density).toInt()

    private fun buildGrid(week: ParsedWeek) {
        headerRow.removeAllViews()
        gridBody.removeAllViews()
        if (week.dates.isEmpty()) return

        val periodColumnWidth = dp(28)

        // --- Header row: blank corner + one cell per day ---
        headerRow.addView(spacerCell(periodColumnWidth))
        for (dateStr in week.dates) {
            val date = TimetableParser.parseDate(dateStr)
            val cell = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                gravity = Gravity.CENTER
                textSize = 12f
                text = date?.let { shortDayLabel(it) } ?: dateStr
                setTextColor(themeColor(android.R.attr.textColorPrimary))
                alpha = 0.8f
                setPadding(2, dp(4), 2, dp(6))
            }
            headerRow.addView(cell)
        }

        // --- Body: one row per distinct period, in order ---
        val byDateAndHour = week.lessons.groupBy { it.date to it.hour }
        val periods = week.lessons.map { it.hour }.distinct().sorted()

        if (periods.isEmpty()) return

        for (period in periods) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(4) }
            }

            row.addView(TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(periodColumnWidth, ViewGroup.LayoutParams.WRAP_CONTENT)
                text = period.toString()
                gravity = Gravity.CENTER
                textSize = 12f
                alpha = 0.5f
                setTextColor(themeColor(android.R.attr.textColorPrimary))
            })

            for (dateStr in week.dates) {
                val lessons = byDateAndHour[dateStr to period].orEmpty()
                row.addView(dayCell(lessons))
            }

            gridBody.addView(row)
        }
    }

    /** One grid cell: stacks every lesson that actually falls here (normally one), so the
     *  cell — and the whole row, since it's a wrap_content LinearLayout — grows on its own. */
    private fun dayCell(lessons: List<LessonInfo>): LinearLayout {
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(2); marginEnd = dp(2)
            }
        }
        for (lesson in lessons) {
            cell.addView(lessonChip(lesson))
        }
        return cell
    }

    private fun lessonChip(lesson: LessonInfo): TextView {
        return TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(3) }
            text = lesson.subject.ifBlank { "?" }
            gravity = Gravity.CENTER
            textSize = 11f
            maxLines = 2
            val color = SubjectColors.colorForCode(context, lesson.subject.ifBlank { "?" })
            val chipColor = if (lesson.isSubstitute) blend(color) else color
            setTextColor(readableTextColor(chipColor))
            setPadding(dp(2), dp(5), dp(2), dp(5))

            val bg = ContextCompat.getDrawable(context, R.drawable.pill_subject_chip)!!.mutate() as GradientDrawable
            bg.setColor(chipColor)
            background = bg

            setOnClickListener { showLessonDetail(lesson) }
        }
    }

    private fun showLessonDetail(lesson: LessonInfo) {
        val lines = mutableListOf("Time: ${lesson.time}")
        if (lesson.rooms.isNotBlank()) lines.add("Room: ${lesson.rooms}")
        if (lesson.teachers.isNotBlank()) lines.add("Teacher: ${lesson.teachers}")
        if (lesson.extras.isNotBlank()) lines.add("Also: ${lesson.extras}")
        if (lesson.isSubstitute) lines.add("⚠ Substitute lesson")

        AlertDialog.Builder(this)
            .setTitle(lesson.subject.ifBlank { "Lesson" })
            .setMessage(lines.joinToString("\n"))
            .setPositiveButton("OK", null)
            .show()
    }

    private fun spacerCell(width: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun themeColor(attr: Int): Int {
        val typedValue = android.util.TypedValue()
        theme.resolveAttribute(attr, typedValue, true)
        return typedValue.data
    }

    /** Slightly muted version of a color, used to flag substitute lessons visually. */
    private fun blend(color: Int): Int {
        val r = (android.graphics.Color.red(color) * 0.7 + 255 * 0.3).toInt()
        val g = (android.graphics.Color.green(color) * 0.7 + 255 * 0.3).toInt()
        val b = (android.graphics.Color.blue(color) * 0.7 + 255 * 0.3).toInt()
        return android.graphics.Color.rgb(r, g, b)
    }

    /** Black or white text, whichever contrasts better against a given background. */
    private fun readableTextColor(bgColor: Int): Int {
        val r = android.graphics.Color.red(bgColor)
        val g = android.graphics.Color.green(bgColor)
        val b = android.graphics.Color.blue(bgColor)
        val luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
        return if (luminance > 0.6) android.graphics.Color.BLACK else android.graphics.Color.WHITE
    }

    /** "Today" / "Tomorrow" reused from DueDateFormat; otherwise a short weekday. */
    private fun shortDayLabel(date: Date): String {
        val quick = DueDateFormat.dayLabel(date)
        if (quick == "Today" || quick == "Tomorrow") return quick
        return SimpleDateFormat("EEE d", Locale.getDefault()).format(date)
    }

    companion object {
        private fun mondayOf(cal: Calendar): Calendar {
            val result = cal.clone() as Calendar
            result.set(Calendar.HOUR_OF_DAY, 0)
            result.set(Calendar.MINUTE, 0)
            result.set(Calendar.SECOND, 0)
            result.set(Calendar.MILLISECOND, 0)
            val isoDow = (result.get(Calendar.DAY_OF_WEEK) + 5) % 7
            result.add(Calendar.DAY_OF_YEAR, -isoDow)
            return result
        }
    }
}
