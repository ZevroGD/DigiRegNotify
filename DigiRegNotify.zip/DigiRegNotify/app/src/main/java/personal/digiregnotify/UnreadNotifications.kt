package personal.digiregnotify

import org.json.JSONArray

/**
 * One entry of POST /api/notification/unread — the same request the real site's home
 * screen makes to show unread messages and new marks (the dashboard itself only carries
 * homework). Example titles: "Neue Mitteilung · <subject>", "Neue Bewertung · M · <test> · 8".
 */
data class UnreadNotification(
    val notificationId: String,
    val type: String,      // "message" or "grade" (others are ignored by callers)
    val objectId: Long,    // message id for messages
    val title: String,
    val subTitle: String,  // for messages: "<weekday, date> · <sender>"
    val timeSent: String
) {
    /** Message subject: the part of the title after "Neue Mitteilung · ". */
    val messageSubject: String get() = title.substringAfter(" · ", title).trim()

    /** Message sender: the part of the subtitle after the date. */
    val messageSender: String get() = subTitle.substringAfterLast(" · ", "").trim()

    /** Grade text without the "Neue Bewertung · " prefix, e.g. "M · 1.Schularbeit · 8". */
    val gradeText: String get() = title.substringAfter(" · ", title).trim()

    companion object {
        fun parse(json: String): List<UnreadNotification> {
            val array = JSONArray(json)
            val result = mutableListOf<UnreadNotification>()
            for (i in 0 until array.length()) {
                val n = array.optJSONObject(i) ?: continue
                result.add(
                    UnreadNotification(
                        notificationId = n.optString("id"),
                        type = n.optString("type"),
                        objectId = n.optLong("objectId"),
                        title = n.optString("title"),
                        subTitle = n.optString("subTitle"),
                        timeSent = n.optString("timeSent")
                    )
                )
            }
            return result
        }
    }
}
