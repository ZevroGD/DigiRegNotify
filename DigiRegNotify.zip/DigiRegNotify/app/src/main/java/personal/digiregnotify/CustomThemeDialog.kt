package personal.digiregnotify

import android.app.Activity
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.LinearLayout
import com.google.android.material.button.MaterialButtonToggleGroup

/**
 * Picks the Custom theme's primary and secondary colour from a fixed grid of colours, with a
 * live preview. (A theme can't take arbitrary colours at runtime, so each grid colour has a
 * ready-made overlay style; see CustomColors.) Save selects the Custom palette.
 */
object CustomThemeDialog {

    fun show(activity: Activity, onSaved: () -> Unit) {
        val view = activity.layoutInflater.inflate(R.layout.dialog_custom_theme, null)
        val previewPrimary = view.findViewById<View>(R.id.customPreviewPrimary)
        val previewSecondary = view.findViewById<View>(R.id.customPreviewSecondary)
        val toggle = view.findViewById<MaterialButtonToggleGroup>(R.id.customColorToggle)
        val grid = view.findViewById<LinearLayout>(R.id.customGrid)
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val chosen = intArrayOf(
            PaletteManager.getCustomPrimaryIndex(activity),
            PaletteManager.getCustomSecondaryIndex(activity)
        )
        var editing = 0

        fun refreshPreview() {
            previewPrimary.setBackgroundColor(CustomColors.argb[chosen[0]])
            (previewSecondary.background.mutate() as GradientDrawable).setColor(CustomColors.argb[chosen[1]])
        }

        // Rebuilds the grid of circles; the chosen one for the current role gets a ring.
        fun buildGrid() {
            grid.removeAllViews()
            val colors = CustomColors.argb
            val onSurface = com.google.android.material.color.MaterialColors.getColor(
                view, com.google.android.material.R.attr.colorOnSurface, android.graphics.Color.GRAY
            )
            for (rowStart in colors.indices step CustomColors.COLUMNS) {
                val row = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_HORIZONTAL
                }
                for (i in rowStart until minOf(rowStart + CustomColors.COLUMNS, colors.size)) {
                    val selected = i == chosen[editing]
                    val circle = View(activity).apply {
                        layoutParams = LinearLayout.LayoutParams(dp(30), dp(30)).apply {
                            setMargins(dp(4), dp(4), dp(4), dp(4))
                        }
                        background = GradientDrawable().apply {
                            shape = GradientDrawable.OVAL
                            setColor(colors[i])
                            // A thin outline keeps white and black circles visible on any background,
                            // and the chosen one gets a thick ring.
                            setStroke(if (selected) dp(3) else dp(1), if (selected) onSurface else 0x55888888)
                        }
                        contentDescription = "Color ${i + 1}"
                        setOnClickListener {
                            chosen[editing] = i
                            refreshPreview()
                            buildGrid()
                        }
                    }
                    row.addView(circle)
                }
                grid.addView(row)
            }
        }

        toggle.check(R.id.customEditPrimary)
        toggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            editing = if (checkedId == R.id.customEditPrimary) 0 else 1
            buildGrid()
        }

        refreshPreview()
        buildGrid()

        SlideDialogBuilder(activity)
            .setTitle("Custom colors")
            .setView(android.widget.ScrollView(activity).apply { addView(view) })
            .setPositiveButton("Save") { _, _ ->
                PaletteManager.setCustomColors(activity, chosen[0], chosen[1])
                PaletteManager.setSelectedKey(activity, PaletteManager.CUSTOM_KEY)
                onSaved()
            }
            .setNeutralButton("Reset") { _, _ ->
                PaletteManager.setCustomColors(activity, CustomColors.DEFAULT_PRIMARY, CustomColors.DEFAULT_SECONDARY)
                PaletteManager.setSelectedKey(activity, PaletteManager.CUSTOM_KEY)
                onSaved()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
