## What's new

**Changed**
- The timetable is smoother and fresher: swipe sideways and the weeks glide past and snap into place (the arrows and a new *Today* button glide too). The neighbouring weeks load ahead, so a swipe usually lands on a filled-in page.
- Double hours are now one tall tile across both periods instead of a tile with a hole underneath. Periods nobody has a lesson in (like period 7) keep their row, so the numbers run without jumps.
- The tiles fill the screen height, show the room under the subject, and each period shows its start time. Today is highlighted in the header, which now reads like "Mon 9" instead of cutting off "Tomorrow", and the title shows "This week" with the dates.
