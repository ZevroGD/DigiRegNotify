package personal.digiregnotify

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Paint
import android.net.Uri
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import com.google.android.material.color.MaterialColors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Showing and opening the attachments ("Anhang") of homework and messages. */
object Attachments {

    /** Adds one row per attachment: descriptions as selectable text, links and files as
     *  tappable lines that call [onClick]. */
    fun addViews(container: LinearLayout, subs: List<Submission>, onClick: (Submission) -> Unit) {
        container.removeAllViews()
        val ctx = container.context
        val density = ctx.resources.displayMetrics.density
        val onSurface = MaterialColors.getColor(container, com.google.android.material.R.attr.colorOnSurface)
        val accent = MaterialColors.getColor(container, com.google.android.material.R.attr.colorSecondary)
        for (s in subs) {
            val tv = TextView(ctx).apply {
                textSize = 13f
                setPadding(0, (4 * density).toInt(), 0, (4 * density).toInt())
                when (s.type) {
                    "text" -> {
                        text = s.text.ifBlank { s.title }
                        setTextColor(onSurface)
                        setTextIsSelectable(true)
                    }
                    "link" -> {
                        text = "🔗 " + s.title.ifBlank { s.link }
                        setTextColor(accent)
                        paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
                        setOnClickListener { onClick(s) }
                    }
                    else -> { // "file"
                        text = "📄 " + s.originalName.ifBlank { s.title.ifBlank { "File" } }
                        setTextColor(accent)
                        paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
                        setOnClickListener { onClick(s) }
                    }
                }
            }
            container.addView(tv)
        }
    }

    /** Opens a link in the browser, or downloads a file with the login session and opens it in
     *  whatever app handles that file type. */
    fun open(activity: Activity, s: Submission, isMessage: Boolean) {
        if (s.type == "link") {
            if (s.link.isBlank()) return
            try {
                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s.link)))
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(activity, "No app to open this link", Toast.LENGTH_SHORT).show()
            }
            return
        }
        if (s.type != "file") return

        if (!NetworkUtil.isConnected(activity)) {
            Toast.makeText(activity, "No internet connection right now", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(activity, "Downloading…", Toast.LENGTH_SHORT).show()
        CoroutineScope(Dispatchers.IO).launch {
            val name = (s.originalName.ifBlank { "attachment-${s.id}" }).replace(Regex("[^A-Za-z0-9._ -]"), "_")
            val dir = File(activity.cacheDir, "attachments").apply { mkdirs() }
            val target = File(dir, "${s.id}_$name")
            val api = RegisterApi(activity)
            val ok = api.downloadSubmission(isMessage, s.id, s.parentId, target)
            DevLog.i("Attachment", "download ${if (isMessage) "message" else "homework"} ${s.id}: ${if (ok) "ok" else "failed"}")
            withContext(Dispatchers.Main) {
                if (!ok) {
                    Toast.makeText(activity, ErrorText.friendly(api.lastError, "download the file"), Toast.LENGTH_LONG).show()
                    return@withContext
                }
                val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", target)
                val ext = target.extension.lowercase()
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
                val view = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, mime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try {
                    activity.startActivity(view)
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(activity, "No app installed to open this file", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /** Fills the area that slides open under a message: its text, then the attachments. */
    fun fillMessagePanel(panel: LinearLayout, message: MessageSummary) {
        panel.removeAllViews()
        val ctx = panel.context
        val density = ctx.resources.displayMetrics.density
        val onSurface = MaterialColors.getColor(panel, com.google.android.material.R.attr.colorOnSurface)
        panel.addView(TextView(ctx).apply {
            text = message.fullBody.ifBlank { "(empty message)" }
            textSize = 14f
            setTextColor(onSurface)
            setTextIsSelectable(true)
            setPadding(0, (10 * density).toInt(), 0, 0)
        })
        if (message.submissions.isNotEmpty()) {
            panel.addView(TextView(ctx).apply {
                text = "Attachments"
                textSize = 12f
                alpha = 0.6f
                setTextColor(onSurface)
                setPadding(0, (14 * density).toInt(), 0, (2 * density).toInt())
            })
            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            val activity = ctx as? Activity
            addViews(box, message.submissions) { if (activity != null) open(activity, it, isMessage = true) }
            panel.addView(box)
        }
    }
}
