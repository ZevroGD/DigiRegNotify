# Register+

A personal, private Android app that logs into Franziskanergymnasium Bozen's
Digitales Register with your own account, checks periodically for new grades
or homework, and sends you a local notification when something new appears.

**This is for your own personal use only** — it logs in as you, using
credentials stored encrypted on your own device. Do not share the APK or
publish this repo publicly, since the source contains your school's exact
login endpoint (not your password — that's typed in at runtime, never
hardcoded).

## How it works

- `RegisterApi.kt` — replicates the two real requests captured from the
  browser: `POST /api/auth/login` and `POST /api/student/dashboard/dashboard`.
  Cookies from login are stored encrypted and reused for the dashboard call.
- `AlarmScheduler.kt` + `CheckAlarmReceiver.kt` — uses `AlarmManager` with
  `setExactAndAllowWhileIdle` to wake up on your chosen interval (default
  2 hours), even through Doze. Each firing reschedules the next one.
- `DashboardDiffer.kt` — remembers item IDs seen on the last check, so only
  genuinely new grades/homework trigger a notification (the very first run
  just records a baseline, no spam of everything at once).
- `MainActivity.kt` — the one screen: enter your username/password and a
  check interval, tap Save. A "Run a check now" button lets you test it
  immediately instead of waiting for the first alarm.

## Getting the APK via GitHub Actions (no Android Studio needed)

1. Create a **private** GitHub repository and push this project to it.
2. GitHub Actions will automatically run on every push to `main` (see
   `.github/workflows/build.yml`), building a debug APK.
3. Go to the repo's **Actions** tab → click the latest run → download the
   `digiregnotify-debug-apk` artifact (it's a zip containing `app-debug.apk`).
4. Transfer the APK to your phone and install it. You'll need to allow
   "install unknown apps" for whatever app you use to open it (Files,
   Chrome, etc.) — Android will prompt you for this the first time.

If you'd rather trigger a build manually without pushing a change, use the
**"Run workflow"** button under Actions (enabled via `workflow_dispatch`).

## First run on your phone

1. Open the app, enter your Digitales Register username and password.
2. Set your check interval in hours (1–24).
3. Tap **Save and start checking**. Android will ask for notification
   permission, and — on Android 12+ — you'll be sent to a system settings
   page to allow "exact alarms" for the app; allow it, or checks will still
   run but may drift in timing.
4. Optionally tap **Run a check now** to confirm login works before waiting
   for the first scheduled check.

## Notes and limitations

- Hardcoded to `franziskanergymnasium.digitalesregister.it` only, since this
  is for one account — no multi-school support, by design.
- If the school ever changes their login page or API, this will silently
  stop working until the requests are re-captured and the endpoints updated.
- Android may still delay an alarm slightly under aggressive battery
  optimization on some phones (notably some Chinese OEM skins like MIUI,
  ColorOS) — if checks seem to stop firing, look for a battery optimization
  exemption setting for this app.
