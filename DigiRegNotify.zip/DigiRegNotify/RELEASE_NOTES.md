## What's new

**Fixed**
- A failed sign-in no longer leaves the wrong login saved, which made the app open as "signed in" and then fail to load.
- Homework due on the last day shown could go missing or land on the wrong day around a clock change (summer/winter time).
- A blank list from the school can no longer make all your homework look new again.
- Updates keep working when the optional GitHub token has expired, and a failed update check no longer blocks the next one for 11 hours.

**Changed**
- Background checks no longer show an error notification while the school's server is down, and a repeated error doesn't ping again.
