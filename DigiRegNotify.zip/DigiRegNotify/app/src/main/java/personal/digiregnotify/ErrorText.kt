package personal.digiregnotify

/** Turns raw exception text into something you can act on. */
object ErrorText {

    /** The school's server couldn't be reached at all (not an answer like "wrong password"). */
    fun isUnreachable(rawError: String?): Boolean = rawError != null && (
        rawError.contains("UnknownHostException") ||
            rawError.contains("SocketTimeoutException") ||
            rawError.contains("ConnectException") ||
            rawError.contains("NoRouteToHostException") ||
            rawError.contains("SocketException")
        )

    /** The school's server answered with an error of its own (HTTP 5xx). */
    fun isServerError(rawError: String?): Boolean = rawError != null && serverError.containsMatchIn(rawError)

    private val serverError = Regex("HTTP (5\\d\\d)")

    fun friendly(rawError: String?, what: String): String {
        if (rawError == null) return "Could not $what"
        return when {
            rawError.contains("UnknownHostException") ->
                "No internet connection. Check your Wi-Fi or mobile data."
            isUnreachable(rawError) ->
                "The school's server isn't answering. It may be down; try again in a few minutes."
            serverError.containsMatchIn(rawError) ->
                "The school's server has a problem (HTTP ${serverError.find(rawError)!!.groupValues[1]}). Try again later."
            rawError == "Not signed in" ->
                "Not signed in."
            rawError.contains("login response") || rawError.contains("login HTTP 4") ->
                "Sign-in was rejected. If your password changed, sign out and sign in again."
            else -> "Could not $what:\n$rawError"
        }
    }

    /** A few words for a banner. */
    fun reason(rawError: String?): String = when {
        rawError == null -> "Couldn't refresh"
        rawError.contains("UnknownHostException") -> "No internet"
        isUnreachable(rawError) -> "School server not answering"
        serverError.containsMatchIn(rawError) -> "School server error"
        rawError == "Not signed in" -> "Signed out"
        else -> "Couldn't refresh"
    }
}
