## What's new

**Changed**
- Opening a message now grows its preview into the full text, instead of showing the text twice. Closing shrinks it back.
