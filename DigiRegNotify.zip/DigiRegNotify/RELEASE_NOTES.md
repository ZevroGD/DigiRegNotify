## What's new

**Changed**
- With no internet (or when the school's server can't be reached), the timetable and marks now show the last saved copy, greyed out, with a line saying when it was saved. Home's saved list is greyed out too.
- Marking an unread message as read on Home now slides it off to the right, and the rows below glide up.

**Fixed**
- An opened message no longer shows its short preview above the full text; the preview slides away while it is open.
- Tapping the menu button repeatedly no longer opens the menu several times.
- A new grade is announced once instead of twice (the second notification replaced the first, which could be the one without the mark).
- New-grade notifications now put the mark first (in the title), so it is still visible on a watch or a collapsed notification.
