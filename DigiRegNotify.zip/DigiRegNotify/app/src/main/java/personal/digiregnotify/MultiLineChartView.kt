package personal.digiregnotify

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import com.google.android.material.color.MaterialColors

data class ChartSeries(
    val subjectId: Int,
    val points: List<Pair<Long, Float>>, // (dateMillis, grade), oldest -> newest
    val color: Int,
    val strokeWidthDp: Float = 3f // 0 hides both the line and its points for this subject
)

/** Plots several subjects' grades on one shared timeline, each in its own color/thickness,
 *  with a labeled Y-axis so the actual grade values are readable, not just relative shapes. */
class MultiLineChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var series: List<ChartSeries> = emptyList()
    private val density = resources.displayMetrics.density

    // The theme's own on-surface color, so the numbers match the rest of the text in both
    // light and dark mode (textColorPrimary resolved to a dark blue on this theme).
    private val axisTextColor: Int by lazy {
        MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurface, Color.GRAY)
    }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#22888888")
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    private val axisTextPaint by lazy {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = axisTextColor
            alpha = 160
            textSize = 10f * density
            textAlign = Paint.Align.RIGHT
        }
    }

    fun setSeries(newSeries: List<ChartSeries>) {
        series = newSeries
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val allPoints = series.flatMap { it.points }
        if (allPoints.isEmpty()) return

        val padding = 8f * density
        val axisWidth = 24f * density // reserved space for the "2 4 6 8 10" labels on the left
        val chartLeft = axisWidth
        val chartRight = width - padding
        val chartTop = padding
        val chartBottom = height - padding
        val w = chartRight - chartLeft
        val h = chartBottom - chartTop
        if (w <= 0 || h <= 0) return

        // The axis only reaches as low as the marks do, in steps of 2, but never lower than
        // is needed: 5 -> starts at 4, and it never goes below 4 unless a mark is under 4.
        val visibleMin = series.filter { it.strokeWidthDp > 0f }
            .flatMap { it.points }.minOfOrNull { it.second } ?: 1f
        val minVal = (Math.floor(((visibleMin - 1f) / 2f).toDouble()).toFloat() * 2f)
            .coerceIn(0f, 4f)
        val maxVal = 10f
        val range = (maxVal - minVal).coerceAtLeast(0.01f)

        fun yFor(value: Float) = chartTop + h - ((value - minVal) / range) * h

        // Axis: a line + number every 2 grade points, from the lower bound up to 10.
        var gridValue = if (minVal < 2f) 2f else minVal
        while (gridValue <= maxVal) {
            val y = yFor(gridValue)
            canvas.drawLine(chartLeft, y, chartRight, y, gridPaint)
            canvas.drawText(gridValue.toInt().toString(), axisWidth - 6f * density, y + 3f * density, axisTextPaint)
            gridValue += 2f
        }

        val minDate = allPoints.minOf { it.first }
        val maxDate = allPoints.maxOf { it.first }
        val dateRange = (maxDate - minDate).coerceAtLeast(1L)

        for (s in series) {
            if (s.points.isEmpty() || s.strokeWidthDp <= 0f) continue // 0 width = hidden entirely

            val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = s.color
                style = Paint.Style.STROKE
                strokeWidth = s.strokeWidthDp * density
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
            }
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = s.color
                style = Paint.Style.FILL
            }

            fun x(dateMillis: Long) = chartLeft + ((dateMillis - minDate).toFloat() / dateRange) * w
            fun y(value: Float) = yFor(value)

            if (s.points.size == 1) {
                val (date, value) = s.points[0]
                canvas.drawCircle(x(date), y(value), (s.strokeWidthDp + 1f) * density / 2, dotPaint)
                continue
            }

            var prevX = x(s.points[0].first)
            var prevY = y(s.points[0].second)
            for (i in 1 until s.points.size) {
                val (date, value) = s.points[i]
                val cx = x(date)
                val cy = y(value)
                canvas.drawLine(prevX, prevY, cx, cy, linePaint)
                prevX = cx
                prevY = cy
            }
            for ((date, value) in s.points) {
                canvas.drawCircle(x(date), y(value), (s.strokeWidthDp + 1f) * density / 2, dotPaint)
            }
        }
    }
}
