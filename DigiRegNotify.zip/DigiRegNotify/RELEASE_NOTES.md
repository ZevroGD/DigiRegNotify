## What's new

**Changed**
- The colour wheel's triangle now points up (white at the top, black at the bottom left, the pure colour at the bottom right) and stays that way while you change the hue.
- The Custom theme now has 1,728 prepared colours instead of 204, so the colour you get is much closer to the one you picked. Before, muted colours such as greyish blues could turn into plain grey or a much brighter blue.
