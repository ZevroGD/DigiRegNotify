package personal.digiregnotify

import android.content.Context
import org.json.JSONObject

object ChangeDetector {

    private const val PREFS = "digireg_change_snapshot"
    private const val KEY = "snapshot"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(item: DashboardItem) = "${item.type}:${item.id}"

    private fun signature(item: DashboardItem): String =
        listOf(item.title, item.subtitle, item.deadline ?: "", item.grade ?: "", item.checked.toString())
            .joinToString("|")

    private fun summaryFor(item: DashboardItem): String {
        val subject = if (item.label.isNotBlank()) "${item.label} — " else ""
        return when (item.type) {
            "grade" -> "$subject${item.subtitle}" + (item.grade?.let { ": $it" } ?: "")
            "gradeGroup" -> "$subject${item.title}: ${item.subtitle}"
            else -> item.subtitle.ifBlank { item.title }
        }
    }

    /**
     * Compares [items] against the last full snapshot and logs real changes/deletions —
     * "added" isn't logged here since that's already what the regular new-item notification
     * covers. The first call only records a baseline, same as the notification tracking.
     *
     * Caveat worth knowing: an item can also disappear here simply because it's aged out of
     * the dashboard feed's visible date window, not because a teacher actually deleted it.
     * There's no way to tell the two apart from this data alone.
     */
    fun detectAndLog(context: Context, items: List<DashboardItem>) {
        val relevant = items.filter { it.type == "grade" || it.type == "gradeGroup" }
        val currentByKey = relevant.associateBy { key(it) }

        val raw = prefs(context).getString(KEY, null)
        val isFirstRun = raw == null
        val previous: Map<String, Pair<String, String>> = if (raw != null) {
            try {
                val obj = JSONObject(raw)
                obj.keys().asSequence().associateWith { k ->
                    val entry = obj.getJSONObject(k)
                    entry.getString("sig") to entry.getString("summary")
                }
            } catch (e: Exception) {
                emptyMap()
            }
        } else {
            emptyMap()
        }

        // Save the new snapshot regardless of what we find below.
        val newSnapshot = JSONObject()
        for ((k, item) in currentByKey) {
            newSnapshot.put(k, JSONObject().apply {
                put("sig", signature(item))
                put("summary", summaryFor(item))
            })
        }
        prefs(context).edit().putString(KEY, newSnapshot.toString()).apply()

        if (isFirstRun) return

        val now = System.currentTimeMillis()
        val entries = mutableListOf<ChangeLogEntry>()

        for ((k, item) in currentByKey) {
            val old = previous[k] ?: continue // new item — the notification path covers this
            if (old.first != signature(item)) {
                entries.add(ChangeLogEntry(now, "changed", item.type, summaryFor(item)))
            }
        }
        for ((k, old) in previous) {
            if (k !in currentByKey) {
                entries.add(ChangeLogEntry(now, "deleted", k.substringBefore(':'), old.second))
            }
        }

        ChangeLog.append(context, entries)
    }
}
