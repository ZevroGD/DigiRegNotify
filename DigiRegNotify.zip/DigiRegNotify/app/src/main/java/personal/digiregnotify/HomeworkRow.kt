package personal.digiregnotify

sealed class HomeworkRow {
    data class DateHeader(val label: String) : HomeworkRow()
    data class Item(val item: DashboardItem) : HomeworkRow()
}
