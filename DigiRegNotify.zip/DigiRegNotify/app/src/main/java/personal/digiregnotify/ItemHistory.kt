package personal.digiregnotify

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** What a homework item said before an edit. [ts] is when the app noticed the edit. */
data class ItemVersion(val ts: Long, val title: String, val subtitle: String, val deadline: String)

/** A homework item that vanished from the feed while it was still due. [ts] = noticed at. */
data class DeletedHomework(
    val key: String,
    val label: String,
    val title: String,
    val subtitle: String,
    val deadline: String,
    val ts: Long
)

/**
 * Per-item edit history and deleted-homework markers, shown right on the Homework screen
 * (an info button on the edited item, a marker on the date a deleted item was due) instead
 * of a separate change log. Only what the app actually saw is known: edits made before
 * the first check, or while no check ran, can't be recovered.
 */
object ItemHistory {

    private const val PREFS = "digireg_item_history"
    private const val KEY_VERSIONS = "versions"
    private const val KEY_DELETED = "deleted"
    private const val MAX_VERSIONS_PER_ITEM = 10
    private const val MAX_DELETED = 60

    data class Data(
        val versions: Map<String, List<ItemVersion>>, // oldest first
        val deleted: List<DeletedHomework>
    )

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun load(context: Context): Data = Data(readVersions(context), readDeleted(context))

    @Synchronized
    fun addVersion(context: Context, key: String, version: ItemVersion) {
        val all = readVersions(context).toMutableMap()
        all[key] = ((all[key] ?: emptyList()) + version).takeLast(MAX_VERSIONS_PER_ITEM)
        writeVersions(context, all)
    }

    @Synchronized
    fun addDeleted(context: Context, item: DeletedHomework) {
        val list = (readDeleted(context).filter { it.key != item.key } + item).takeLast(MAX_DELETED)
        writeDeleted(context, list)
    }

    fun clear(context: Context) {
        prefs(context).edit().clear().apply()
    }

    /** Drops history of items that no longer exist, and deleted markers whose day has passed. */
    @Synchronized
    fun prune(context: Context, currentKeys: Set<String>, todayStartMillis: Long) {
        val versions = readVersions(context).filterKeys { it in currentKeys }
        writeVersions(context, versions)
        val deleted = readDeleted(context).filter {
            val due = DueDateFormat.parse(it.deadline)?.time ?: return@filter false
            due >= todayStartMillis
        }
        writeDeleted(context, deleted)
    }

    private fun readVersions(context: Context): Map<String, List<ItemVersion>> {
        val raw = prefs(context).getString(KEY_VERSIONS, null) ?: return emptyMap()
        return try {
            val obj = JSONObject(raw)
            obj.keys().asSequence().associateWith { k ->
                val arr = obj.getJSONArray(k)
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    ItemVersion(o.optLong("ts"), o.optString("title"), o.optString("subtitle"), o.optString("deadline"))
                }
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun writeVersions(context: Context, map: Map<String, List<ItemVersion>>) {
        val obj = JSONObject()
        for ((k, list) in map) {
            val arr = JSONArray()
            for (v in list) arr.put(JSONObject().put("ts", v.ts).put("title", v.title)
                .put("subtitle", v.subtitle).put("deadline", v.deadline))
            obj.put(k, arr)
        }
        prefs(context).edit().putString(KEY_VERSIONS, obj.toString()).apply()
    }

    private fun readDeleted(context: Context): List<DeletedHomework> {
        val raw = prefs(context).getString(KEY_DELETED, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                DeletedHomework(
                    o.optString("key"), o.optString("label"), o.optString("title"),
                    o.optString("subtitle"), o.optString("deadline"), o.optLong("ts")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeDeleted(context: Context, list: List<DeletedHomework>) {
        val arr = JSONArray()
        for (d in list) arr.put(JSONObject().put("key", d.key).put("label", d.label).put("title", d.title)
            .put("subtitle", d.subtitle).put("deadline", d.deadline).put("ts", d.ts))
        prefs(context).edit().putString(KEY_DELETED, arr.toString()).apply()
    }
}
