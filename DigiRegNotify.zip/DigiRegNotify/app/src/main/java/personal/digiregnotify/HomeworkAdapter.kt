package personal.digiregnotify

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox
import java.text.SimpleDateFormat
import java.util.Locale

private const val VIEW_TYPE_HEADER = 0
private const val VIEW_TYPE_ITEM = 1
private const val VIEW_TYPE_EMPTY = 2
private const val VIEW_TYPE_MESSAGE = 3

/**
 * [onToggle] is called when the user ticks/unticks an item. The owner talks to the server and
 * then re-renders the list, which resets every checkbox to the authoritative state, so a
 * failed request simply snaps the box back. [onOpenMessage]/[onMarkMessageRead] do the same
 * job for the unread-message rows at the top of the list.
 */
class HomeworkAdapter(
    private var rows: List<HomeworkRow>,
    private val onToggle: (DashboardItem, Boolean) -> Unit,
    private val onOpenMessage: (MessageSummary) -> Unit,
    private val onMarkMessageRead: (MessageSummary) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    class HeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val label: TextView = view.findViewById(R.id.headerLabel)
        val info: TextView = view.findViewById(R.id.headerInfo)
        val panel: LinearLayout = view.findViewById(R.id.headerDeletedPanel)
    }

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val checkbox: MaterialCheckBox = view.findViewById(R.id.itemCheckbox)
        val subjectBadge: TextView = view.findViewById(R.id.itemSubjectBadge)
        val category: TextView = view.findViewById(R.id.itemCategory)
        val subject: TextView = view.findViewById(R.id.itemSubject)
        val gradeValue: TextView = view.findViewById(R.id.itemGradeValue)
        val info: TextView = view.findViewById(R.id.itemInfoButton)
        val historyPanel: LinearLayout = view.findViewById(R.id.itemHistoryPanel)
    }

    class EmptyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view as TextView
    }

    class MessageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val from: TextView = view.findViewById(R.id.unreadRowFrom)
        val subject: TextView = view.findViewById(R.id.unreadRowSubject)
        val openButton: MaterialButton = view.findViewById(R.id.unreadRowOpenButton)
        val markReadButton: MaterialButton = view.findViewById(R.id.unreadRowMarkReadButton)
    }

    // Which info panels are open, so they stay open when the list is re-rendered.
    private val openPanels = mutableSetOf<String>()
    private val timeFormat = SimpleDateFormat("dd.MM.yy HH:mm", Locale.getDefault())

    private fun addLine(panel: LinearLayout, time: String, text: String) {
        val line = LayoutInflater.from(panel.context).inflate(R.layout.item_history_line, panel, false)
        line.findViewById<TextView>(R.id.historyLineTime).text = time
        line.findViewById<TextView>(R.id.historyLineText).text = text
        panel.addView(line)
    }

    private fun versionText(title: String, subtitle: String, deadline: String): String {
        val due = DueDateFormat.parse(deadline)?.let { " (due ${DueDateFormat.dayLabel(it)})" } ?: ""
        val body = listOf(title, subtitle).filter { it.isNotBlank() }.joinToString(": ")
        return body.ifBlank { "(empty)" } + due
    }

    /** Sets a panel open/closed without animation (used when a row is (re)bound). */
    private fun restorePanel(panel: View, open: Boolean) {
        panel.visibility = if (open) View.VISIBLE else View.GONE
        panel.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
        panel.alpha = 1f
    }

    private fun togglePanel(id: String, panel: View) {
        if (id in openPanels) {
            openPanels.remove(id)
            Expand.collapse(panel)
        } else {
            openPanels.add(id)
            Expand.expand(panel)
        }
    }

    fun updateRows(newRows: List<HomeworkRow>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int =
        when (rows[position]) {
            is HomeworkRow.DateHeader -> VIEW_TYPE_HEADER
            is HomeworkRow.Item -> VIEW_TYPE_ITEM
            is HomeworkRow.EmptyNote -> VIEW_TYPE_EMPTY
            is HomeworkRow.UnreadMessage -> VIEW_TYPE_MESSAGE
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            VIEW_TYPE_HEADER -> HeaderViewHolder(inflater.inflate(R.layout.item_homework_header, parent, false))
            VIEW_TYPE_EMPTY -> EmptyViewHolder(inflater.inflate(R.layout.item_homework_empty, parent, false))
            VIEW_TYPE_MESSAGE -> MessageViewHolder(inflater.inflate(R.layout.item_unread_message_row, parent, false))
            else -> ItemViewHolder(inflater.inflate(R.layout.item_homework, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is HomeworkRow.DateHeader -> {
                val h = holder as HeaderViewHolder
                h.label.text = row.label
                if (row.deleted.isEmpty()) {
                    h.info.visibility = View.GONE
                    h.panel.visibility = View.GONE
                } else {
                    val id = "deleted:${row.label}"
                    h.info.visibility = View.VISIBLE
                    h.info.text = "ⓘ ${row.deleted.size} deleted"
                    h.panel.removeAllViews()
                    for (d in row.deleted.sortedBy { it.ts }) {
                        val subject = d.label.takeIf { it.isNotBlank() }
                            ?.let { SubjectNames.nameFor(h.itemView.context, it) + " — " } ?: ""
                        addLine(
                            h.panel, "Deleted ${timeFormat.format(java.util.Date(d.ts))}",
                            subject + versionText(d.title, d.subtitle, "")
                        )
                    }
                    restorePanel(h.panel, id in openPanels)
                    h.info.setOnClickListener { togglePanel(id, h.panel) }
                }
            }
            is HomeworkRow.EmptyNote -> {
                (holder as EmptyViewHolder).text.text = row.text
            }
            is HomeworkRow.UnreadMessage -> {
                val h = holder as MessageViewHolder
                val message = row.message
                h.from.text = message.fromName.ifBlank { "Unknown sender" }
                h.subject.text = message.subject.ifBlank { "(no subject)" }
                h.openButton.setOnClickListener { onOpenMessage(message) }
                h.markReadButton.setOnClickListener {
                    h.markReadButton.isEnabled = false
                    onMarkMessageRead(message)
                }
            }
            is HomeworkRow.Item -> {
                val h = holder as ItemViewHolder
                val item = row.item
                val context = h.itemView.context

                // "label" is the school's own subject code (verified against the marks
                // endpoint). Shown as its custom name/color if set in Settings, else the
                // raw code with the default palette color.
                val code = item.label.ifBlank { null }
                if (code != null) {
                    h.subjectBadge.text = SubjectNames.nameFor(context, code)
                    h.subjectBadge.visibility = View.VISIBLE
                    val color = SubjectColors.colorForCode(context, code)
                    (h.subjectBadge.background.mutate() as GradientDrawable).setColor(color)
                    h.subjectBadge.setTextColor(SubjectColors.readableTextColor(color))
                } else {
                    h.subjectBadge.visibility = View.GONE
                }

                h.category.text = item.title.ifBlank { "Item" }
                h.subject.text = item.subtitle.ifBlank { "(no description)" }

                // Edit history: an info button appears only on homework that was edited; it
                // slides open the earlier versions (newest edit first).
                if (row.versions.isEmpty()) {
                    h.info.visibility = View.GONE
                    h.historyPanel.visibility = View.GONE
                } else {
                    val id = "edited:${item.type}:${item.id}"
                    h.info.visibility = View.VISIBLE
                    h.historyPanel.removeAllViews()
                    if (row.versions.size > 1) {
                        addLine(h.historyPanel, "Edited ${row.versions.size} times", "")
                        (h.historyPanel.getChildAt(0)
                            .findViewById<TextView>(R.id.historyLineText)).visibility = View.GONE
                    }
                    for (v in row.versions.asReversed()) {
                        addLine(
                            h.historyPanel, "Edited ${timeFormat.format(java.util.Date(v.ts))} — before:",
                            versionText(v.title, v.subtitle, v.deadline)
                        )
                    }
                    restorePanel(h.historyPanel, id in openPanels)
                    h.info.setOnClickListener { togglePanel(id, h.historyPanel) }
                }

                // Marks and observations (history screen) have nothing to tick; marks show the
                // mark itself on the right.
                val tickable = item.type != "grade" && item.type != "observation"
                h.checkbox.visibility = if (tickable) View.VISIBLE else View.GONE
                if (item.type == "grade" && item.grade != null) {
                    h.gradeValue.visibility = View.VISIBLE
                    h.gradeValue.text = formatGrade(item.grade)
                } else {
                    h.gradeValue.visibility = View.GONE
                }

                h.checkbox.setOnCheckedChangeListener(null)
                h.checkbox.isChecked = item.checked
                h.checkbox.isEnabled = item.checkable
                h.checkbox.setOnCheckedChangeListener { box, isChecked ->
                    box.isEnabled = false // until the server answers and the list re-renders
                    onToggle(item, isChecked)
                }
            }
        }
    }

    /** "9.00" -> "9", "8.75" -> "8.75", "9.50" -> "9.5". */
    private fun formatGrade(raw: String): String {
        val v = raw.toFloatOrNull() ?: return raw
        return String.format(Locale.getDefault(), "%.2f", v).trimEnd('0').trimEnd('.', ',')
    }

    override fun getItemCount(): Int = rows.size
}
