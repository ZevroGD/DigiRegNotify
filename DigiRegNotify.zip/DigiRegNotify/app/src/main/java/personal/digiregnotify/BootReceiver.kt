package personal.digiregnotify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val api = RegisterApi(context)
            if (api.hasCredentials()) {
                AlarmScheduler.scheduleRepeating(context)
            }
        }
    }
}
