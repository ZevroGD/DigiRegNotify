package personal.digiregnotify

import android.app.Application

class DigiRegApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ThemeManager.applySaved(this)
    }
}
