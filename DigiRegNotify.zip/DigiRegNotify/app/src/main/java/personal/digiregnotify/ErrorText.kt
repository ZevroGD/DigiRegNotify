package personal.digiregnotify

/** Turns raw exception text into something you can act on. */
object ErrorText {
    fun friendly(rawError: String?, what: String): String {
        if (rawError == null) return "Could not $what"
        return when {
            rawError.contains("UnknownHostException") ->
                "No internet connection — check your Wi-Fi or mobile data"
            rawError.contains("SocketTimeoutException") ->
                "Connection timed out — the network seems slow or unavailable"
            rawError.contains("ConnectException") ->
                "Could not reach the server — check your connection"
            else -> "Could not $what:\n$rawError"
        }
    }
}
