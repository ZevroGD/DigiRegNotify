package personal.digiregnotify

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.slider.Slider
import java.util.Locale

data class SubjectRowState(
    val subjectId: Int,
    val name: String,
    val average: Float?,
    val color: Int,
    val thickness: Int // 0..5 — 0 hides the subject's line and points entirely
)

class SubjectDropdownAdapter(
    private var rows: List<SubjectRowState>,
    private val onThicknessChanged: (subjectId: Int, newThickness: Int) -> Unit
) : RecyclerView.Adapter<SubjectDropdownAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val dot: View = view.findViewById(R.id.rowColorDot)
        val name: TextView = view.findViewById(R.id.rowSubjectName)
        val average: TextView = view.findViewById(R.id.rowAverage)
        val slider: Slider = view.findViewById(R.id.rowThicknessSlider)
    }

    fun updateRows(newRows: List<SubjectRowState>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_subject_dropdown_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val row = rows[position]
        holder.name.text = row.name
        holder.average.text = row.average?.let { String.format(Locale.getDefault(), "%.2f", it) } ?: "–"
        (holder.dot.background.mutate() as GradientDrawable).setColor(row.color)

        holder.slider.trackActiveTintList = android.content.res.ColorStateList.valueOf(row.color)
        holder.slider.thumbTintList = android.content.res.ColorStateList.valueOf(row.color)

        // Avoid firing the listener while we set the restored value during bind.
        holder.slider.clearOnChangeListeners()
        holder.slider.value = row.thickness.toFloat().coerceIn(0f, 5f)
        holder.slider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) onThicknessChanged(row.subjectId, value.toInt())
        }
    }

    override fun getItemCount(): Int = rows.size
}
