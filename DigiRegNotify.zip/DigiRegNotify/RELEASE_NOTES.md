## What's new

**New**
- **Interactive grade chart.** Tap the chart on the Marks screen to open it full screen. Drag a finger along it to move a cursor from day to day; every mark of that day shows as a coloured label (subject, kind, mark). Month names run along the bottom, and a Legend lets you show or hide each subject.

**Changed**
- The More menu and the Sort menu now fly in from the top, overshoot a little and settle. Sort is a styled popup instead of the plain system menu, with a tick on the active choice.
- Single marks are now written as on the school's scale: 6.5 is `6/7`, 8.25 is `8+`, 9.75 is `10-`. This applies to the chart labels, the marks listed under each subject, and marks in History. Averages stay plain numbers.
- The colour pickers (Custom theme and subject colours) now use a colour wheel: drag on the ring for the hue and inside the triangle for brightness and saturation. A hex field and a live preview are included.

**Fixed**
- The Custom theme could turn the whole screen white after saving.

---

*Earlier in 1.1:* attachments on homework and messages, a History screen, edit and delete markers, a Developer menu, new-mark notifications, a redesigned Marks screen, slide-down animations and a tile-style More menu.
