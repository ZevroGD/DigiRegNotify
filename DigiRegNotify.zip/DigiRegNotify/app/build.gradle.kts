plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// CI passes -PciBuildNumber=<n> (GitHub Actions' run_number); local builds fall back to 1.
// This is what actually fixes both problems at once: a real, incrementing version so Android
// knows build N+1 supersedes build N, AND a fixed debug.keystore below so every build is
// signed by the same key — Android refuses an update when the signer changes, which is
// exactly why you had to uninstall between builds before.
val ciBuildNumber = (project.findProperty("ciBuildNumber") as String?)?.toIntOrNull() ?: 1
// Major.minor comes from gradle.properties so the workflow can read the same value.
val appVersionBase = (project.findProperty("appVersionBase") as String?) ?: "1.0"
// The last number restarts at 0 for every new appVersionBase; versionCode still always rises.
val appBuildOffset = (project.findProperty("appBuildOffset") as String?)?.toIntOrNull() ?: 0

android {
    namespace = "personal.digiregnotify"
    compileSdk = 34

    defaultConfig {
        applicationId = "personal.digiregnotify"
        minSdk = 26
        targetSdk = 34
        versionCode = ciBuildNumber
        versionName = "$appVersionBase.${(ciBuildNumber - appBuildOffset).coerceAtLeast(0)}"
    }

    signingConfigs {
        getByName("debug") {
            // Checked into the repo on purpose: it's a debug-only key with the well-known
            // default alias/password, not a secret. The point is that it's the SAME file
            // every build, so every APK has the same signing certificate.
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")

    // Networking
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Coroutines, for clean async code in the alarm receiver
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
