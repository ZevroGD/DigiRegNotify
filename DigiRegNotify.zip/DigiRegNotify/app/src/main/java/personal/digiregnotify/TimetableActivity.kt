package personal.digiregnotify

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class TimetableActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var adapter: TimetableAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView
    private lateinit var weekLabelText: TextView

    private val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val weekLabelFormat = SimpleDateFormat("d MMM", Locale.getDefault())

    /** Monday of the currently shown week, always normalized to a clean day boundary. */
    private var weekStart: Calendar = mondayOf(Calendar.getInstance())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timetable)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.timetableEmptyText)
        swipeRefresh = findViewById(R.id.timetableSwipeRefresh)
        weekLabelText = findViewById(R.id.weekLabelText)

        val recyclerView = findViewById<RecyclerView>(R.id.timetableRecyclerView)
        adapter = TimetableAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<ImageButton>(R.id.timetableBackButton).setOnClickListener { finish() }
        findViewById<TextView>(R.id.prevWeekButton).setOnClickListener { shiftWeek(-7) }
        findViewById<TextView>(R.id.nextWeekButton).setOnClickListener { shiftWeek(7) }
        swipeRefresh.setOnRefreshListener { loadWeek() }

        loadWeek()
    }

    private fun shiftWeek(days: Int) {
        weekStart.add(Calendar.DAY_OF_YEAR, days)
        loadWeek()
    }

    private fun loadWeek() {
        if (!api.hasCredentials()) {
            emptyText.text = "Sign in from the main screen first"
            emptyText.visibility = TextView.VISIBLE
            swipeRefresh.isRefreshing = false
            return
        }

        val monday = weekStart.time
        val sunday = Calendar.getInstance().apply { time = monday; add(Calendar.DAY_OF_YEAR, 6) }.time
        weekLabelText.text = "${weekLabelFormat.format(monday)} – ${weekLabelFormat.format(sunday)}"

        if (!NetworkUtil.isConnected(this)) {
            swipeRefresh.isRefreshing = false
            emptyText.text = "No internet connection right now"
            emptyText.visibility = TextView.VISIBLE
            return
        }

        swipeRefresh.isRefreshing = true
        val startDate = isoFormat.format(monday)

        CoroutineScope(Dispatchers.IO).launch {
            val json = api.fetchCalendarWeek(startDate)
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (json == null) {
                    emptyText.text = ErrorText.friendly(api.lastError, "load the timetable")
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@TimetableActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    return@withContext
                }

                val week = try {
                    TimetableParser.parseWeek(json)
                } catch (e: Exception) {
                    emptyText.text = "Could not read the timetable data"
                    emptyText.visibility = TextView.VISIBLE
                    return@withContext
                }

                val rows = buildRows(week)
                adapter.updateRows(rows)
                emptyText.visibility = if (week.lessons.isEmpty()) TextView.VISIBLE else TextView.GONE
                emptyText.text = "No lessons found for this week"
            }
        }
    }

    private fun buildRows(week: ParsedWeek): List<TimetableRow> {
        val rows = mutableListOf<TimetableRow>()
        val byDate = week.lessons.groupBy { it.date }

        for (date in week.dates) {
            val parsedDate = TimetableParser.parseDate(date) ?: continue
            rows.add(TimetableRow.DayHeader(dayLabel(parsedDate)))
            val lessons = byDate[date].orEmpty().sortedBy { it.hour }
            if (lessons.isEmpty()) {
                rows.add(TimetableRow.NoLessons("No lessons"))
            } else {
                lessons.forEach { rows.add(TimetableRow.Lesson(it)) }
            }
        }
        return rows
    }

    /** "Today" / "Tomorrow" reused from DueDateFormat; otherwise a plain weekday + date. */
    private fun dayLabel(date: Date): String {
        val quick = DueDateFormat.dayLabel(date)
        if (quick == "Today" || quick == "Tomorrow") return quick
        return SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(date)
    }

    companion object {
        private fun mondayOf(cal: Calendar): Calendar {
            val result = cal.clone() as Calendar
            result.set(Calendar.HOUR_OF_DAY, 0)
            result.set(Calendar.MINUTE, 0)
            result.set(Calendar.SECOND, 0)
            result.set(Calendar.MILLISECOND, 0)
            // ISO weekday: Monday=1..Sunday=7, independent of the device's first-day-of-week setting
            val isoDow = (result.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Sun=0 -> 6, Mon=1(cal) -> 0
            result.add(Calendar.DAY_OF_YEAR, -isoDow)
            return result
        }
    }
}
