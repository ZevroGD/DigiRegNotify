package personal.digiregnotify

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MessagesActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var adapter: MessageAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_messages)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.messagesEmptyText)
        swipeRefresh = findViewById(R.id.messagesSwipeRefresh)
        recyclerView = findViewById(R.id.messagesRecyclerView)

        adapter = MessageAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<ImageButton>(R.id.messagesBackButton).setOnClickListener { finish() }
        swipeRefresh.setOnRefreshListener { loadMessages() }
        loadMessages()
    }

    private fun loadMessages() {
        if (!api.hasCredentials()) {
            emptyText.text = "Sign in from the main screen first"
            emptyText.visibility = TextView.VISIBLE
            swipeRefresh.isRefreshing = false
            return
        }
        if (!NetworkUtil.isConnected(this)) {
            swipeRefresh.isRefreshing = false
            emptyText.text = "No internet connection right now"
            emptyText.visibility = TextView.VISIBLE
            return
        }

        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            val json = api.fetchMessages() // read-only: never calls markAsRead
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (json == null) {
                    emptyText.text = ErrorText.friendly(api.lastError, "load messages")
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@MessagesActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    return@withContext
                }

                val messages = try {
                    MessageParser.parse(json)
                } catch (e: Exception) {
                    emptyText.text = "Could not read the messages data"
                    emptyText.visibility = TextView.VISIBLE
                    return@withContext
                }

                adapter.updateMessages(messages)
                emptyText.visibility = if (messages.isEmpty()) TextView.VISIBLE else TextView.GONE
                emptyText.text = "No messages"

                scrollToRequestedMessage(messages)
            }
        }
    }

    /** If opened from a "new message" notification, jump to that message. */
    private fun scrollToRequestedMessage(messages: List<MessageSummary>) {
        val targetId = intent.getLongExtra(EXTRA_MESSAGE_ID, -1L)
        if (targetId <= 0) return
        val position = messages.indexOfFirst { it.id == targetId }
        if (position >= 0) recyclerView.scrollToPosition(position)
    }

    companion object {
        const val EXTRA_MESSAGE_ID = "message_id"
    }
}
