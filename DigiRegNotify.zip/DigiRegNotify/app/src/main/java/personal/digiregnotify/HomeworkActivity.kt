package personal.digiregnotify

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** The app's real home screen once signed in: today's and upcoming homework. */
class HomeworkActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var adapter: HomeworkAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView
    private lateinit var sortButton: TextView

    private var allHomeworkItems: List<DashboardItem> = emptyList()
    private var activeCategory: String? = null // null = show all categories

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homework)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.homeworkEmptyText)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        sortButton = findViewById(R.id.sortNavButton)

        val recyclerView = findViewById<RecyclerView>(R.id.homeworkRecyclerView)
        adapter = HomeworkAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<TextView>(R.id.marksNavButton).setOnClickListener {
            startActivity(Intent(this, MarksActivity::class.java))
        }
        findViewById<TextView>(R.id.settingsNavButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        sortButton.setOnClickListener { showSortMenu() }

        swipeRefresh.setOnRefreshListener { loadHomework() }
        loadHomework()
    }

    override fun onResume() {
        super.onResume()
        // If the user signed out from Settings, bounce back to the login screen.
        if (!api.hasCredentials()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun loadHomework() {
        if (!api.hasCredentials()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            val dashboardJson = api.fetchDashboardWithAutoLogin()
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (dashboardJson == null) {
                    emptyText.text = "Could not load homework:\n${api.lastError}"
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@HomeworkActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    return@withContext
                }

                val differ = DashboardDiffer(this@HomeworkActivity)
                val allItems = differ.parseItems(dashboardJson)
                allHomeworkItems = allItems.filter { it.type == "gradeGroup" }

                render()
            }
        }
    }

    /** Shows a menu of categories actually present (e.g. Hausaufgabe, Prüfung) to filter by. */
    private fun showSortMenu() {
        val categories = allHomeworkItems
            .map { it.title.ifBlank { "Other" } }
            .distinct()
            .sorted()

        if (categories.isEmpty()) {
            Toast.makeText(this, "Nothing to sort yet", Toast.LENGTH_SHORT).show()
            return
        }

        val popup = PopupMenu(this, sortButton, Gravity.END)
        popup.menu.add(0, 0, 0, "All")
        categories.forEachIndexed { index, category ->
            popup.menu.add(0, index + 1, index + 1, category)
        }

        popup.setOnMenuItemClickListener { menuItem ->
            activeCategory = if (menuItem.itemId == 0) null else menuItem.title.toString()
            sortButton.text = if (activeCategory == null) "Sort" else activeCategory
            render()
            true
        }
        popup.show()
    }

    /** Applies the active category filter, groups by due date, and pushes to the adapter. */
    private fun render() {
        val filtered = if (activeCategory == null) {
            allHomeworkItems
        } else {
            allHomeworkItems.filter { it.title.ifBlank { "Other" } == activeCategory }
        }

        val rows = buildRows(filtered)
        adapter.updateRows(rows)
        emptyText.visibility = if (filtered.isEmpty()) TextView.VISIBLE else TextView.GONE
        emptyText.text = if (allHomeworkItems.isEmpty()) "No homework found" else "Nothing in this category"
    }

    /** Groups items by due date, inserting a header row before each new day. */
    private fun buildRows(items: List<DashboardItem>): List<HomeworkRow> {
        val withDates = items
            .map { item -> item to DueDateFormat.parse(item.deadline) }
            .sortedBy { it.second?.time ?: Long.MAX_VALUE }

        val rows = mutableListOf<HomeworkRow>()
        var lastDayLabel: String? = null

        for ((item, date) in withDates) {
            val dayLabel = date?.let { DueDateFormat.dayLabel(it) } ?: "No due date"
            if (dayLabel != lastDayLabel) {
                rows.add(HomeworkRow.DateHeader(dayLabel))
                lastDayLabel = dayLabel
            }
            rows.add(HomeworkRow.Item(item))
        }
        return rows
    }
}
