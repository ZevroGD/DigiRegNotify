package personal.digiregnotify

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HomeworkAdapter(private var items: List<DashboardItem>) :
    RecyclerView.Adapter<HomeworkAdapter.ViewHolder>() {

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val subject: TextView = view.findViewById(R.id.itemSubject)
        val deadline: TextView = view.findViewById(R.id.itemDeadline)
    }

    fun updateItems(newItems: List<DashboardItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_homework, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.subject.text = item.subtitle.ifBlank { item.title }
        holder.deadline.text = item.deadline?.let { "Due: $it" } ?: "No deadline"
    }

    override fun getItemCount(): Int = items.size
}
