package personal.digiregnotify

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

class MarksActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var chart: MultiLineChartView
    private lateinit var dropdownAdapter: SubjectDropdownAdapter
    private lateinit var overviewAdapter: SubjectOverviewAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView
    private lateinit var dropdownRecycler: RecyclerView
    private lateinit var overviewRecycler: RecyclerView
    private lateinit var chevron: TextView
    private lateinit var overviewChevron: TextView

    private var subjects: List<SubjectSummary> = emptyList() // only those with grades — charted
    private var allSubjects: List<SubjectSummary> = emptyList() // every subject, grades or not
    private val thicknessBySubject = mutableMapOf<Int, Int>() // default 3, 0..5 (0 = hidden)
    private var dropdownExpanded = false
    private var overviewExpanded = false

    private val isoDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_marks)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.marksEmptyText)
        swipeRefresh = findViewById(R.id.marksSwipeRefresh)
        chart = findViewById(R.id.combinedChart)
        chevron = findViewById(R.id.subjectsDropdownChevron)
        overviewChevron = findViewById(R.id.allSubjectsDropdownChevron)

        dropdownRecycler = findViewById(R.id.marksRecyclerView)
        dropdownAdapter = SubjectDropdownAdapter(emptyList()) { subjectId, newThickness ->
            thicknessBySubject[subjectId] = newThickness
            renderChart()
            renderDropdown()
        }
        dropdownRecycler.layoutManager = LinearLayoutManager(this)
        dropdownRecycler.adapter = dropdownAdapter

        overviewRecycler = findViewById(R.id.allSubjectsRecyclerView)
        overviewAdapter = SubjectOverviewAdapter(emptyList()) { summary -> showSubjectDetail(summary) }
        overviewRecycler.layoutManager = LinearLayoutManager(this)
        overviewRecycler.adapter = overviewAdapter

        findViewById<ImageButton>(R.id.marksBackButton).setOnClickListener { finish() }
        findViewById<android.widget.LinearLayout>(R.id.subjectsDropdownHeader).setOnClickListener {
            dropdownExpanded = !dropdownExpanded
            dropdownRecycler.visibility = if (dropdownExpanded) RecyclerView.VISIBLE else RecyclerView.GONE
            chevron.text = if (dropdownExpanded) "▴" else "▾"
        }
        findViewById<android.widget.LinearLayout>(R.id.allSubjectsDropdownHeader).setOnClickListener {
            overviewExpanded = !overviewExpanded
            overviewRecycler.visibility = if (overviewExpanded) RecyclerView.VISIBLE else RecyclerView.GONE
            overviewChevron.text = if (overviewExpanded) "▴" else "▾"
        }
        swipeRefresh.setOnRefreshListener { loadMarks() }
        loadMarks()
    }

    private fun loadMarks() {
        if (!api.hasCredentials()) {
            emptyText.text = "Sign in from the main screen first"
            emptyText.visibility = TextView.VISIBLE
            swipeRefresh.isRefreshing = false
            return
        }
        if (!NetworkUtil.isConnected(this)) {
            swipeRefresh.isRefreshing = false
            emptyText.text = "No internet connection right now"
            emptyText.visibility = TextView.VISIBLE
            return
        }

        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            val (firstJson, secondJson) = api.fetchAllSubjectsBothSemesters()
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (firstJson == null) {
                    emptyText.text = ErrorText.friendly(api.lastError, "load marks")
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@MarksActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    return@withContext
                }

                val merged = try {
                    val first = AllSubjectsParser.parse(firstJson)
                    if (secondJson != null) {
                        AllSubjectsParser.merge(first, AllSubjectsParser.parse(secondJson))
                    } else {
                        // Semester switch failed — still show what we have, but say so.
                        Toast.makeText(
                            this@MarksActivity,
                            "Could only load one semester (the other failed to switch)",
                            Toast.LENGTH_LONG
                        ).show()
                        first
                    }
                } catch (e: Exception) {
                    emptyText.text = "Could not read the marks data"
                    emptyText.visibility = TextView.VISIBLE
                    return@withContext
                }

                allSubjects = merged.sortedBy { it.name }
                subjects = allSubjects.filter { it.grades.isNotEmpty() }
                for (s in subjects) thicknessBySubject.putIfAbsent(s.subjectId, 3)
                SubjectRegistry.recordCodes(this@MarksActivity, allSubjects.map { it.name })

                renderChart()
                renderDropdown()
                renderOverview()

                emptyText.visibility = if (subjects.isEmpty()) TextView.VISIBLE else TextView.GONE
                emptyText.text = "No grades found yet"
            }
        }
    }

    private fun renderOverview() {
        val rows = allSubjects.map { s ->
            SubjectOverviewRow(
                summary = s,
                displayName = SubjectNames.nameFor(this, s.name),
                color = SubjectColors.colorForCode(this, s.name),
                averageText = (s.averageYear ?: s.averageSemester)?.let {
                    String.format(Locale.getDefault(), "%.2f", it)
                } ?: "no grades yet"
            )
        }
        overviewAdapter.updateRows(rows)
    }

    /** Tapping any subject in "All subjects" — including ones with nothing graphed. */
    private fun showSubjectDetail(summary: SubjectSummary) {
        val name = SubjectNames.nameFor(this, summary.name)
        val count = summary.grades.size
        val avgText = (summary.averageYear ?: summary.averageSemester)?.let {
            String.format(Locale.getDefault(), "Average: %.2f", it)
        } ?: "No grades recorded yet"

        val builder = MaterialAlertDialogBuilder(this).setTitle(name)

        if (summary.grades.isEmpty()) {
            builder.setMessage(avgText)
        } else {
            val container = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                val pad = (20 * resources.displayMetrics.density).toInt()
                setPadding(pad, pad / 2, pad, 0)
            }
            container.addView(TextView(this).apply {
                text = "$avgText  ·  $count grade${if (count == 1) "" else "s"}"
                alpha = 0.8f
            })
            container.addView(GradeChartView(this).apply {
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (120 * resources.displayMetrics.density).toInt()
                ).apply { topMargin = (12 * resources.displayMetrics.density).toInt() }
                setValues(summary.grades.map { it.value })
            })
            builder.setView(container)
        }

        builder.setPositiveButton("OK", null).show()
    }

    private fun renderChart() {
        val series = subjects.map { s ->
            ChartSeries(
                subjectId = s.subjectId,
                points = s.grades.mapNotNull { g ->
                    val date = try {
                        isoDate.parse(g.date)?.time
                    } catch (e: Exception) {
                        null
                    }
                    date?.let { it to g.value }
                },
                color = SubjectColors.colorForCode(this, s.name),
                strokeWidthDp = (thicknessBySubject[s.subjectId] ?: 3).toFloat()
            )
        }
        chart.setSeries(series)
    }

    private fun renderDropdown() {
        val rows = subjects.map { s ->
            SubjectRowState(
                subjectId = s.subjectId,
                name = SubjectNames.nameFor(this, s.name),
                average = s.averageYear ?: s.averageSemester,
                color = SubjectColors.colorForCode(this, s.name),
                thickness = thicknessBySubject[s.subjectId] ?: 3
            )
        }
        dropdownAdapter.updateRows(rows)
    }
}
