package personal.digiregnotify

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Saves the stack trace of any uncaught exception, so a crash can be read afterwards in the
 *  Developer menu instead of vanishing. */
object CrashReporter {

    private const val DIR = "crashes"
    private const val KEEP = 10

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                save(app, thread, error)
            } catch (e: Throwable) {
                // Never let the reporter hide the real crash.
            }
            previous?.uncaughtException(thread, error)
        }
    }

    private fun save(context: Context, thread: Thread, error: Throwable) {
        val dir = File(context.filesDir, DIR).apply { mkdirs() }
        val now = Date()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(now)
        val info = try {
            val p = context.packageManager.getPackageInfo(context.packageName, 0)
            "${p.versionName}"
        } catch (e: Exception) {
            "?"
        }
        val text = buildString {
            append("Crash at ").append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(now)).append('\n')
            append("Thread: ").append(thread.name).append('\n')
            append("App version: ").append(info).append('\n')
            append("Android: ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n")
            append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append("\n\n")
            append(Log.getStackTraceString(error))
        }
        File(dir, "crash_$stamp.txt").writeText(text)
        DevLog.e("Crash", "Uncaught ${error.javaClass.simpleName}: ${error.message}", error)
        dir.listFiles()?.sortedByDescending { it.name }?.drop(KEEP)?.forEach { it.delete() }
    }

    /** Newest first. */
    fun list(context: Context): List<File> =
        File(context.filesDir, DIR).listFiles()?.sortedByDescending { it.name } ?: emptyList()

    fun read(file: File): String = try { file.readText() } catch (e: Exception) { "(unreadable)" }

    fun clear(context: Context) {
        File(context.filesDir, DIR).listFiles()?.forEach { it.delete() }
    }
}
