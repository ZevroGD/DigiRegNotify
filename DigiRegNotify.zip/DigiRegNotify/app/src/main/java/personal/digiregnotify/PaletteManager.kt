package personal.digiregnotify

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build

object PaletteManager {

    const val CUSTOM_KEY = "custom"
    const val DEFAULT_CUSTOM_PRIMARY = 0xFF355C7D.toInt()
    const val DEFAULT_CUSTOM_SECONDARY = 0xFFF4A261.toInt()

    data class Palette(
        val key: String,
        val displayName: String,
        val styleResId: Int,
        val amoledStyleResId: Int,
        // Color RESOURCE ids (not literal ints) so the preview swatch always
        // matches the color that's actually active in the current light/dark mode.
        val previewPrimaryRes: Int,
        val previewSecondaryRes: Int
    )

    val palettes = listOf(
        Palette(
            "ledger", "Ledger",
            R.style.Theme_DigiRegNotify, R.style.Theme_DigiRegNotify_Amoled,
            R.color.ink, R.color.amber
        ),
        Palette(
            "harbor", "Harbor",
            R.style.Theme_DigiRegNotify_Harbor, R.style.Theme_DigiRegNotify_Harbor_Amoled,
            R.color.harbor_primary, R.color.harbor_secondary
        ),
        Palette(
            "moss", "Moss",
            R.style.Theme_DigiRegNotify_Moss, R.style.Theme_DigiRegNotify_Moss_Amoled,
            R.color.moss_primary, R.color.moss_secondary
        ),
        Palette(
            "plum", "Plum",
            R.style.Theme_DigiRegNotify_Plum, R.style.Theme_DigiRegNotify_Plum_Amoled,
            R.color.plum_primary, R.color.plum_secondary
        ),
        Palette(
            "ember", "Ember",
            R.style.Theme_DigiRegNotify_Ember, R.style.Theme_DigiRegNotify_Ember_Amoled,
            R.color.ember_primary, R.color.ember_secondary
        ),
        Palette(
            "crimson", "Crimson",
            R.style.Theme_DigiRegNotify_Crimson, R.style.Theme_DigiRegNotify_Crimson_Amoled,
            R.color.crimson_primary, R.color.crimson_secondary
        ),
        Palette(
            "indigo", "Indigo",
            R.style.Theme_DigiRegNotify_Indigo, R.style.Theme_DigiRegNotify_Indigo_Amoled,
            R.color.indigo_primary, R.color.indigo_secondary
        ),
        Palette(
            "rose", "Rose",
            R.style.Theme_DigiRegNotify_Rose, R.style.Theme_DigiRegNotify_Rose_Amoled,
            R.color.rose_primary, R.color.rose_secondary
        ),
        Palette(
            "lagoon", "Lagoon",
            R.style.Theme_DigiRegNotify_Lagoon, R.style.Theme_DigiRegNotify_Lagoon_Amoled,
            R.color.lagoon_primary, R.color.lagoon_secondary
        ),
        Palette(
            "violet", "Violet",
            R.style.Theme_DigiRegNotify_Violet, R.style.Theme_DigiRegNotify_Violet_Amoled,
            R.color.violet_primary, R.color.violet_secondary
        ),
        // Always last. Its two colors are picked by the user (see CustomThemeDialog).
        Palette(
            CUSTOM_KEY, "Custom",
            R.style.Theme_DigiRegNotify_Custom, R.style.Theme_DigiRegNotify_Custom_Amoled,
            R.color.custom_primary, R.color.custom_secondary
        )
    )

    private const val PREFS = "digireg_settings"
    private const val KEY_PALETTE = "palette_key"
    private const val KEY_AMOLED = "amoled_enabled"
    private const val KEY_CUSTOM_PRIMARY = "custom_primary"
    private const val KEY_CUSTOM_SECONDARY = "custom_secondary"

    /** Whether the last attempt to swap in the custom colors worked (it needs Android 11+). */
    @Volatile
    var customColorsApplied = true
        private set

    fun getCustomPrimary(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_CUSTOM_PRIMARY, DEFAULT_CUSTOM_PRIMARY)

    fun getCustomSecondary(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_CUSTOM_SECONDARY, DEFAULT_CUSTOM_SECONDARY)

    fun setCustomColors(context: Context, primary: Int, secondary: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_CUSTOM_PRIMARY, primary)
            .putInt(KEY_CUSTOM_SECONDARY, secondary)
            .apply()
    }

    fun isCustomSupported(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

    /** Changes whenever the look changes — screens compare it to know when to recreate. */
    fun getAppearanceSignature(context: Context): String {
        val key = getSelectedKey(context)
        return if (key == CUSTOM_KEY) "$key:${getCustomPrimary(context)}:${getCustomSecondary(context)}" else key
    }

    private fun contrastOn(color: Int): Int =
        if (androidx.core.graphics.ColorUtils.calculateLuminance(color) > 0.5) Color.BLACK else Color.WHITE

    /**
     * Styles can't hold colors chosen at runtime, so the Custom style points at placeholder
     * color resources and this swaps their values (Material's runtime color override,
     * Android 11+). Must run before the screen inflates its layout. Called through reflection
     * so a missing/changed API degrades to "custom colors not applied" instead of a crash.
     */
    fun applyCustomColors(activity: Activity) {
        if (getSelectedKey(activity) != CUSTOM_KEY) return
        val primary = getCustomPrimary(activity)
        val secondary = getCustomSecondary(activity)
        val colors = mapOf(
            R.color.custom_primary to primary,
            R.color.custom_secondary to secondary,
            R.color.custom_on_primary to contrastOn(primary),
            R.color.custom_on_secondary to contrastOn(secondary)
        )
        customColorsApplied = try {
            if (!isCustomSupported()) {
                false
            } else {
                val cls = Class.forName("com.google.android.material.color.ColorResourcesOverride")
                val instance = cls.getMethod("getInstance").invoke(null)
                if (instance == null) {
                    false
                } else {
                    cls.getMethod("applyIfPossible", Context::class.java, Map::class.java)
                        .invoke(instance, activity, colors) as? Boolean ?: false
                }
            }
        } catch (e: Throwable) {
            false
        }
    }

    fun getSelectedKey(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PALETTE, "ledger") ?: "ledger"

    fun setSelectedKey(context: Context, key: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_PALETTE, key).apply()
    }

    fun isAmoledEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_AMOLED, false)

    fun setAmoledEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_AMOLED, enabled).apply()
    }

    private fun isNightModeActive(context: Context): Boolean {
        val flags = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return flags == Configuration.UI_MODE_NIGHT_YES
    }

    fun getSelectedPalette(context: Context): Palette =
        palettes.find { it.key == getSelectedKey(context) } ?: palettes.first()

    /** The style to actually apply, accounting for the AMOLED toggle —
     *  which only takes effect while dark mode is currently active. */
    fun getStyleResId(context: Context): Int {
        val palette = getSelectedPalette(context)
        return if (isAmoledEnabled(context) && isNightModeActive(context)) {
            palette.amoledStyleResId
        } else {
            palette.styleResId
        }
    }
}
