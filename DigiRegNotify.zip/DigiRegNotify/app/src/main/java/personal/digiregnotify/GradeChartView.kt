package personal.digiregnotify

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/**
 * A minimal line chart for plotting a subject's grades over time.
 * Deliberately dependency-free (just Canvas) so it can't break the build.
 */
class GradeChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var values: List<Float> = emptyList()

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#C98A3E") // amber
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#35507A") // ink
        style = Paint.Style.FILL
    }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33888888")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    fun setValues(newValues: List<Float>) {
        values = newValues
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (values.isEmpty()) return

        val padding = 12f
        val w = width - padding * 2
        val h = height - padding * 2
        if (w <= 0 || h <= 0) return

        // Grade scale is fixed 1–10 (adjust if your school uses a different scale)
        val minVal = 1f
        val maxVal = 10f
        val range = (maxVal - minVal).coerceAtLeast(0.01f)

        // Horizontal reference line at the midpoint of the scale
        val midY = padding + h - ((5.5f - minVal) / range) * h
        canvas.drawLine(padding, midY, padding + w, midY, gridPaint)

        if (values.size == 1) {
            val x = padding + w / 2
            val y = padding + h - ((values[0] - minVal) / range) * h
            canvas.drawCircle(x, y, 6f, dotPaint)
            return
        }

        val stepX = w / (values.size - 1)
        var prevX = padding
        var prevY = padding + h - ((values[0] - minVal) / range) * h

        for (i in 1 until values.size) {
            val x = padding + stepX * i
            val y = padding + h - ((values[i] - minVal) / range) * h
            canvas.drawLine(prevX, prevY, x, y, linePaint)
            prevX = x
            prevY = y
        }

        for (i in values.indices) {
            val x = padding + stepX * i
            val y = padding + h - ((values[i] - minVal) / range) * h
            canvas.drawCircle(x, y, 5f, dotPaint)
        }
    }
}
