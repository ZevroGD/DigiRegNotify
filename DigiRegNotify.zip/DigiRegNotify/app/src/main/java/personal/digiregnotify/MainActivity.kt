package personal.digiregnotify

import android.Manifest
import android.app.AlarmManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Pure sign-in screen. If credentials are already saved, this immediately
 * hands off to HomeworkActivity (the app's real "home" screen) instead of
 * showing itself — nothing here is reachable once you're signed in.
 */
class MainActivity : BaseActivity() {

    private lateinit var usernameInput: TextInputEditText
    private lateinit var passwordInput: TextInputEditText
    private lateinit var statusText: TextView
    private lateinit var api: RegisterApi

    private val notificationPermissionRequestCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        api = RegisterApi(this)

        if (api.hasCredentials()) {
            // Already signed in — skip straight to the homework home screen.
            startActivity(Intent(this, HomeworkActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        usernameInput = findViewById(R.id.usernameInput)
        passwordInput = findViewById(R.id.passwordInput)
        statusText = findViewById(R.id.statusText)

        requestNotificationPermissionIfNeeded()

        findViewById<MaterialButton>(R.id.saveButton).setOnClickListener { onSave() }
        findViewById<MaterialButton>(R.id.testButton).setOnClickListener { onTestNow() }
        findViewById<ImageButton>(R.id.loginSettingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    notificationPermissionRequestCode
                )
            }
        }
    }

    private fun requestExactAlarmPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(AlarmManager::class.java)
            if (!am.canScheduleExactAlarms()) {
                Toast.makeText(
                    this,
                    "Please allow exact alarms so checks stay on schedule",
                    Toast.LENGTH_LONG
                ).show()
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        }
    }

    private fun onSave() {
        val username = usernameInput.text.toString().trim()
        val password = passwordInput.text.toString()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter your username and password", Toast.LENGTH_SHORT).show()
            return
        }

        api.saveCredentials(username, password)

        val saveButton = findViewById<MaterialButton>(R.id.saveButton)
        saveButton.isEnabled = false
        statusText.text = "Checking your login…"

        CoroutineScope(Dispatchers.IO).launch {
            val loginOk = api.login()
            withContext(Dispatchers.Main) {
                saveButton.isEnabled = true
                if (loginOk) {
                    requestExactAlarmPermissionIfNeeded()
                    AlarmScheduler.scheduleRepeating(this@MainActivity)
                    startActivity(Intent(this@MainActivity, HomeworkActivity::class.java))
                    finish()
                } else {
                    statusText.text = "Login failed — check your username/password"
                    Toast.makeText(
                        this@MainActivity,
                        "Login failed:\n\n${api.lastError}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun onTestNow() {
        val username = usernameInput.text.toString().trim()
        val password = passwordInput.text.toString()
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter your username and password first", Toast.LENGTH_SHORT).show()
            return
        }

        Toast.makeText(this, "Checking now…", Toast.LENGTH_SHORT).show()
        CoroutineScope(Dispatchers.IO).launch {
            val ok = api.login(username, password)
            val result = if (ok) {
                val dashboard = api.fetchDashboard()
                if (dashboard != null) {
                    val differ = DashboardDiffer(this@MainActivity)
                    val items = differ.parseItems(dashboard)
                    "Login and dashboard fetch both OK — ${items.size} items found.\n\nTap \"Sign in and start checking\" to actually start."
                } else {
                    "Login OK, but dashboard fetch failed:\n\n${api.lastError}"
                }
            } else {
                "Login failed:\n\n${api.lastError}"
            }
            withContext(Dispatchers.Main) {
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("Check result")
                    .setMessage(result)
                    .setPositiveButton("OK", null)
                    .setCancelable(true)
                    .show()
            }
        }
    }
}
