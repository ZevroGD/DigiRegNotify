package personal.digiregnotify

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Everything needed to talk to Digitales Register, based on the real
 * requests captured from the browser:
 *   POST /v2/api/auth/login            {"username":..,"password":..} -> sets cookies
 *   POST /v2/api/student/dashboard/dashboard  {"viewFuture":true}    -> grades/homework
 */
class RegisterApi(context: Context) {

    private val baseUrl = "https://franziskanergymnasium.digitalesregister.it/v2"

    // Cookies persisted across app/process restarts, since AlarmManager
    // wakes up a fresh process each time.
    private val cookiePrefs: SharedPreferences = encryptedPrefs(context, "digireg_cookies")
    private val credPrefs: SharedPreferences = encryptedPrefs(context, "digireg_credentials")

    private fun encryptedPrefs(context: Context, name: String): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context, name, masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private val persistentCookieJar = object : CookieJar {
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            val editor = cookiePrefs.edit()
            for (c in cookies) {
                editor.putString(c.name, "${c.value}|${c.expiresAt}")
            }
            editor.apply()
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val result = mutableListOf<Cookie>()
            for ((name, raw) in cookiePrefs.all) {
                val value = raw as? String ?: continue
                val parts = value.split("|")
                val cookieValue = parts.getOrNull(0) ?: continue
                result.add(
                    Cookie.Builder()
                        .name(name)
                        .value(cookieValue)
                        .domain(url.host)
                        .path("/")
                        .build()
                )
            }
            return result
        }
    }

    private val client = OkHttpClient.Builder()
        .cookieJar(persistentCookieJar)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMedia = "application/json;charset=utf-8".toMediaType()

    fun saveCredentials(username: String, password: String) {
        credPrefs.edit()
            .putString("username", username)
            .putString("password", password)
            .apply()
    }

    fun hasCredentials(): Boolean =
        credPrefs.getString("username", null) != null &&
            credPrefs.getString("password", null) != null

    fun clearCredentials() {
        credPrefs.edit().clear().apply()
        cookiePrefs.edit().clear().apply()
    }

    /** Logs in fresh. Returns true if the server confirms loggedIn:true. */
    fun login(): Boolean {
        val username = credPrefs.getString("username", null) ?: return false
        val password = credPrefs.getString("password", null) ?: return false

        val body = JSONObject()
            .put("username", username)
            .put("password", password)
            .toString()
            .toRequestBody(jsonMedia)

        val request = Request.Builder()
            .url("$baseUrl/api/auth/login")
            .header("Accept", "application/json, text/plain, */*")
            .header("Content-Type", "application/json;charset=utf-8")
            .header("Origin", "https://franziskanergymnasium.digitalesregister.it")
            .header("Referer", "https://franziskanergymnasium.digitalesregister.it/v2/login")
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return false
            val text = response.body?.string() ?: return false
            val json = JSONObject(text)
            return json.optBoolean("loggedIn", false)
        }
    }

    /** Fetches the dashboard (grades, homework, etc). Returns raw JSON text, or null on failure. */
    fun fetchDashboard(): String? {
        val body = JSONObject()
            .put("viewFuture", true)
            .toString()
            .toRequestBody(jsonMedia)

        val request = Request.Builder()
            .url("$baseUrl/api/student/dashboard/dashboard")
            .header("Accept", "application/json, text/plain, */*")
            .header("Content-Type", "application/json;charset=utf-8")
            .header("Origin", "https://franziskanergymnasium.digitalesregister.it")
            .header("Referer", "https://franziskanergymnasium.digitalesregister.it/v2/")
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            return response.body?.string()
        }
    }

    /**
     * Convenience: tries the dashboard with existing cookies; if that looks
     * like it failed (empty/invalid), logs in fresh and retries once.
     */
    fun fetchDashboardWithAutoLogin(): String? {
        val first = fetchDashboard()
        if (first != null && looksValid(first)) return first
        if (!login()) return null
        val second = fetchDashboard()
        return if (second != null && looksValid(second)) second else null
    }

    private fun looksValid(text: String): Boolean {
        val trimmed = text.trim()
        return trimmed.startsWith("[") || trimmed.startsWith("{")
    }
}
