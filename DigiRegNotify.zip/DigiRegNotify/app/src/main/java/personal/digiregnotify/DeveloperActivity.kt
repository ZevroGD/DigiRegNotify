package personal.digiregnotify

import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.pm.PackageInfoCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Logs, crash reports, live status and maintenance actions, in one place. */
class DeveloperActivity : BaseActivity() {

    private lateinit var infoText: TextView
    private lateinit var logText: TextView
    private lateinit var logFilter: EditText
    private lateinit var levelToggle: MaterialButtonToggleGroup
    private lateinit var crashContainer: LinearLayout
    private lateinit var crashEmpty: TextView

    private var minLevel = 'D'
    private var updatingSwitch = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_developer)

        infoText = findViewById(R.id.devInfoText)
        logText = findViewById(R.id.devLogText)
        logFilter = findViewById(R.id.devLogFilter)
        levelToggle = findViewById(R.id.devLevelToggle)
        crashContainer = findViewById(R.id.devCrashContainer)
        crashEmpty = findViewById(R.id.devCrashEmpty)

        findViewById<ImageButton>(R.id.devBackButton).setOnClickListener { finish() }

        findViewById<MaterialButton>(R.id.devRunCheck).setOnClickListener { runCheck(it as MaterialButton) }
        findViewById<MaterialButton>(R.id.devReschedule).setOnClickListener {
            AlarmScheduler.scheduleRepeating(this)
            toast("Alarm rescheduled")
            refresh()
        }
        findViewById<MaterialButton>(R.id.devTestNotification).setOnClickListener {
            NotificationHelper.notifyTest(this)
            refresh()
        }
        findViewById<MaterialButton>(R.id.devResetBaseline).setOnClickListener {
            confirm(
                "Reset what counts as already seen?",
                "The next check records the current state silently, then only new things notify. Nothing is deleted from your account."
            ) {
                ChangeDetector.resetBaseline(this)
                ChangeTracker.resetBaseline(this)
                DevLog.i("Dev", "baselines reset")
                refresh()
            }
        }
        findViewById<MaterialButton>(R.id.devClearItemHistory).setOnClickListener {
            confirm("Clear edit and delete history?", "Removes the ⓘ markers on the Homework screen.") {
                ItemHistory.clear(this)
                DevLog.i("Dev", "item history cleared")
                refresh()
            }
        }
        findViewById<MaterialButton>(R.id.devClearSession).setOnClickListener {
            RegisterApi(this).clearSession()
            DevLog.i("Dev", "session cookies cleared")
            toast("Session forgotten; the next request logs in again")
            refresh()
        }
        findViewById<MaterialButton>(R.id.devShareReport).setOnClickListener {
            share("Register+ report", buildReport())
        }

        findViewById<MaterialSwitch>(R.id.devRecordSwitch).setOnCheckedChangeListener { _, isChecked ->
            if (updatingSwitch) return@setOnCheckedChangeListener
            DevLog.setRecording(this, isChecked)
            refresh()
        }

        levelToggle.check(R.id.devLevelAll)
        levelToggle.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            minLevel = when (id) {
                R.id.devLevelWarn -> 'W'
                R.id.devLevelError -> 'E'
                else -> 'D'
            }
            renderLog()
        }
        logFilter.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = renderLog()
        })
        findViewById<MaterialButton>(R.id.devLogRefresh).setOnClickListener { refresh() }
        findViewById<MaterialButton>(R.id.devLogCopy).setOnClickListener {
            val cm = getSystemService(ClipboardManager::class.java)
            cm.setPrimaryClip(ClipData.newPlainText("Register+ log", logText.text))
            toast("Log copied")
        }
        findViewById<MaterialButton>(R.id.devLogClear).setOnClickListener {
            confirm("Clear the log?", "Deletes all recorded log lines.") {
                DevLog.clear(this)
                refresh()
            }
        }
        findViewById<MaterialButton>(R.id.devCrashClear).setOnClickListener {
            confirm("Clear crash reports?", "Deletes all saved crash reports.") {
                CrashReporter.clear(this)
                refresh()
            }
        }

        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        infoText.text = buildInfo()
        renderLog()
        renderCrashes()
    }

    /** Shows whether the log is recording. */
    private fun renderRecordingState() {
        val on = DevLog.isRecording(this)
        updatingSwitch = true
        findViewById<MaterialSwitch>(R.id.devRecordSwitch).isChecked = on
        updatingSwitch = false
        findViewById<TextView>(R.id.devRecordLabel).text =
            if (on) "Recording (newest ~200 KB kept)" else "Not recording"
    }

    private fun renderLog() {
        renderRecordingState()
        val text = DevLog.read(this, minLevel, logFilter.text.toString())
        logText.text = text.ifBlank { "(nothing logged yet)" }
        findViewById<TextView>(R.id.devLogTitle).text = "Log · ${DevLog.sizeBytes(this) / 1024} KB"
    }

    private fun renderCrashes() {
        crashContainer.removeAllViews()
        val crashes = CrashReporter.list(this)
        crashEmpty.visibility = if (crashes.isEmpty()) TextView.VISIBLE else TextView.GONE
        findViewById<MaterialButton>(R.id.devCrashClear).visibility =
            if (crashes.isEmpty()) MaterialButton.GONE else MaterialButton.VISIBLE
        for (file in crashes) {
            val firstLine = CrashReporter.read(file).lineSequence().firstOrNull().orEmpty()
            val button = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = firstLine
                isAllCaps = false
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (8 * resources.displayMetrics.density).toInt() }
                setOnClickListener { showCrash(file) }
            }
            crashContainer.addView(button)
        }
    }

    private fun showCrash(file: File) {
        val text = CrashReporter.read(file)
        val view = TextView(this).apply {
            this.text = text
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 10f
            setTextIsSelectable(true)
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(view) }
        SlideDialogBuilder(this)
            .setTitle("Crash report")
            .setView(scroll)
            .setPositiveButton("Share") { _, _ -> share("Register+ crash report", text) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun runCheck(button: MaterialButton) {
        button.isEnabled = false
        button.text = "Checking…"
        CoroutineScope(Dispatchers.IO).launch {
            val result = CheckRunner.performCheck(this@DeveloperActivity, CheckStatus.Source.MANUAL)
            withContext(Dispatchers.Main) {
                button.isEnabled = true
                button.text = "Run a check now"
                toast(
                    when (result) {
                        is CheckResult.Success -> "OK: ${result.totalItems} items, ${result.newItems} new"
                        is CheckResult.NoConnection -> "No connection"
                        is CheckResult.Failure -> "Failed: ${result.message}"
                    }
                )
                refresh()
            }
        }
    }

    private fun buildInfo(): String {
        val pm = packageManager
        val pkg = try { pm.getPackageInfo(packageName, 0) } catch (e: Exception) { null }
        val versionName = pkg?.versionName ?: "?"
        val versionCode = pkg?.let { PackageInfoCompat.getLongVersionCode(it) } ?: -1L
        val api = RegisterApi(this)
        val powerManager = getSystemService(PowerManager::class.java)
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        fun yn(b: Boolean) = if (b) "yes" else "NO"
        return listOf(
            "Version:        $versionName (code $versionCode)",
            "Android:        ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})",
            "Device:         ${Build.MANUFACTURER} ${Build.MODEL}",
            "Time now:       ${fmt.format(Date())}",
            "",
            "Logged in:      ${yn(api.hasCredentials())}",
            "Network:        ${if (NetworkUtil.isConnected(this)) "connected" else "OFFLINE"}",
            "Polling:        ${if (AlarmScheduler.isPollingEnabled(this)) "on, every ${AlarmScheduler.getIntervalHours(this)} h" else "OFF"}",
            "Alarm queued:   ${yn(AlarmScheduler.isAlarmPending(this))}",
            "Exact alarms:   ${yn(AlarmScheduler.canScheduleExact(this))}",
            "Notifications:  ${yn(NotificationManagerCompat.from(this).areNotificationsEnabled())}",
            "Battery exempt: ${yn(powerManager.isIgnoringBatteryOptimizations(packageName))}",
            "",
            "Palette:        ${PaletteManager.getAppearanceSignature(this)}",
            "",
            CheckStatus.describe(this)
        ).joinToString("\n")
    }

    private fun buildReport(): String {
        val crashes = CrashReporter.list(this)
        return buildString {
            append("=== STATUS ===\n").append(buildInfo()).append("\n\n")
            append("=== LOG (newest 400 lines) ===\n")
                .append(DevLog.read(this@DeveloperActivity, 'D', "", 400)).append("\n\n")
            append("=== LATEST CRASH ===\n")
                .append(crashes.firstOrNull()?.let { CrashReporter.read(it) } ?: "(none)")
        }.takeLast(150_000)
    }

    private fun share(subject: String, text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, subject))
    }

    private fun confirm(title: String, message: String, action: () -> Unit) {
        SlideDialogBuilder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Yes") { _, _ -> action() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}
