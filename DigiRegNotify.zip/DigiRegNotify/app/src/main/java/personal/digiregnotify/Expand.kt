package personal.digiregnotify

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import java.util.WeakHashMap

/** Slide-down / slide-up (with a fade) for any panel that shows or hides, so dropdown
 *  sections open and close smoothly instead of popping. Used app-wide. */
object Expand {

    private const val DURATION_MS = 220L
    private val running = WeakHashMap<View, ValueAnimator>()

    /** Chevron that points down when closed and up when open. */
    fun rotateChevron(chevron: View, expanded: Boolean, animate: Boolean = true) {
        val target = if (expanded) 180f else 0f
        if (animate) chevron.animate().rotation(target).setDuration(DURATION_MS).start()
        else chevron.rotation = target
    }

    fun expand(view: View, animate: Boolean = true) {
        running.remove(view)?.cancel()
        val lp = view.layoutParams
        val parent = view.parent as? View
        if (!animate || parent == null || parent.width == 0) {
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            view.alpha = 1f
            view.visibility = View.VISIBLE
            view.requestLayout()
            return
        }
        if (view.visibility == View.VISIBLE && lp.height == ViewGroup.LayoutParams.WRAP_CONTENT) return

        // Measure the natural height at the width the view will really get.
        val margins = lp as? ViewGroup.MarginLayoutParams
        val available = parent.width - parent.paddingLeft - parent.paddingRight -
            (margins?.leftMargin ?: 0) - (margins?.rightMargin ?: 0)
        view.measure(
            View.MeasureSpec.makeMeasureSpec(available, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val target = view.measuredHeight

        lp.height = 0
        view.alpha = 0f
        view.visibility = View.VISIBLE
        view.requestLayout()
        run(view, 0, target, 0f, 1f) {
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            view.alpha = 1f
            view.requestLayout()
        }
    }

    fun collapse(view: View, animate: Boolean = true) {
        running.remove(view)?.cancel()
        if (view.visibility != View.VISIBLE) return
        val lp = view.layoutParams
        if (!animate) {
            view.visibility = View.GONE
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            view.alpha = 1f
            return
        }
        run(view, view.height, 0, view.alpha, 0f) {
            view.visibility = View.GONE
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            view.alpha = 1f
        }
    }

    private fun run(view: View, fromH: Int, toH: Int, fromA: Float, toA: Float, onDone: () -> Unit) {
        val lp = view.layoutParams
        val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = DURATION_MS
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                lp.height = (fromH + (toH - fromH) * f).toInt()
                view.alpha = fromA + (toA - fromA) * f
                view.requestLayout()
            }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) { cancelled = true }
                override fun onAnimationEnd(animation: Animator) {
                    if (cancelled) return
                    running.remove(view)
                    onDone()
                }
            })
        }
        running[view] = animator
        animator.start()
    }
}
