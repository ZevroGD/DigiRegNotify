package personal.digiregnotify

/** The fixed grid of colours the Custom theme can use (12 hues in 4 tones, then neutrals).
 *  Themes can't hold colours picked at runtime, so each colour has a ready-made overlay style
 *  (res/values/custom_palette.xml, generated from this same list). */
object CustomColors {
    const val COLUMNS = 8
    const val DEFAULT_PRIMARY = 32   // a deep blue (hue 240, tone 3)
    const val DEFAULT_SECONDARY = 13 // an orange (hue 30, tone 2)

    val argb: IntArray = intArrayOf(
        0xFFF28585.toInt(), 0xFFF2BC85.toInt(), 0xFFF2F285.toInt(), 0xFFBCF285.toInt(), 0xFF85F285.toInt(), 0xFF85F2BC.toInt(), 0xFF85F2F2.toInt(), 0xFF85BCF2.toInt(),
        0xFF8585F2.toInt(), 0xFFBC85F2.toInt(), 0xFFF285F2.toInt(), 0xFFF285BC.toInt(), 0xFFD94C4C.toInt(), 0xFFD9924C.toInt(), 0xFFD9D94C.toInt(), 0xFF92D94C.toInt(),
        0xFF4CD94C.toInt(), 0xFF4CD992.toInt(), 0xFF4CD9D9.toInt(), 0xFF4C92D9.toInt(), 0xFF4C4CD9.toInt(), 0xFF924CD9.toInt(), 0xFFD94CD9.toInt(), 0xFFD94C92.toInt(),
        0xFFA62121.toInt(), 0xFFA66321.toInt(), 0xFFA6A621.toInt(), 0xFF63A621.toInt(), 0xFF21A621.toInt(), 0xFF21A663.toInt(), 0xFF21A6A6.toInt(), 0xFF2163A6.toInt(),
        0xFF2121A6.toInt(), 0xFF6321A6.toInt(), 0xFFA621A6.toInt(), 0xFFA62163.toInt(), 0xFF660A0A.toInt(), 0xFF66380A.toInt(), 0xFF66660A.toInt(), 0xFF38660A.toInt(),
        0xFF0A660A.toInt(), 0xFF0A6638.toInt(), 0xFF0A6666.toInt(), 0xFF0A3866.toInt(), 0xFF0A0A66.toInt(), 0xFF380A66.toInt(), 0xFF660A66.toInt(), 0xFF660A38.toInt(),
        0xFFFFFFFF.toInt(), 0xFFE0E0E0.toInt(), 0xFFB8B8B8.toInt(), 0xFF8C8C8C.toInt(), 0xFF606060.toInt(), 0xFF404040.toInt(), 0xFF202020.toInt(), 0xFF000000.toInt()
    )
}
