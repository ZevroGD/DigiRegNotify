package personal.digiregnotify

import android.content.Context
import android.graphics.Color

object PaletteManager {

    data class Palette(
        val key: String,
        val displayName: String,
        val styleResId: Int,
        val previewPrimary: Int,
        val previewSecondary: Int
    )

    val palettes = listOf(
        Palette(
            "ledger", "Ledger", R.style.Theme_DigiRegNotify,
            Color.parseColor("#35507A"), Color.parseColor("#C98A3E")
        ),
        Palette(
            "harbor", "Harbor", R.style.Theme_DigiRegNotify_Harbor,
            Color.parseColor("#1F6F78"), Color.parseColor("#E0793E")
        ),
        Palette(
            "moss", "Moss", R.style.Theme_DigiRegNotify_Moss,
            Color.parseColor("#3F6B4A"), Color.parseColor("#C77B3E")
        ),
        Palette(
            "plum", "Plum", R.style.Theme_DigiRegNotify_Plum,
            Color.parseColor("#6E3B5C"), Color.parseColor("#D98A4E")
        ),
        Palette(
            "ember", "Ember", R.style.Theme_DigiRegNotify_Ember,
            Color.parseColor("#B45A2E"), Color.parseColor("#2E6E8E")
        )
    )

    private const val PREFS = "digireg_settings"
    private const val KEY = "palette_key"

    fun getSelectedKey(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "ledger") ?: "ledger"

    fun setSelectedKey(context: Context, key: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, key).apply()
    }

    fun getStyleResId(context: Context): Int =
        palettes.find { it.key == getSelectedKey(context) }?.styleResId
            ?: R.style.Theme_DigiRegNotify
}
