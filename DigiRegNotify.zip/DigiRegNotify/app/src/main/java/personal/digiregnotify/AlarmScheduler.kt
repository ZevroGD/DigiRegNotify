package personal.digiregnotify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.SystemClock

object AlarmScheduler {

    private const val REQUEST_CODE = 100
    private const val PREFS = "digireg_settings"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** The choices on the slider, in minutes. */
    val INTERVAL_STEPS_MINUTES = intArrayOf(15, 30, 60, 120, 180, 240, 360, 480, 720, 1440)

    fun setIntervalMinutes(context: Context, minutes: Int) {
        prefs(context).edit().putInt("interval_minutes", minutes).remove("interval_hours").apply()
    }

    /** The saved interval (default 2 hours). An older or odd value snaps to the nearest choice. */
    fun getIntervalMinutes(context: Context): Int {
        val p = prefs(context)
        val saved = if (p.contains("interval_minutes")) p.getInt("interval_minutes", 120)
        else p.getInt("interval_hours", 2) * 60
        val snapped = INTERVAL_STEPS_MINUTES.minByOrNull { Math.abs(it - saved) } ?: 120
        if (snapped != saved || !p.contains("interval_minutes")) setIntervalMinutes(context, snapped)
        return snapped
    }

    fun intervalLabel(minutes: Int): String = when {
        minutes < 60 -> "Every $minutes minutes"
        minutes == 60 -> "Every hour"
        else -> "Every ${minutes / 60} hours"
    }

    fun setPollingEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("polling_enabled", enabled).apply()
    }

    fun isPollingEnabled(context: Context): Boolean =
        prefs(context).getBoolean("polling_enabled", true) // on by default

    fun canScheduleExact(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = context.getSystemService(AlarmManager::class.java)
            return am.canScheduleExactAlarms()
        }
        return true
    }

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, CheckAlarmReceiver::class.java)
        return PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Schedules (or reschedules) the repeating check based on the saved interval.
     *  Does nothing if polling has been turned off in Settings. */
    fun scheduleRepeating(context: Context) {
        if (!isPollingEnabled(context)) return

        val am = context.getSystemService(AlarmManager::class.java)
        val intervalMillis = getIntervalMinutes(context) * 60L * 1000L
        val triggerAt = SystemClock.elapsedRealtime() + intervalMillis

        val pi = pendingIntent(context)
        DevLog.i("Alarm", "next check in ${getIntervalMinutes(context)} min (exact allowed: ${canScheduleExact(context)})")

        // setExactAndAllowWhileIdle fires once; the receiver reschedules the
        // next one itself, which is more reliable across Doze than a single
        // long-lived repeating alarm.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            // Fall back to an inexact alarm if the user hasn't granted the
            // "alarms & reminders" permission; still works, just less precise.
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
        }
    }

    /** True if a check alarm is currently queued. */
    fun isAlarmPending(context: Context): Boolean =
        PendingIntent.getBroadcast(
            context, REQUEST_CODE, Intent(context, CheckAlarmReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        ) != null

    /** Schedules the next check only if none is pending. Safe to call whenever the app is
     *  opened: it revives a chain that died (new APK installed, force-stop, etc.) without
     *  pushing back an alarm that's already waiting. */
    fun ensureScheduled(context: Context) {
        if (!isPollingEnabled(context)) return
        val pending = PendingIntent.getBroadcast(
            context, REQUEST_CODE, Intent(context, CheckAlarmReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending == null) scheduleRepeating(context)
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(AlarmManager::class.java)
        am.cancel(pendingIntent(context))
    }
}
