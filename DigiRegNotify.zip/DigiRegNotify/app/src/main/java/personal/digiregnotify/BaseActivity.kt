package personal.digiregnotify

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/** Every screen extends this so palette changes apply consistently everywhere. */
abstract class BaseActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(PaletteManager.getStyleResId(this))
        super.onCreate(savedInstanceState)
    }
}
