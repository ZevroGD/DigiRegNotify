package personal.digiregnotify

sealed class HomeworkRow {
    data class DateHeader(val label: String) : HomeworkRow()
    data class Item(val item: DashboardItem) : HomeworkRow()
    data class EmptyNote(val text: String) : HomeworkRow()
    /** Unread messages, shown at the very top — but as real rows, so they scroll away with
     *  everything else instead of staying pinned above the list. */
    data class UnreadMessage(val message: MessageSummary) : HomeworkRow()
}
