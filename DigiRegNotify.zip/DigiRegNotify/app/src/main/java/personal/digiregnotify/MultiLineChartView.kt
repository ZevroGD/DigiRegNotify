package personal.digiregnotify

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

data class ChartSeries(
    val subjectId: Int,
    val points: List<Pair<Long, Float>>, // (dateMillis, grade), oldest -> newest
    val color: Int,
    val strokeWidthDp: Float = 3f
)

/** Plots several subjects' grades on one shared timeline, each in its own color/thickness. */
class MultiLineChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var series: List<ChartSeries> = emptyList()
    private val density = resources.displayMetrics.density

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33888888")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    fun setSeries(newSeries: List<ChartSeries>) {
        series = newSeries
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val allPoints = series.flatMap { it.points }
        if (allPoints.isEmpty()) return

        val padding = 12f
        val w = width - padding * 2
        val h = height - padding * 2
        if (w <= 0 || h <= 0) return

        val minVal = 1f
        val maxVal = 10f
        val range = (maxVal - minVal).coerceAtLeast(0.01f)

        val minDate = allPoints.minOf { it.first }
        val maxDate = allPoints.maxOf { it.first }
        val dateRange = (maxDate - minDate).coerceAtLeast(1L)

        val midY = padding + h - ((5.5f - minVal) / range) * h
        canvas.drawLine(padding, midY, padding + w, midY, gridPaint)

        for (s in series) {
            if (s.points.isEmpty()) continue

            val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = s.color
                style = Paint.Style.STROKE
                strokeWidth = s.strokeWidthDp * density
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
            }
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = s.color
                style = Paint.Style.FILL
            }

            fun x(dateMillis: Long) = padding + ((dateMillis - minDate).toFloat() / dateRange) * w
            fun y(value: Float) = padding + h - ((value - minVal) / range) * h

            if (s.points.size == 1) {
                val (date, value) = s.points[0]
                canvas.drawCircle(x(date), y(value), (s.strokeWidthDp + 1f) * density / 2, dotPaint)
                continue
            }

            var prevX = x(s.points[0].first)
            var prevY = y(s.points[0].second)
            for (i in 1 until s.points.size) {
                val (date, value) = s.points[i]
                val cx = x(date)
                val cy = y(value)
                canvas.drawLine(prevX, prevY, cx, cy, linePaint)
                prevX = cx
                prevY = cy
            }
            for ((date, value) in s.points) {
                canvas.drawCircle(x(date), y(value), (s.strokeWidthDp + 1f) * density / 2, dotPaint)
            }
        }
    }
}
