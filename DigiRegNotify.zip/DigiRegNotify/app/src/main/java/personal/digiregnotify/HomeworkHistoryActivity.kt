package personal.digiregnotify

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Date

/**
 * The past month of homework, marks and teacher observations, newest day first. It uses the same request as the website's
 * history view (the dashboard with viewFuture = false) and the same rows as the Home screen,
 * so ticking things off and the edit info buttons work here too.
 */
class HomeworkHistoryActivity : BaseActivity() {

    private lateinit var adapter: HomeworkAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView

    private var items: List<DashboardItem> = emptyList()
    private var observationDetails: Map<Long, Observation> = emptyMap()
    private var searchQuery = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homework_history)

        swipeRefresh = findViewById(R.id.historySwipeRefresh)
        emptyText = findViewById(R.id.historyEmptyText)
        val recycler = findViewById<RecyclerView>(R.id.historyRecyclerView)

        adapter = HomeworkAdapter(
            emptyList(),
            onToggle = { item, value -> onToggled(item, value) },
            onOpenMessage = {},      // no message rows in the history
            onMarkMessageRead = {},
            onOpenSubmission = { s -> Attachments.open(this, s, isMessage = false) }
        )
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        findViewById<ImageButton>(R.id.historyBackButton).setOnClickListener { finish() }
        findViewById<TextInputEditText>(R.id.historySearchInput).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString().orEmpty()
                render()
            }
        })
        swipeRefresh.setOnRefreshListener { load() }

        load()
    }

    private fun load() {
        if (!RegisterApi(this).hasCredentials()) {
            emptyText.text = "Not signed in"
            return
        }
        if (!NetworkUtil.isConnected(this)) {
            emptyText.text = "No internet connection right now"
            swipeRefresh.isRefreshing = false
            return
        }
        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            val api = RegisterApi(this@HomeworkHistoryActivity)
            val json = api.fetchDashboardWithAutoLogin(viewFuture = false)
            val parsed = json?.let {
                try {
                    DashboardDiffer(this@HomeworkHistoryActivity).parseItems(it)
                        .filter { item -> item.type == "gradeGroup" || item.type == "grade" || item.type == "observation" }
                } catch (e: Exception) {
                    DevLog.w("History", "could not parse history", e)
                    null
                }
            }
            // The history only says "Beobachtung" for an observation; what was observed is on the
            // subject's page, so fetch it for the subjects that have observations.
            var details: Map<Long, Observation> = emptyMap()
            if (parsed != null && parsed.any { it.type == "observation" }) {
                try {
                    val subjectsJson = api.fetchAllSubjects()
                    if (subjectsJson != null) {
                        val subjects = AllSubjectsParser.parse(subjectsJson)
                        details = Observations.load(this@HomeworkHistoryActivity, subjects).associateBy { it.id }
                    }
                } catch (e: Exception) {
                    DevLog.w("History", "observation details failed", e)
                }
            }
            withContext(Dispatchers.Main) {
                observationDetails = details
                swipeRefresh.isRefreshing = false
                if (parsed == null) {
                    emptyText.text = ErrorText.friendly(api.lastError, "load the history")
                    Toast.makeText(this@HomeworkHistoryActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    return@withContext
                }
                items = parsed
                render()
            }
        }
    }

    private fun render() {
        val q = searchQuery.trim()
        // Observations show what was observed, with who entered it.
        val shown = items.map { item ->
            val detail = if (item.type == "observation") item.id.toLongOrNull()?.let { observationDetails[it] } else null
            if (detail == null) item else item.copy(
                subtitle = listOf(detail.text, detail.created).filter { it.isNotBlank() }.joinToString("\n")
            )
        }
        val filtered = if (q.isEmpty()) shown else shown.filter {
            it.title.contains(q, ignoreCase = true) || it.subtitle.contains(q, ignoreCase = true) ||
                SubjectNames.nameFor(this, it.label).contains(q, ignoreCase = true)
        }

        val history = ItemHistory.load(this)
        val rows = mutableListOf<HomeworkRow>()

        // Newest day first, with the items of one day kept in due-time order.
        val byDay = filtered
            .map { it to effectiveTime(it) }
            .filter { it.second != null }
            .groupBy { startOfDay(it.second!!).time }
            .toSortedMap(reverseOrder<Long>())
        // Homework that was deleted on a past day is still remembered for a while; show it on
        // that day (not while searching, and not for days that haven't passed yet).
        val todayStart = startOfDay(Date()).time
        val deletedByDay = if (q.isNotEmpty()) emptyMap<Long, List<DeletedHomework>>() else history.deleted
            .mapNotNull { d -> DueDateFormat.parse(d.deadline)?.let { startOfDay(it).time to d } }
            .filter { it.first < todayStart }
            .groupBy({ it.first }, { it.second })
        val days = (byDay.keys + deletedByDay.keys).toSortedSet(reverseOrder<Long>())
        for (dayMillis in days) {
            rows.add(HomeworkRow.DateHeader(DueDateFormat.dayLabel(Date(dayMillis)), deletedByDay[dayMillis] ?: emptyList()))
            (byDay[dayMillis] ?: emptyList()).sortedBy { it.second }.forEach { (item, _) ->
                rows.add(HomeworkRow.Item(item, history.versions["${item.type}:${item.id}"] ?: emptyList()))
            }
        }
        // Items without a due date go last.
        val undated = filtered.filter { effectiveTime(it) == null }
        if (undated.isNotEmpty()) {
            rows.add(HomeworkRow.DateHeader("No due date"))
            undated.forEach { rows.add(HomeworkRow.Item(it, history.versions["${it.type}:${it.id}"] ?: emptyList())) }
        }

        adapter.updateRows(rows)
        emptyText.visibility = if (rows.isEmpty()) TextView.VISIBLE else TextView.GONE
        emptyText.text = if (q.isNotEmpty()) "Nothing matches \"$q\"" else "Nothing found in the past month"
    }

    private fun onToggled(item: DashboardItem, value: Boolean) {
        CoroutineScope(Dispatchers.IO).launch {
            val api = RegisterApi(this@HomeworkHistoryActivity)
            val ok = api.toggleReminder(item.id, item.type, value)
            withContext(Dispatchers.Main) {
                if (ok) {
                    items = items.map {
                        if (it.id == item.id && it.type == item.type) it.copy(checked = value) else it
                    }
                } else {
                    Toast.makeText(
                        this@HomeworkHistoryActivity,
                        ErrorText.friendly(api.lastError, "update this"),
                        Toast.LENGTH_SHORT
                    ).show()
                }
                render() // resets every checkbox to the authoritative state
            }
        }
    }

    /** Homework: its due time. Marks and observations only have a day; they sort after that
     *  day's homework (end of day). */
    private fun effectiveTime(item: DashboardItem): Date? {
        DueDateFormat.parse(item.deadline)?.let { return it }
        val day = DueDateFormat.parseDay(item.date) ?: return null
        return Calendar.getInstance().apply {
            time = day
            set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59)
        }.time
    }

    private fun startOfDay(date: Date): Date =
        Calendar.getInstance().apply {
            time = date
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.time
}
