package personal.digiregnotify

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.ImageButton
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** The app's real home screen once signed in: today's and upcoming homework. */
class HomeworkActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var adapter: HomeworkAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView
    private lateinit var moreButton: ImageButton
    private lateinit var searchBarContainer: android.widget.LinearLayout
    private lateinit var searchInput: TextInputEditText

    private var allHomeworkItems: List<DashboardItem> = emptyList()
    private var unreadMessages: List<MessageSummary> = emptyList()
    private var activeCategory: String? = null // null = show all categories
    private var searchQuery: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homework)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.homeworkEmptyText)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        moreButton = findViewById(R.id.moreNavButton)
        searchBarContainer = findViewById(R.id.searchBarContainer)
        searchInput = findViewById(R.id.searchInput)

        val recyclerView = findViewById<RecyclerView>(R.id.homeworkRecyclerView)
        adapter = HomeworkAdapter(
            emptyList(),
            onToggle = { item, value -> onHomeworkToggled(item, value) },
            onOpenMessage = { message -> openMessage(message) },
            onMarkMessageRead = { message -> markMessageRead(message) }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<ImageButton>(R.id.messagesNavButton).setOnClickListener {
            startActivity(Intent(this, MessagesActivity::class.java))
        }
        moreButton.setOnClickListener { showMoreMenu() }
        findViewById<ImageButton>(R.id.searchNavButton).setOnClickListener { toggleSearchBar() }

        // Opened from a "new homework" notification: pre-apply its filter so the exact
        // item that was announced is what you land on.
        intent.getStringExtra(EXTRA_CATEGORY)?.let { activeCategory = it }
        intent.getStringExtra(EXTRA_SEARCH)?.let { query ->
            searchQuery = query
            searchInput.setText(query)
            searchBarContainer.visibility = android.view.View.VISIBLE
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString().orEmpty()
                render()
            }
        })

        swipeRefresh.setOnRefreshListener {
            loadHomework()
            loadUnreadMessages()
        }
        loadHomework()
        loadUnreadMessages()
    }

    /** Sort/Timetable/Marks/Settings, consolidated so the top bar can't overflow regardless
     *  of screen width — six separate buttons there was one too many. */
    private fun showMoreMenu() {
        val popup = PopupMenu(this, moreButton, Gravity.END)
        val sortLabel = if (activeCategory == null) "Sort" else "Sort: $activeCategory"
        popup.menu.add(0, 0, 0, sortLabel)
        popup.menu.add(0, 1, 1, "Timetable")
        popup.menu.add(0, 2, 2, "Marks")
        popup.menu.add(0, 3, 3, "Settings")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                0 -> showSortMenu()
                1 -> startActivity(Intent(this, TimetableActivity::class.java))
                2 -> startActivity(Intent(this, MarksActivity::class.java))
                3 -> startActivity(Intent(this, SettingsActivity::class.java))
            }
            true
        }
        popup.show()
    }

    private fun toggleSearchBar() {
        if (searchBarContainer.visibility == android.view.View.VISIBLE) {
            searchBarContainer.visibility = android.view.View.GONE
            searchInput.text?.clear()
            searchQuery = ""
            render()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
        } else {
            searchBarContainer.visibility = android.view.View.VISIBLE
            searchInput.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    override fun onResume() {
        super.onResume()
        // If the user signed out from Settings, bounce back to the login screen.
        if (!api.hasCredentials()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        loadUnreadMessages() // in case something was read on the Messages screen
    }

    private fun loadHomework() {
        if (!api.hasCredentials()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        if (!NetworkUtil.isConnected(this)) {
            swipeRefresh.isRefreshing = false
            emptyText.text = "No internet connection right now"
            emptyText.visibility = TextView.VISIBLE
            return
        }

        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            val dashboardJson = api.fetchDashboardWithAutoLogin()
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (dashboardJson == null) {
                    emptyText.text = ErrorText.friendly(api.lastError, "load homework")
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@HomeworkActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    return@withContext
                }

                val differ = DashboardDiffer(this@HomeworkActivity)
                val allItems = differ.parseItems(dashboardJson)
                allHomeworkItems = allItems.filter { it.type == "gradeGroup" }
                SubjectRegistry.recordCodes(this@HomeworkActivity, allHomeworkItems.map { it.label })

                render()
            }
        }
    }

    /** Shows a menu of categories actually present (e.g. Hausaufgabe, Prüfung) to filter by. */
    private fun showSortMenu() {
        val categories = allHomeworkItems
            .map { it.title.ifBlank { "Other" } }
            .distinct()
            .sorted()

        if (categories.isEmpty()) {
            Toast.makeText(this, "Nothing to sort yet", Toast.LENGTH_SHORT).show()
            return
        }

        val popup = PopupMenu(this, moreButton, Gravity.END)
        popup.menu.add(0, 0, 0, "All")
        categories.forEachIndexed { index, category ->
            popup.menu.add(0, index + 1, index + 1, category)
        }

        popup.setOnMenuItemClickListener { menuItem ->
            activeCategory = if (menuItem.itemId == 0) null else menuItem.title.toString()
            render()
            true
        }
        popup.show()
    }

    /** Applies the active category filter and search query, groups by due date, puts unread
     *  messages at the top as real rows (so they scroll away like everything else), and
     *  pushes the result to the adapter. */
    private fun render() {
        var filtered = if (activeCategory == null) {
            allHomeworkItems
        } else {
            allHomeworkItems.filter { it.title.ifBlank { "Other" } == activeCategory }
        }

        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim()
            filtered = filtered.filter {
                it.title.contains(q, ignoreCase = true) || it.subtitle.contains(q, ignoreCase = true)
            }
        }

        val messageRows = unreadMessages.map { HomeworkRow.UnreadMessage(it) }
        val rows = buildRows(filtered, fillEmptyDays = activeCategory == null && searchQuery.isBlank())
        adapter.updateRows(messageRows + rows)

        emptyText.visibility = if (filtered.isEmpty() && unreadMessages.isEmpty()) TextView.VISIBLE else TextView.GONE
        emptyText.text = when {
            allHomeworkItems.isEmpty() -> "No homework found"
            searchQuery.isNotBlank() -> "Nothing matches \"$searchQuery\""
            else -> "Nothing in this category"
        }
    }

    /** Sends a tick/untick to the server, then re-renders so every box shows the real state. */
    private fun onHomeworkToggled(item: DashboardItem, value: Boolean) {
        CoroutineScope(Dispatchers.IO).launch {
            val ok = api.toggleReminder(item.id, item.type, value)
            withContext(Dispatchers.Main) {
                if (ok) {
                    allHomeworkItems = allHomeworkItems.map {
                        if (it.id == item.id && it.type == item.type) it.copy(checked = value) else it
                    }
                } else {
                    Toast.makeText(
                        this@HomeworkActivity,
                        ErrorText.friendly(api.lastError, "update this"),
                        Toast.LENGTH_SHORT
                    ).show()
                }
                render()
            }
        }
    }

    /** Fills in every day from today through the furthest due date (capped) — but only for the
     *  full, unfiltered list. When searching or sorting, [fillEmptyDays] is false: a search for
     *  something due in a month shouldn't generate a month of "Nothing due" placeholder rows. */
    private fun buildRows(items: List<DashboardItem>, fillEmptyDays: Boolean): List<HomeworkRow> {
        val withDates = items.map { item -> item to DueDateFormat.parse(item.deadline) }
        val dated = withDates.filter { it.second != null }
        val undated = withDates.filter { it.second == null }.map { it.first }

        val rows = mutableListOf<HomeworkRow>()

        if (dated.isNotEmpty()) {
            if (fillEmptyDays) {
                val maxFilledDays = 14
                val today = startOfDay(java.util.Date())
                val maxDueDay = startOfDay(java.util.Date(dated.maxOf { it.second!!.time }))

                val daySpan = ((maxDueDay.time - today.time) / (24 * 60 * 60 * 1000)).toInt().coerceAtLeast(0)
                val filledSpan = daySpan.coerceAtMost(maxFilledDays)

                val cursor = java.util.Calendar.getInstance().apply { time = today }
                repeat(filledSpan + 1) {
                    val dayStart = startOfDay(cursor.time)
                    val dayEnd = dayStart.time + 24 * 60 * 60 * 1000
                    val dayItems = dated
                        .filter { it.second!!.time in dayStart.time until dayEnd }
                        .sortedBy { it.second!!.time }

                    rows.add(HomeworkRow.DateHeader(DueDateFormat.dayLabel(dayStart)))
                    if (dayItems.isEmpty()) {
                        rows.add(HomeworkRow.EmptyNote("Nothing due"))
                    } else {
                        dayItems.forEach { rows.add(HomeworkRow.Item(it.first)) }
                    }
                    cursor.add(java.util.Calendar.DAY_OF_YEAR, 1)
                }

                // Anything further out than the fill cap: still shown, just not
                // gap-filled day by day (avoids a huge list for a far-off item).
                if (daySpan > maxFilledDays) {
                    val beyondCutoff = cursor.timeInMillis
                    val beyond = dated
                        .filter { it.second!!.time >= beyondCutoff }
                        .sortedBy { it.second!!.time }
                    var lastLabel: String? = null
                    for ((item, date) in beyond) {
                        val label = DueDateFormat.dayLabel(date!!)
                        if (label != lastLabel) {
                            rows.add(HomeworkRow.DateHeader(label))
                            lastLabel = label
                        }
                        rows.add(HomeworkRow.Item(item))
                    }
                }
            } else {
                // Filtered view: just group by the days that actually have a match.
                val sorted = dated.sortedBy { it.second!!.time }
                var lastLabel: String? = null
                for ((item, date) in sorted) {
                    val label = DueDateFormat.dayLabel(date!!)
                    if (label != lastLabel) {
                        rows.add(HomeworkRow.DateHeader(label))
                        lastLabel = label
                    }
                    rows.add(HomeworkRow.Item(item))
                }
            }
        }

        if (undated.isNotEmpty()) {
            rows.add(HomeworkRow.DateHeader("No due date"))
            undated.forEach { rows.add(HomeworkRow.Item(it)) }
        }

        return rows
    }

    private fun startOfDay(date: java.util.Date): java.util.Date {
        val cal = java.util.Calendar.getInstance()
        cal.time = date
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.time
    }

    private fun loadUnreadMessages() {
        if (!api.hasCredentials() || !NetworkUtil.isConnected(this)) return

        CoroutineScope(Dispatchers.IO).launch {
            val json = api.fetchMessages()
            val unread = if (json != null) {
                try {
                    MessageParser.parse(json).filter { it.isUnread }
                } catch (e: Exception) {
                    emptyList()
                }
            } else {
                emptyList()
            }
            withContext(Dispatchers.Main) {
                unreadMessages = unread
                render()
            }
        }
    }

    /** Shows the full message and marks it read — same behavior as opening it in Messages. */
    private fun openMessage(message: MessageSummary) {
        MaterialAlertDialogBuilder(this)
            .setTitle(message.subject.ifBlank { "(no subject)" })
            .setMessage("${message.fromName}\n\n${message.fullBody.ifBlank { "(empty message)" }}")
            .setPositiveButton("OK", null)
            .show()
        markMessageRead(message)
    }

    private fun markMessageRead(message: MessageSummary) {
        CoroutineScope(Dispatchers.IO).launch {
            val ok = api.markMessageAsRead(message.id)
            withContext(Dispatchers.Main) {
                if (ok) {
                    unreadMessages = unreadMessages.filter { it.id != message.id }
                    render()
                } else {
                    Toast.makeText(
                        this@HomeworkActivity,
                        ErrorText.friendly(api.lastError, "mark this as read"),
                        Toast.LENGTH_SHORT
                    ).show()
                    render() // re-enable the button row
                }
            }
        }
    }

    companion object {
        const val EXTRA_CATEGORY = "category"
        const val EXTRA_SEARCH = "search"
    }
}
