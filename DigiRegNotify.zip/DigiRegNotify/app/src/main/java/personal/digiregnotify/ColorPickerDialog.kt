package personal.digiregnotify

import android.app.Activity
import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.SeekBar
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** A free single-color picker: hue / saturation / brightness sliders or a hex code, with a
 *  live preview. (CustomThemeDialog is the two-color version used for the app theme.) */
object ColorPickerDialog {

    fun show(activity: Activity, title: String, initial: Int, onPicked: (Int) -> Unit) {
        val view = activity.layoutInflater.inflate(R.layout.dialog_custom_theme, null)
        // This layout also serves the two-color theme picker; here only one color is edited.
        view.findViewById<View>(R.id.customColorToggle).visibility = View.GONE
        view.findViewById<View>(R.id.customPreviewSecondary).visibility = View.GONE
        val preview = view.findViewById<View>(R.id.customPreviewPrimary)
        val hue = view.findViewById<SeekBar>(R.id.customHue)
        val sat = view.findViewById<SeekBar>(R.id.customSaturation)
        val bri = view.findViewById<SeekBar>(R.id.customBrightness)
        val hex = view.findViewById<EditText>(R.id.customHex)

        var color = initial or 0xFF000000.toInt()
        var updating = false

        fun showHex() { hex.setText(String.format("#%06X", color and 0xFFFFFF)) }

        fun loadSliders() {
            val hsv = FloatArray(3)
            Color.colorToHSV(color, hsv)
            hue.progress = hsv[0].toInt()
            sat.progress = (hsv[1] * 100).toInt()
            bri.progress = (hsv[2] * 100).toInt()
        }

        val sliders = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (updating) return
                color = Color.HSVToColor(
                    floatArrayOf(hue.progress.toFloat(), sat.progress / 100f, bri.progress / 100f)
                )
                updating = true
                showHex()
                updating = false
                preview.setBackgroundColor(color)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
        hue.setOnSeekBarChangeListener(sliders)
        sat.setOnSeekBarChangeListener(sliders)
        bri.setOnSeekBarChangeListener(sliders)

        hex.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (updating) return
                val text = s.toString().trimStart('#')
                if (text.length != 6) return // wait until a full code is typed
                color = try {
                    Color.parseColor("#$text")
                } catch (e: Exception) {
                    return
                }
                updating = true
                loadSliders()
                updating = false
                preview.setBackgroundColor(color)
            }
        })

        updating = true
        loadSliders()
        showHex()
        updating = false
        preview.setBackgroundColor(color)

        SlideDialogBuilder(activity)
            .setTitle(title)
            .setView(view)
            .setPositiveButton("Save") { _, _ -> onPicked(color) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
