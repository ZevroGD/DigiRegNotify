package personal.digiregnotify

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class ChangeLogActivity : BaseActivity() {

    private lateinit var adapter: ChangeLogAdapter
    private lateinit var emptyText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_log)

        emptyText = findViewById(R.id.changeLogEmptyText)
        val recyclerView = findViewById<RecyclerView>(R.id.changeLogRecyclerView)
        adapter = ChangeLogAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<ImageButton>(R.id.changeLogBackButton).setOnClickListener { finish() }
        findViewById<TextView>(R.id.changeLogClearButton).setOnClickListener { confirmClear() }

        render()
    }

    private fun render() {
        val entries = ChangeLog.getAll(this)
        adapter.updateEntries(entries)
        emptyText.visibility = if (entries.isEmpty()) TextView.VISIBLE else TextView.GONE
    }

    private fun confirmClear() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Clear change history?")
            .setMessage("This only clears what you can see here — it doesn't affect your actual grades or homework.")
            .setPositiveButton("Clear") { _, _ ->
                ChangeLog.clear(this)
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
