package personal.digiregnotify

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChangeLogAdapter(private var entries: List<ChangeLogEntry>) :
    RecyclerView.Adapter<ChangeLogAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val badge: TextView = view.findViewById(R.id.changeLogTypeBadge)
        val summary: TextView = view.findViewById(R.id.changeLogSummary)
        val time: TextView = view.findViewById(R.id.changeLogTime)
    }

    fun updateEntries(newEntries: List<ChangeLogEntry>) {
        entries = newEntries
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_change_log_entry, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = entries[position]
        val kindLabel = if (entry.itemType == "grade") "Grade" else "Homework"

        holder.badge.text = if (entry.type == "deleted") "Deleted" else "Changed"
        val badgeColor = if (entry.type == "deleted") Color.parseColor("#A23B3B") else Color.parseColor("#C98A3E")
        (holder.badge.background.mutate() as GradientDrawable).setColor(badgeColor)

        holder.summary.text = "$kindLabel — ${entry.summary}"
        holder.time.text = DateUtils.getRelativeTimeSpanString(
            entry.timestamp, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
        )
    }

    override fun getItemCount(): Int = entries.size
}
