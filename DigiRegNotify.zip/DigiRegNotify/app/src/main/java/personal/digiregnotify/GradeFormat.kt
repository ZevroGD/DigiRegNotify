package personal.digiregnotify

import java.util.Locale

/**
 * How a single mark is written, as on the school's own marking scale:
 * 6.5 -> "6/7", 8.25 -> "8+", 9.75 -> "10-", whole marks stay "8".
 * (Averages are not marks and stay plain numbers.)
 */
object GradeFormat {
    fun format(value: Float): String {
        val quarter = Math.round(value * 4) / 4f
        if (Math.abs(value - quarter) > 0.01f) {
            // Not a quarter step (unexpected): show the number itself, without trailing zeros.
            return String.format(Locale.getDefault(), "%.2f", value).trimEnd('0').trimEnd('.', ',')
        }
        val whole = Math.floor(quarter.toDouble()).toInt()
        val fraction = quarter - whole
        return when {
            fraction < 0.01f -> "$whole"
            fraction < 0.375f -> "$whole+"            // .25
            fraction < 0.625f -> "$whole/${whole + 1}" // .5
            else -> "${whole + 1}-"                    // .75
        }
    }

    /** Same for a mark that arrives as text (e.g. "9.00"); unreadable text is returned as is. */
    fun format(raw: String): String = raw.toFloatOrNull()?.let { format(it) } ?: raw
}
