## What's new

**Changed**
- Updates work without any setup. The GitHub token under "GitHub access" is optional and only raises GitHub's request limit, and the dialog has a button that opens the token page.
- Buttons on the Marks screen now use the same press animation as "Check now".
- The app is no longer marked as debuggable.
- Timetable notifications only appear when an hour changes to another subject (swapped or replaced), and show the before and after. Room, teacher and substitute changes no longer notify.
- The Custom colors preview shows exactly the colour you pick. The app still uses the closest prepared colour behind the scenes.
- Check frequency goes down to 15 minutes. The slider now has ten clear steps (15 min, 30 min, 1, 2, 3, 4, 6, 8, 12 and 24 hours). A saved in-between value moves to the nearest step.
- The last check and last background check moved from Settings to the Developer menu.
