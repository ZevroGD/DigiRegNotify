package personal.digiregnotify

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Lets the user pick the Custom palette's primary and secondary color (hue / saturation /
 *  brightness sliders or a hex code) with a live preview. Save selects the Custom palette. */
object CustomThemeDialog {

    fun show(activity: Activity, onSaved: () -> Unit) {
        if (!PaletteManager.isCustomSupported()) {
            Toast.makeText(activity, "Custom colors need Android 11 or newer", Toast.LENGTH_LONG).show()
            return
        }

        val view = activity.layoutInflater.inflate(R.layout.dialog_custom_theme, null)
        val previewPrimary = view.findViewById<View>(R.id.customPreviewPrimary)
        val previewSecondary = view.findViewById<View>(R.id.customPreviewSecondary)
        val toggle = view.findViewById<MaterialButtonToggleGroup>(R.id.customColorToggle)
        val hue = view.findViewById<SeekBar>(R.id.customHue)
        val sat = view.findViewById<SeekBar>(R.id.customSaturation)
        val bri = view.findViewById<SeekBar>(R.id.customBrightness)
        val hex = view.findViewById<EditText>(R.id.customHex)

        val colors = intArrayOf(
            PaletteManager.getCustomPrimary(activity),
            PaletteManager.getCustomSecondary(activity)
        )
        var editing = 0
        var updating = false // stops the sliders and the hex field from feeding each other

        fun refreshPreview() {
            previewPrimary.setBackgroundColor(colors[0])
            (previewSecondary.background.mutate() as GradientDrawable).setColor(colors[1])
        }

        fun loadControls() {
            updating = true
            val hsv = FloatArray(3)
            Color.colorToHSV(colors[editing], hsv)
            hue.progress = hsv[0].toInt()
            sat.progress = (hsv[1] * 100).toInt()
            bri.progress = (hsv[2] * 100).toInt()
            hex.setText(String.format("#%06X", colors[editing] and 0xFFFFFF))
            updating = false
        }

        val sliderListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (updating) return
                val color = Color.HSVToColor(
                    floatArrayOf(hue.progress.toFloat(), sat.progress / 100f, bri.progress / 100f)
                )
                colors[editing] = color
                updating = true
                hex.setText(String.format("#%06X", color and 0xFFFFFF))
                updating = false
                refreshPreview()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
        hue.setOnSeekBarChangeListener(sliderListener)
        sat.setOnSeekBarChangeListener(sliderListener)
        bri.setOnSeekBarChangeListener(sliderListener)

        hex.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (updating) return
                val parsed = try {
                    Color.parseColor(if (s.toString().startsWith("#")) s.toString() else "#$s")
                } catch (e: Exception) {
                    return // incomplete or invalid: wait for more typing
                }
                if (s.toString().trimStart('#').length != 6) return
                colors[editing] = parsed or 0xFF000000.toInt()
                val hsv = FloatArray(3)
                Color.colorToHSV(colors[editing], hsv)
                updating = true
                hue.progress = hsv[0].toInt()
                sat.progress = (hsv[1] * 100).toInt()
                bri.progress = (hsv[2] * 100).toInt()
                updating = false
                refreshPreview()
            }
        })

        toggle.check(R.id.customEditPrimary)
        toggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            editing = if (checkedId == R.id.customEditPrimary) 0 else 1
            loadControls()
        }

        refreshPreview()
        loadControls()

        MaterialAlertDialogBuilder(activity)
            .setTitle("Custom colors")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                PaletteManager.setCustomColors(activity, colors[0], colors[1])
                PaletteManager.setSelectedKey(activity, PaletteManager.CUSTOM_KEY)
                onSaved()
            }
            .setNeutralButton("Reset") { _, _ ->
                PaletteManager.setCustomColors(
                    activity, PaletteManager.DEFAULT_CUSTOM_PRIMARY, PaletteManager.DEFAULT_CUSTOM_SECONDARY
                )
                PaletteManager.setSelectedKey(activity, PaletteManager.CUSTOM_KEY)
                onSaved()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
