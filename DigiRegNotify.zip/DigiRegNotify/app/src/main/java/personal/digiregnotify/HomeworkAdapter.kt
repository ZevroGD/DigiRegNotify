package personal.digiregnotify

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox

private const val VIEW_TYPE_HEADER = 0
private const val VIEW_TYPE_ITEM = 1
private const val VIEW_TYPE_EMPTY = 2
private const val VIEW_TYPE_MESSAGE = 3

/**
 * [onToggle] is called when the user ticks/unticks an item. The owner talks to the server and
 * then re-renders the list, which resets every checkbox to the authoritative state, so a
 * failed request simply snaps the box back. [onOpenMessage]/[onMarkMessageRead] do the same
 * job for the unread-message rows at the top of the list.
 */
class HomeworkAdapter(
    private var rows: List<HomeworkRow>,
    private val onToggle: (DashboardItem, Boolean) -> Unit,
    private val onOpenMessage: (MessageSummary) -> Unit,
    private val onMarkMessageRead: (MessageSummary) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    class HeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val label: TextView = view as TextView
    }

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val checkbox: MaterialCheckBox = view.findViewById(R.id.itemCheckbox)
        val subjectBadge: TextView = view.findViewById(R.id.itemSubjectBadge)
        val category: TextView = view.findViewById(R.id.itemCategory)
        val subject: TextView = view.findViewById(R.id.itemSubject)
    }

    class EmptyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view as TextView
    }

    class MessageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val from: TextView = view.findViewById(R.id.unreadRowFrom)
        val subject: TextView = view.findViewById(R.id.unreadRowSubject)
        val openButton: MaterialButton = view.findViewById(R.id.unreadRowOpenButton)
        val markReadButton: MaterialButton = view.findViewById(R.id.unreadRowMarkReadButton)
    }

    fun updateRows(newRows: List<HomeworkRow>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int =
        when (rows[position]) {
            is HomeworkRow.DateHeader -> VIEW_TYPE_HEADER
            is HomeworkRow.Item -> VIEW_TYPE_ITEM
            is HomeworkRow.EmptyNote -> VIEW_TYPE_EMPTY
            is HomeworkRow.UnreadMessage -> VIEW_TYPE_MESSAGE
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            VIEW_TYPE_HEADER -> HeaderViewHolder(inflater.inflate(R.layout.item_homework_header, parent, false))
            VIEW_TYPE_EMPTY -> EmptyViewHolder(inflater.inflate(R.layout.item_homework_empty, parent, false))
            VIEW_TYPE_MESSAGE -> MessageViewHolder(inflater.inflate(R.layout.item_unread_message_row, parent, false))
            else -> ItemViewHolder(inflater.inflate(R.layout.item_homework, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is HomeworkRow.DateHeader -> {
                (holder as HeaderViewHolder).label.text = row.label
            }
            is HomeworkRow.EmptyNote -> {
                (holder as EmptyViewHolder).text.text = row.text
            }
            is HomeworkRow.UnreadMessage -> {
                val h = holder as MessageViewHolder
                val message = row.message
                h.from.text = message.fromName.ifBlank { "Unknown sender" }
                h.subject.text = message.subject.ifBlank { "(no subject)" }
                h.openButton.setOnClickListener { onOpenMessage(message) }
                h.markReadButton.setOnClickListener {
                    h.markReadButton.isEnabled = false
                    onMarkMessageRead(message)
                }
            }
            is HomeworkRow.Item -> {
                val h = holder as ItemViewHolder
                val item = row.item
                val context = h.itemView.context

                // "label" is the school's own subject code (verified against the marks
                // endpoint). Shown as its custom name/color if set in Settings, else the
                // raw code with the default palette color.
                val code = item.label.ifBlank { null }
                if (code != null) {
                    h.subjectBadge.text = SubjectNames.nameFor(context, code)
                    h.subjectBadge.visibility = View.VISIBLE
                    val color = SubjectColors.colorForCode(context, code)
                    (h.subjectBadge.background.mutate() as GradientDrawable).setColor(color)
                    h.subjectBadge.setTextColor(SubjectColors.readableTextColor(color))
                } else {
                    h.subjectBadge.visibility = View.GONE
                }

                h.category.text = item.title.ifBlank { "Item" }
                h.subject.text = item.subtitle.ifBlank { "(no description)" }

                h.checkbox.setOnCheckedChangeListener(null)
                h.checkbox.isChecked = item.checked
                h.checkbox.isEnabled = item.checkable
                h.checkbox.setOnCheckedChangeListener { box, isChecked ->
                    box.isEnabled = false // until the server answers and the list re-renders
                    onToggle(item, isChecked)
                }
            }
        }
    }

    override fun getItemCount(): Int = rows.size
}
