package personal.digiregnotify

import android.content.Context
import android.graphics.Color

object SubjectColors {

    // A fixed, visually distinct palette, cycled through in subject order.
    private val palette = listOf(
        "#C98A3E", "#35507A", "#4B7A51", "#A23B3B", "#6E3B5C",
        "#1F6F78", "#B45A2E", "#7C9CCF", "#8FBF9B", "#D98A4E"
    ).map { Color.parseColor(it) }

    private const val PREFS = "digireg_subject_colors"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Stable color for a subject: a saved override if one is set later in Settings,
     *  otherwise a palette color chosen deterministically from the subject id. */
    fun colorFor(context: Context, subjectId: Int): Int {
        val saved = prefs(context).getInt("subject_$subjectId", Int.MIN_VALUE)
        if (saved != Int.MIN_VALUE) return saved
        val index = ((subjectId % palette.size) + palette.size) % palette.size
        return palette[index]
    }

    fun setColorFor(context: Context, subjectId: Int, color: Int) {
        prefs(context).edit().putInt("subject_$subjectId", color).apply()
    }
}
