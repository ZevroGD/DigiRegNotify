package personal.digiregnotify

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class DashboardItem(
    val id: String,
    val type: String,
    val title: String,
    val subtitle: String
)

/**
 * Remembers which dashboard item ids we've already seen, so we can figure
 * out which ones are new since the last check.
 */
class DashboardDiffer(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("digireg_seen_items", Context.MODE_PRIVATE)

    /** Parses the dashboard JSON (an array, or an array-of-groups) into a flat item list. */
    fun parseItems(dashboardJson: String): List<DashboardItem> {
        val items = mutableListOf<DashboardItem>()
        val root = JSONArray(dashboardJson)
        for (i in 0 until root.length()) {
            val group = root.optJSONObject(i) ?: continue
            val groupItems = group.optJSONArray("items") ?: continue
            for (j in 0 until groupItems.length()) {
                val item = groupItems.optJSONObject(j) ?: continue
                items.add(
                    DashboardItem(
                        id = item.optString("id", item.optString("category", "")),
                        type = item.optString("type", ""),
                        title = item.optString("title", ""),
                        subtitle = item.optString("subtitle", "")
                    )
                )
            }
        }
        return items
    }

    /** Returns only the items not seen on a previous check, then remembers all current items. */
    fun findNewItems(items: List<DashboardItem>): List<DashboardItem> {
        val seen = prefs.getStringSet("seen_ids", emptySet()) ?: emptySet()
        val isFirstRun = seen.isEmpty()

        val newItems = items.filter { it.id !in seen }

        val editor = prefs.edit()
        editor.putStringSet("seen_ids", items.map { it.id }.toSet())
        editor.apply()

        // Don't spam a notification for every existing item on the very first run.
        return if (isFirstRun) emptyList() else newItems
    }
}
