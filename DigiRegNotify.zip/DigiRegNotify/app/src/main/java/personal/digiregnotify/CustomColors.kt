package personal.digiregnotify

/**
 * The prepared colours behind the Custom theme: 24 hues in 8 tones, plus 12 greys (204 in all).
 * A theme can't take colours chosen at runtime, so each of these has a ready-made overlay style
 * (res/values/custom_palette.xml, generated from this same list). Whatever colour the user
 * picks is matched to the closest one of these.
 */
object CustomColors {
    const val DEFAULT_PRIMARY_ARGB = 0xFF2A5CAA.toInt()   // a deep blue
    const val DEFAULT_SECONDARY_ARGB = 0xFFF28C28.toInt() // an orange

    val argb: IntArray = intArrayOf(
        0xFFFFB2B2.toInt(), 0xFFFFC6B2.toInt(), 0xFFFFD9B2.toInt(), 0xFFFFECB2.toInt(), 0xFFFFFFB2.toInt(), 0xFFECFFB2.toInt(), 0xFFD9FFB2.toInt(), 0xFFC6FFB2.toInt(),
        0xFFB2FFB2.toInt(), 0xFFB2FFC6.toInt(), 0xFFB2FFD9.toInt(), 0xFFB2FFEC.toInt(), 0xFFB2FFFF.toInt(), 0xFFB2ECFF.toInt(), 0xFFB2D9FF.toInt(), 0xFFB2C6FF.toInt(),
        0xFFB2B2FF.toInt(), 0xFFC6B2FF.toInt(), 0xFFD9B2FF.toInt(), 0xFFECB2FF.toInt(), 0xFFFFB2FF.toInt(), 0xFFFFB2EC.toInt(), 0xFFFFB2D9.toInt(), 0xFFFFB2C6.toInt(),
        0xFFF27979.toInt(), 0xFFF29779.toInt(), 0xFFF2B679.toInt(), 0xFFF2D479.toInt(), 0xFFF2F279.toInt(), 0xFFD4F279.toInt(), 0xFFB6F279.toInt(), 0xFF97F279.toInt(),
        0xFF79F279.toInt(), 0xFF79F297.toInt(), 0xFF79F2B6.toInt(), 0xFF79F2D4.toInt(), 0xFF79F2F2.toInt(), 0xFF79D4F2.toInt(), 0xFF79B6F2.toInt(), 0xFF7997F2.toInt(),
        0xFF7979F2.toInt(), 0xFF9779F2.toInt(), 0xFFB679F2.toInt(), 0xFFD479F2.toInt(), 0xFFF279F2.toInt(), 0xFFF279D4.toInt(), 0xFFF279B6.toInt(), 0xFFF27997.toInt(),
        0xFFE04F4F.toInt(), 0xFFE0734F.toInt(), 0xFFE0974F.toInt(), 0xFFE0BC4F.toInt(), 0xFFE0E04F.toInt(), 0xFFBCE04F.toInt(), 0xFF97E04F.toInt(), 0xFF73E04F.toInt(),
        0xFF4FE04F.toInt(), 0xFF4FE073.toInt(), 0xFF4FE097.toInt(), 0xFF4FE0BC.toInt(), 0xFF4FE0E0.toInt(), 0xFF4FBCE0.toInt(), 0xFF4F97E0.toInt(), 0xFF4F73E0.toInt(),
        0xFF4F4FE0.toInt(), 0xFF734FE0.toInt(), 0xFF974FE0.toInt(), 0xFFBC4FE0.toInt(), 0xFFE04FE0.toInt(), 0xFFE04FBC.toInt(), 0xFFE04F97.toInt(), 0xFFE04F73.toInt(),
        0xFFCC2929.toInt(), 0xFFCC5229.toInt(), 0xFFCC7A29.toInt(), 0xFFCCA329.toInt(), 0xFFCCCC29.toInt(), 0xFFA3CC29.toInt(), 0xFF7ACC29.toInt(), 0xFF52CC29.toInt(),
        0xFF29CC29.toInt(), 0xFF29CC52.toInt(), 0xFF29CC7A.toInt(), 0xFF29CCA3.toInt(), 0xFF29CCCC.toInt(), 0xFF29A3CC.toInt(), 0xFF297ACC.toInt(), 0xFF2952CC.toInt(),
        0xFF2929CC.toInt(), 0xFF5229CC.toInt(), 0xFF7A29CC.toInt(), 0xFFA329CC.toInt(), 0xFFCC29CC.toInt(), 0xFFCC29A3.toInt(), 0xFFCC297A.toInt(), 0xFFCC2952.toInt(),
        0xFFB20E0E.toInt(), 0xFFB2370E.toInt(), 0xFFB2600E.toInt(), 0xFFB2890E.toInt(), 0xFFB2B20E.toInt(), 0xFF89B20E.toInt(), 0xFF60B20E.toInt(), 0xFF37B20E.toInt(),
        0xFF0EB20E.toInt(), 0xFF0EB237.toInt(), 0xFF0EB260.toInt(), 0xFF0EB289.toInt(), 0xFF0EB2B2.toInt(), 0xFF0E89B2.toInt(), 0xFF0E60B2.toInt(), 0xFF0E37B2.toInt(),
        0xFF0E0EB2.toInt(), 0xFF370EB2.toInt(), 0xFF600EB2.toInt(), 0xFF890EB2.toInt(), 0xFFB20EB2.toInt(), 0xFFB20E89.toInt(), 0xFFB20E60.toInt(), 0xFFB20E37.toInt(),
        0xFF940000.toInt(), 0xFF942500.toInt(), 0xFF944A00.toInt(), 0xFF946F00.toInt(), 0xFF949400.toInt(), 0xFF6F9400.toInt(), 0xFF4A9400.toInt(), 0xFF259400.toInt(),
        0xFF009400.toInt(), 0xFF009425.toInt(), 0xFF00944A.toInt(), 0xFF00946F.toInt(), 0xFF009494.toInt(), 0xFF006F94.toInt(), 0xFF004A94.toInt(), 0xFF002594.toInt(),
        0xFF000094.toInt(), 0xFF250094.toInt(), 0xFF4A0094.toInt(), 0xFF6F0094.toInt(), 0xFF940094.toInt(), 0xFF94006F.toInt(), 0xFF94004A.toInt(), 0xFF940025.toInt(),
        0xFF6B0B0B.toInt(), 0xFF6B230B.toInt(), 0xFF6B3B0B.toInt(), 0xFF6B530B.toInt(), 0xFF6B6B0B.toInt(), 0xFF536B0B.toInt(), 0xFF3B6B0B.toInt(), 0xFF236B0B.toInt(),
        0xFF0B6B0B.toInt(), 0xFF0B6B23.toInt(), 0xFF0B6B3B.toInt(), 0xFF0B6B53.toInt(), 0xFF0B6B6B.toInt(), 0xFF0B536B.toInt(), 0xFF0B3B6B.toInt(), 0xFF0B236B.toInt(),
        0xFF0B0B6B.toInt(), 0xFF230B6B.toInt(), 0xFF3B0B6B.toInt(), 0xFF530B6B.toInt(), 0xFF6B0B6B.toInt(), 0xFF6B0B53.toInt(), 0xFF6B0B3B.toInt(), 0xFF6B0B23.toInt(),
        0xFF471212.toInt(), 0xFF471F12.toInt(), 0xFF472D12.toInt(), 0xFF473A12.toInt(), 0xFF474712.toInt(), 0xFF3A4712.toInt(), 0xFF2D4712.toInt(), 0xFF1F4712.toInt(),
        0xFF124712.toInt(), 0xFF12471F.toInt(), 0xFF12472D.toInt(), 0xFF12473A.toInt(), 0xFF124747.toInt(), 0xFF123A47.toInt(), 0xFF122D47.toInt(), 0xFF121F47.toInt(),
        0xFF121247.toInt(), 0xFF1F1247.toInt(), 0xFF2D1247.toInt(), 0xFF3A1247.toInt(), 0xFF471247.toInt(), 0xFF47123A.toInt(), 0xFF47122D.toInt(), 0xFF47121F.toInt(),
        0xFFFFFFFF.toInt(), 0xFFE8E8E8.toInt(), 0xFFD0D0D0.toInt(), 0xFFB8B8B8.toInt(), 0xFFA0A0A0.toInt(), 0xFF888888.toInt(), 0xFF707070.toInt(), 0xFF585858.toInt(),
        0xFF404040.toInt(), 0xFF2C2C2C.toInt(), 0xFF181818.toInt(), 0xFF000000.toInt()
    )

    /** Index of the prepared colour closest to [color] (a weighted RGB distance, which
     *  follows how the eye sees differences better than plain RGB does). */
    fun nearestIndex(color: Int): Int {
        val r1 = (color shr 16) and 0xFF
        val g1 = (color shr 8) and 0xFF
        val b1 = color and 0xFF
        var best = 0
        var bestDistance = Double.MAX_VALUE
        for (i in argb.indices) {
            val c = argb[i]
            val r2 = (c shr 16) and 0xFF
            val g2 = (c shr 8) and 0xFF
            val b2 = c and 0xFF
            val rMean = (r1 + r2) / 2.0
            val dr = (r1 - r2).toDouble()
            val dg = (g1 - g2).toDouble()
            val db = (b1 - b2).toDouble()
            val distance = (2 + rMean / 256) * dr * dr + 4 * dg * dg + (2 + (255 - rMean) / 256) * db * db
            if (distance < bestDistance) {
                bestDistance = distance
                best = i
            }
        }
        return best
    }
}
