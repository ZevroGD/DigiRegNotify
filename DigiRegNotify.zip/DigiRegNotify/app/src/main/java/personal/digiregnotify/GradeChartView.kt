package personal.digiregnotify

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import com.google.android.material.R as MaterialR

/**
 * A minimal line chart for plotting a subject's grades over time.
 * Deliberately dependency-free (just Canvas) so it can't break the build.
 * Colors are resolved from the active theme so it follows palette changes.
 */
class GradeChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var values: List<Float> = emptyList()
    private val density = resources.displayMetrics.density

    /**
     * Adds a reference: grade lines with numbers down the left (like the big chart) and each
     * mark's value written by its dot. Off for the tiny charts, which stay plain lines.
     */
    var showAxis = false
        set(value) {
            field = value
            invalidate()
        }

    private val onSurface: Int by lazy {
        com.google.android.material.color.MaterialColors.getColor(this, MaterialR.attr.colorOnSurface, Color.GRAY)
    }
    private val axisTextPaint by lazy {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = onSurface
            alpha = 160
            textSize = 10f * density
            textAlign = Paint.Align.RIGHT
        }
    }
    private val valueTextPaint by lazy {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = onSurface
            alpha = 210
            textSize = 10f * density
            textAlign = Paint.Align.CENTER
        }
    }

    private fun resolveThemeColor(attrResId: Int, fallback: Int): Int {
        val typedValue = TypedValue()
        return if (context.theme.resolveAttribute(attrResId, typedValue, true)) {
            typedValue.data
        } else {
            fallback
        }
    }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = resolveThemeColor(MaterialR.attr.colorSecondary, Color.parseColor("#C98A3E"))
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = resolveThemeColor(MaterialR.attr.colorPrimary, Color.parseColor("#35507A"))
        style = Paint.Style.FILL
    }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33888888")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    fun setValues(newValues: List<Float>) {
        values = newValues
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (values.isEmpty()) return

        val padding = 12f
        val left = if (showAxis) 24f * density else padding
        val top = if (showAxis) 16f * density else padding
        val bottom = if (showAxis) 8f * density else padding
        val w = width - left - padding
        val h = height - top - bottom
        if (w <= 0 || h <= 0) return

        // Without the axis the scale is the fixed 1–10 (adjust if your school uses a different
        // scale). With it, only the part the marks actually cover is shown: marks from 7+ to 9-
        // give a chart from 7 to 9.
        var minVal = 1f
        var maxVal = 10f
        if (showAxis) {
            val lowest = values.minOrNull() ?: 1f
            val highest = values.maxOrNull() ?: 10f
            minVal = Math.floor(lowest.toDouble()).toFloat()
            maxVal = Math.ceil(highest.toDouble()).toFloat()
            if (maxVal - minVal < 1f) { // all marks the same whole number: a little room each side
                minVal -= 1f
                maxVal += 1f
            }
            if (maxVal > 10f) { maxVal = 10f; minVal = minOf(minVal, 9f) }
            if (minVal < 1f) { minVal = 1f; maxVal = maxOf(maxVal, 2f) }
        }
        val range = (maxVal - minVal).coerceAtLeast(0.01f)

        fun yFor(v: Float) = top + h - ((v - minVal) / range) * h

        if (showAxis) {
            // A line and a number at every whole grade, or every 2nd/5th when they'd be too close.
            val maxLines = (h / density / 14f).toInt() + 1
            val span = maxVal - minVal
            val step = listOf(1, 2, 5).firstOrNull { span / it + 1 <= maxLines } ?: 5
            var g = Math.ceil((minVal / step).toDouble()).toFloat() * step
            while (g <= maxVal + 0.001f) {
                val y = yFor(g)
                canvas.drawLine(left, y, left + w, y, gridPaint)
                canvas.drawText(g.toInt().toString(), left - 6f * density, y + 3f * density, axisTextPaint)
                g += step
            }
        } else {
            // Horizontal reference line at the midpoint of the scale
            val midY = yFor(5.5f)
            canvas.drawLine(left, midY, left + w, midY, gridPaint)
        }

        fun drawValue(x: Float, y: Float, v: Float) {
            // Above the dot; below it when there's no room at the top.
            val above = y - 8f * density >= top - 4f * density
            val baseline = if (above) y - 8f * density else y + 17f * density
            canvas.drawText(GradeFormat.format(v), x, baseline, valueTextPaint)
        }

        if (values.size == 1) {
            val x = left + w / 2
            val y = yFor(values[0])
            canvas.drawCircle(x, y, 6f, dotPaint)
            if (showAxis) drawValue(x, y, values[0])
            return
        }

        val stepX = w / (values.size - 1)
        var prevX = left
        var prevY = yFor(values[0])

        for (i in 1 until values.size) {
            val x = left + stepX * i
            val y = yFor(values[i])
            canvas.drawLine(prevX, prevY, x, y, linePaint)
            prevX = x
            prevY = y
        }

        // Numbers by the dots only while there is room for them side by side.
        val labelDots = showAxis && stepX >= 26f * density
        for (i in values.indices) {
            val x = left + stepX * i
            val y = yFor(values[i])
            canvas.drawCircle(x, y, 5f, dotPaint)
            if (labelDots) drawValue(x, y, values[i])
        }
    }
}
