package personal.digiregnotify

import android.content.Context

sealed class CheckResult {
    data class Success(val totalItems: Int, val newItems: Int) : CheckResult()
    object NoConnection : CheckResult()
    data class Failure(val message: String) : CheckResult()
}

object CheckRunner {

    /** Logs in, fetches the dashboard, diffs against last-seen items, and
     *  notifies for anything genuinely new — respecting notification prefs.
     *  Used by both the scheduled background alarm and any manual trigger,
     *  so "run a check" always means the same thing everywhere. */
    fun performCheck(context: Context): CheckResult {
        val api = RegisterApi(context)
        if (!api.hasCredentials()) return CheckResult.Failure("Not signed in")

        if (!NetworkUtil.isConnected(context)) {
            return CheckResult.NoConnection
        }

        val dashboardJson = api.fetchDashboardWithAutoLogin()
            ?: return CheckResult.Failure(api.lastError ?: "Could not log in or fetch data")

        val differ = DashboardDiffer(context)
        val items = differ.parseItems(dashboardJson)
        val newItems = differ.findNewItems(items)

        val filtered = newItems.filter { item ->
            when {
                item.type == "grade" -> NotificationPrefs.isGradesEnabled(context)
                item.type == "gradeGroup" -> NotificationPrefs.isHomeworkEnabled(context)
                else -> true
            }
        }

        NotificationHelper.notifyNewItems(context, filtered)
        return CheckResult.Success(items.size, filtered.size)
    }
}
