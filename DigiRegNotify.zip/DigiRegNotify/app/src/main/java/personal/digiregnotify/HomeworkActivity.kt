package personal.digiregnotify

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.ImageButton
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** The app's real home screen once signed in: today's and upcoming homework. */
class HomeworkActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var adapter: HomeworkAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView
    private lateinit var statusBanner: TextView
    private lateinit var moreButton: ImageButton
    private lateinit var searchBarContainer: android.widget.LinearLayout
    private lateinit var searchInput: TextInputEditText

    private var allHomeworkItems: List<DashboardItem> = emptyList()
    private val uiScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var renderJob: Job? = null
    private var firstResume = true
    private var unreadMessages: List<MessageSummary> = emptyList()
    private var activeCategory: String? = null // null = show all categories
    private var searchQuery: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homework)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.homeworkEmptyText)
        statusBanner = findViewById(R.id.homeworkStatusBanner)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        moreButton = findViewById(R.id.moreNavButton)
        searchBarContainer = findViewById(R.id.searchBarContainer)
        searchInput = findViewById(R.id.searchInput)

        val recyclerView = findViewById<RecyclerView>(R.id.homeworkRecyclerView)
        adapter = HomeworkAdapter(
            emptyList(),
            onToggle = { item, value -> onHomeworkToggled(item, value) },
            onLoadMessage = { message, callback -> loadFullMessage(message, callback) },
            onMarkMessageRead = { message -> markMessageRead(message) },
            onOpenSubmission = { s -> Attachments.open(this, s, isMessage = false) }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        adapter.prewarm(recyclerView) // inflate a few rows while the data is still loading

        findViewById<ImageButton>(R.id.messagesNavButton).setOnClickListener {
            startActivity(Intent(this, MessagesActivity::class.java))
        }
        moreButton.setOnClickListener { showMoreMenu() }
        findViewById<ImageButton>(R.id.searchNavButton).setOnClickListener { toggleSearchBar() }
        // The X in the search field: empties it, then puts the cursor straight back in and brings
        // up the keyboard so you can type the next search.
        findViewById<TextInputLayout>(R.id.searchLayout).setEndIconOnClickListener {
            searchInput.setText("")
            focusSearchField()
        }

        // Opened from a "new homework" notification: pre-apply its filter so the exact
        // item that was announced is what you land on.
        intent.getStringExtra(EXTRA_CATEGORY)?.let { activeCategory = it }
        intent.getStringExtra(EXTRA_SEARCH)?.let { query ->
            searchQuery = query
            searchInput.setText(query)
            searchBarContainer.visibility = android.view.View.VISIBLE
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString().orEmpty()
                render()
            }
        })

        // loadUnreadMessages() is deliberately NOT called here alongside loadHomework() —
        // "Check now" in Settings (one clean, isolated request) works reliably, while this
        // screen firing homework and messages as two concurrent requests on the same session
        // occasionally doesn't. loadHomework() now kicks off the messages load itself once
        // it's genuinely finished, instead of both racing each other from the start.
        swipeRefresh.setOnRefreshListener { loadHomework() }
        loadHomework()
    }

    /** Sort/Timetable/Marks/Settings, consolidated so the top bar can't overflow regardless
     *  of screen width — six separate buttons there was one too many. */
    /** A themed row list instead of a plain system PopupMenu, so it actually looks like the
     *  rest of the app (icon + label + a subtitle for Sort showing the active filter) rather
     *  than generic platform styling. */
    private fun showMoreMenu() {
        var fly: FlyInDialog? = null

        val items = listOf(
            MoreMenuItem(
                R.drawable.ic_menu_sort, "Sort",
                activeCategory?.let { "Currently: $it" }
            ) { showSortMenu() },
            MoreMenuItem(R.drawable.ic_menu_timetable, "Timetable", null) {
                startActivity(Intent(this, TimetableActivity::class.java))
            },
            MoreMenuItem(R.drawable.ic_menu_history, "History", "Past month") {
                startActivity(Intent(this, HomeworkHistoryActivity::class.java))
            },
            MoreMenuItem(R.drawable.ic_menu_marks, "Marks", null) {
                startActivity(Intent(this, MarksActivity::class.java))
            }
        )

        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val primary = com.google.android.material.color.MaterialColors.getColor(
            this, com.google.android.material.R.attr.colorPrimary, android.graphics.Color.GRAY
        )
        val onSurface = com.google.android.material.color.MaterialColors.getColor(
            this, com.google.android.material.R.attr.colorOnSurface, android.graphics.Color.GRAY
        )

        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(14))
        }
        // Header: the title, and Settings as a gear in the top right corner.
        val header = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, 0, dp(10))
        }
        header.addView(TextView(this).apply {
            text = "Menu"
            textSize = 20f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setTextColor(onSurface)
            layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        header.addView(android.widget.ImageButton(this).apply {
            setImageResource(R.drawable.ic_settings_gear)
            setColorFilter(primary)
            background = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless)).let { a ->
                a.getDrawable(0).also { a.recycle() }
            }
            setPadding(dp(8), dp(8), dp(8), dp(8))
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            contentDescription = "Settings"
            layoutParams = android.widget.LinearLayout.LayoutParams(dp(44), dp(44))
            setOnClickListener {
                fly?.dismiss()
                startActivity(Intent(this@HomeworkActivity, SettingsActivity::class.java))
            }
        })
        container.addView(header)

        // A two-column grid of tiles: tinted rounded card, accent icon, label, optional note.
        fun tile(item: MoreMenuItem): android.view.View =
            android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                minimumHeight = dp(92)
                setPadding(dp(16), dp(14), dp(16), dp(14))
                background = android.graphics.drawable.RippleDrawable(
                    android.content.res.ColorStateList.valueOf(androidx.core.graphics.ColorUtils.setAlphaComponent(primary, 50)),
                    android.graphics.drawable.GradientDrawable().apply {
                        cornerRadius = dp(16).toFloat()
                        setColor(androidx.core.graphics.ColorUtils.setAlphaComponent(primary, 28))
                    },
                    null
                )
                isClickable = true
                isFocusable = true
                setOnClickListener { fly?.dismiss(); item.action() }

                addView(android.widget.ImageView(this@HomeworkActivity).apply {
                    setImageResource(item.iconRes)
                    setColorFilter(primary)
                    layoutParams = android.widget.LinearLayout.LayoutParams(dp(26), dp(26))
                })
                addView(TextView(this@HomeworkActivity).apply {
                    text = item.label
                    textSize = 15f
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                    setTextColor(onSurface)
                    setPadding(0, dp(10), 0, 0)
                })
                if (item.subtitle != null) {
                    addView(TextView(this@HomeworkActivity).apply {
                        text = item.subtitle
                        textSize = 11f
                        alpha = 0.6f
                        setTextColor(onSurface)
                    })
                }
            }

        for (pair in items.chunked(2)) {
            val line = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(10) }
            }
            pair.forEachIndexed { index, item ->
                line.addView(tile(item), android.widget.LinearLayout.LayoutParams(
                    0, android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 1f
                ).apply { if (index == 0) marginEnd = dp(5) else marginStart = dp(5) })
            }
            // A lone last tile keeps half width: the other half is an invisible copy of it, so
            // both halves have the same natural height. (A plain spacer view broke the row —
            // it collapsed the row to nothing, then stretched it over the whole dialog.)
            if (pair.size == 1) {
                line.addView(
                    tile(pair[0]).apply { visibility = android.view.View.INVISIBLE; isClickable = false },
                    android.widget.LinearLayout.LayoutParams(
                        0, android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 1f
                    ).apply { marginStart = dp(5) }
                )
            }
            container.addView(line)
        }

        val menu = FlyInDialog(this, container)
        fly = menu
        menu.show()
    }

    private data class MoreMenuItem(
        val iconRes: Int,
        val label: String,
        val subtitle: String?,
        val action: () -> Unit
    )

    /**
     * Shows the "new version" popup when a newer release is known: from the last check (the
     * notification, or the background poll). If automatic checking is on and the last check is
     * old, this also looks first. Shown at most about twice a day, or always after a tap on the
     * notification.
     */
    private fun offerUpdate() {
        val fromNotification = intent.getBooleanExtra(EXTRA_SHOW_UPDATE, false)
        intent.removeExtra(EXTRA_SHOW_UPDATE)
        CoroutineScope(Dispatchers.IO).launch {
            if (UpdateChecker.isAutoCheckEnabled(this@HomeworkActivity)) {
                UpdateChecker.autoCheck(this@HomeworkActivity, notify = false) // throttled; no ping while you are here
            }
            val info = UpdateChecker.takePendingForPopup(this@HomeworkActivity, force = fromNotification)
            if (info != null) {
                withContext(Dispatchers.Main) { UpdateDialogs.show(this@HomeworkActivity, info) }
            }
        }
    }

    private fun toggleSearchBar() {
        if (searchBarContainer.visibility == android.view.View.VISIBLE) {
            Expand.collapse(searchBarContainer)
            searchInput.text?.clear()
            searchQuery = ""
            render()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
        } else {
            Expand.expand(searchBarContainer)
            focusSearchField()
        }
    }

    /** Puts the cursor in the search field and shows the keyboard. The short delay lets the
     *  field finish appearing first, otherwise Android ignores the request. */
    private fun focusSearchField() {
        searchInput.requestFocus()
        searchInput.postDelayed({
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }, 120)
    }

    override fun onResume() {
        super.onResume()
        // If the user signed out from Settings, bounce back to the login screen.
        if (!api.hasCredentials()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        AlarmScheduler.ensureScheduled(this) // revive the background chain if it died
        offerUpdate()
        // On the first resume loadHomework() (from onCreate) loads the messages itself once
        // it finishes; starting a second request here only made the two compete.
        if (firstResume) firstResume = false
        else loadUnreadMessages() // in case something was read on the Messages screen
    }

    private fun loadHomework() {
        if (!api.hasCredentials()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        // Offline is handled by the check itself (it reports NoConnection straight away), so the
        // saved list below can still be shown.
        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            // Runs the exact same check as Settings' "Check now" and the background alarm
            // (CheckRunner.performCheck), so a pull-to-refresh also fires notifications and
            // logs changes, and all three paths behave identically. It builds a fresh
            // RegisterApi/client each time, avoiding stale pooled connections.
            var result = CheckRunner.performCheck(this@HomeworkActivity)

            fun homeworkOf(r: CheckResult) =
                (r as? CheckResult.Success)?.items?.filter { it.type == "gradeGroup" }

            // An empty result can still be a stale-session artifact slipping past validation.
            // Rather than show "No homework found" on the first empty result, quietly retry
            // a couple of times first.
            var attempt = 0
            // Same for a hard failure, but not when the school's server couldn't be reached at all:
            // retrying a dead server only makes you wait longer.
            fun needsRetry(r: CheckResult) =
                homeworkOf(r)?.isEmpty() == true || (r is CheckResult.Failure && !r.unreachable)
            while (needsRetry(result) && attempt < 2) {
                attempt++
                delay(1500)
                result = CheckRunner.performCheck(this@HomeworkActivity)
            }

            val homework = homeworkOf(result)
            if (homework != null) SubjectRegistry.recordCodes(this@HomeworkActivity, homework.map { it.label })

            // Couldn't load: fall back to the last list the school sent.
            val saved = if (homework == null) DashboardCache.load(this@HomeworkActivity) else null
            val savedItems = saved?.let {
                try {
                    DashboardDiffer(this@HomeworkActivity).parseItems(it.json).filter { item -> item.type == "gradeGroup" }
                } catch (e: Exception) {
                    null
                }
            }

            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (homework == null && savedItems != null && saved != null) {
                    val reason = when (val r = result) {
                        is CheckResult.NoConnection -> "No internet"
                        is CheckResult.Failure -> ErrorText.reason(r.message)
                        else -> ErrorText.reason(null)
                    }
                    statusBanner.text = "Saved list from ${savedTime(saved.savedAt)} · $reason"
                    statusBanner.visibility = TextView.VISIBLE
                    emptyText.visibility = TextView.GONE
                    allHomeworkItems = savedItems
                    render()
                    loadUnreadMessages()
                    return@withContext
                }
                if (homework == null) {
                    emptyText.text = when (val r = result) {
                        is CheckResult.NoConnection -> "No internet connection right now"
                        is CheckResult.Failure -> ErrorText.friendly(r.message, "load homework")
                        else -> ErrorText.friendly(null, "load homework")
                    }
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@HomeworkActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    loadUnreadMessages() // still worth trying, even though homework failed
                    return@withContext
                }

                statusBanner.visibility = TextView.GONE
                allHomeworkItems = homework

                render()
                loadUnreadMessages() // only now, after the check has fully finished
            }
        }
    }

    /** "13:15" for today, "9 Nov, 13:15" for an earlier day. */
    private fun savedTime(millis: Long): String {
        val then = java.util.Calendar.getInstance().apply { timeInMillis = millis }
        val now = java.util.Calendar.getInstance()
        val sameDay = then.get(java.util.Calendar.YEAR) == now.get(java.util.Calendar.YEAR) &&
            then.get(java.util.Calendar.DAY_OF_YEAR) == now.get(java.util.Calendar.DAY_OF_YEAR)
        val pattern = if (sameDay) "HH:mm" else "d MMM, HH:mm"
        return java.text.SimpleDateFormat(pattern, java.util.Locale.getDefault()).format(java.util.Date(millis))
    }

    /** Shows a menu of categories actually present (e.g. Hausaufgabe, Prüfung) to filter by. */
    private fun showSortMenu() {
        val categories = allHomeworkItems
            .map { it.title.ifBlank { "Other" } }
            .distinct()
            .sorted()

        if (categories.isEmpty()) {
            Toast.makeText(this, "Nothing to sort yet", Toast.LENGTH_SHORT).show()
            return
        }

        // A dialog in the app's own style (instead of the plain system popup menu), with the
        // same fly-in as the main menu.
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val onSurface = com.google.android.material.color.MaterialColors.getColor(
            this, com.google.android.material.R.attr.colorOnSurface, android.graphics.Color.GRAY
        )
        val accent = com.google.android.material.color.MaterialColors.getColor(
            this, com.google.android.material.R.attr.colorPrimary, android.graphics.Color.GRAY
        )
        var fly: FlyInDialog? = null

        val column = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        column.addView(TextView(this).apply {
            text = "Show"
            textSize = 20f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setTextColor(onSurface)
            setPadding(dp(8), dp(12), 0, dp(10))
        })
        val options = listOf<String?>(null) + categories // null = all
        for (option in options) {
            val selected = option == activeCategory
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(14), dp(8), dp(14))
                background = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackground)).let { a ->
                    a.getDrawable(0).also { a.recycle() }
                }
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    activeCategory = option
                    fly?.dismiss()
                    render()
                }
                addView(TextView(this@HomeworkActivity).apply {
                    text = option ?: "All"
                    textSize = 16f
                    setTextColor(if (selected) accent else onSurface)
                    if (selected) typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                    layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                addView(TextView(this@HomeworkActivity).apply {
                    text = if (selected) "✓" else ""
                    textSize = 16f
                    setTextColor(accent)
                })
            }
            column.addView(row)
        }
        val menu = FlyInDialog(this, android.widget.ScrollView(this).apply { addView(column) })
        fly = menu
        menu.show()
    }

    /** Applies the active category filter and search query, groups by due date, puts unread
     *  messages at the top as real rows (so they scroll away like everything else), and
     *  pushes the result to the adapter. */
    /** Builds the list off the main thread (reading the history, filtering, grouping by day), so
     *  only handing it to the adapter is left for the main thread. The newest call wins. */
    private fun render() {
        val category = activeCategory
        val query = searchQuery
        val items = allHomeworkItems
        val unread = unreadMessages
        val context = applicationContext

        renderJob?.cancel()
        renderJob = uiScope.launch {
            val (rows, noMatches) = withContext(Dispatchers.Default) {
                var filtered = if (category == null) {
                    items
                } else {
                    items.filter { it.title.ifBlank { "Other" } == category }
                }

                if (query.isNotBlank()) {
                    val q = query.trim()
                    filtered = filtered.filter {
                        it.title.contains(q, ignoreCase = true) || it.subtitle.contains(q, ignoreCase = true)
                    }
                }

                // Reading these the first time touches the disk; do it here, not while binding rows.
                filtered.mapNotNull { it.label.ifBlank { null } }.distinct().forEach {
                    SubjectNames.nameFor(context, it)
                    SubjectColors.colorForCode(context, it)
                }

                val history = ItemHistory.load(context)
                val messageRows = unread.map { HomeworkRow.UnreadMessage(it) }
                val built = buildRows(filtered, fillEmptyDays = category == null && query.isBlank(), history)
                (messageRows + built) to filtered.isEmpty()
            }

            adapter.updateRows(rows)

            emptyText.visibility = if (noMatches && unread.isEmpty()) TextView.VISIBLE else TextView.GONE
            emptyText.text = when {
                items.isEmpty() -> "No homework found"
                query.isNotBlank() -> "Nothing matches \"$query\""
                else -> "Nothing in this category"
            }
        }
    }

    override fun onDestroy() {
        uiScope.cancel()
        super.onDestroy()
    }

    /** Sends a tick/untick to the server, then re-renders so every box shows the real state. */
    private fun onHomeworkToggled(item: DashboardItem, value: Boolean) {
        CoroutineScope(Dispatchers.IO).launch {
            val freshApi = RegisterApi(this@HomeworkActivity)
            val ok = freshApi.toggleReminder(item.id, item.type, value)
            withContext(Dispatchers.Main) {
                if (ok) {
                    allHomeworkItems = allHomeworkItems.map {
                        if (it.id == item.id && it.type == item.type) it.copy(checked = value) else it
                    }
                } else {
                    Toast.makeText(
                        this@HomeworkActivity,
                        ErrorText.friendly(freshApi.lastError, "update this"),
                        Toast.LENGTH_SHORT
                    ).show()
                }
                render()
            }
        }
    }

    /** Fills in every day from today through the furthest due date (capped) — but only for the
     *  full, unfiltered list. When searching or sorting, [fillEmptyDays] is false: a search for
     *  something due in a month shouldn't generate a month of "Nothing due" placeholder rows. */
    private fun buildRows(items: List<DashboardItem>, fillEmptyDays: Boolean, history: ItemHistory.Data): List<HomeworkRow> {
        val withDates = items.map { item -> item to DueDateFormat.parse(item.deadline) }
        val dated = withDates.filter { it.second != null }
        val undated = withDates.filter { it.second == null }.map { it.first }

        val rows = mutableListOf<HomeworkRow>()

        if (dated.isNotEmpty()) {
            if (fillEmptyDays) {
                val maxFilledDays = 14
                val today = startOfDay(java.util.Date())
                val maxDueDay = startOfDay(java.util.Date(dated.maxOf { it.second!!.time }))

                val daySpan = ((maxDueDay.time - today.time) / (24 * 60 * 60 * 1000)).toInt().coerceAtLeast(0)
                val filledSpan = daySpan.coerceAtMost(maxFilledDays)

                val cursor = java.util.Calendar.getInstance().apply { time = today }
                repeat(filledSpan + 1) {
                    val dayStart = startOfDay(cursor.time)
                    val dayEnd = dayStart.time + 24 * 60 * 60 * 1000
                    val dayItems = dated
                        .filter { it.second!!.time in dayStart.time until dayEnd }
                        .sortedBy { it.second!!.time }

                    rows.add(HomeworkRow.DateHeader(DueDateFormat.dayLabel(dayStart), deletedOn(dayStart, history)))
                    if (dayItems.isEmpty()) {
                        rows.add(HomeworkRow.EmptyNote("Nothing due"))
                    } else {
                        dayItems.forEach { rows.add(itemRow(it.first, history)) }
                    }
                    cursor.add(java.util.Calendar.DAY_OF_YEAR, 1)
                }

                // Anything further out than the fill cap: still shown, just not
                // gap-filled day by day (avoids a huge list for a far-off item).
                if (daySpan > maxFilledDays) {
                    val beyondCutoff = cursor.timeInMillis
                    val beyond = dated
                        .filter { it.second!!.time >= beyondCutoff }
                        .sortedBy { it.second!!.time }
                    var lastLabel: String? = null
                    for ((item, date) in beyond) {
                        val label = DueDateFormat.dayLabel(date!!)
                        if (label != lastLabel) {
                            rows.add(HomeworkRow.DateHeader(label))
                            lastLabel = label
                        }
                        rows.add(itemRow(item, history))
                    }
                }
            } else {
                // Filtered view: just group by the days that actually have a match.
                val sorted = dated.sortedBy { it.second!!.time }
                var lastLabel: String? = null
                for ((item, date) in sorted) {
                    val label = DueDateFormat.dayLabel(date!!)
                    if (label != lastLabel) {
                        rows.add(HomeworkRow.DateHeader(label))
                        lastLabel = label
                    }
                    rows.add(itemRow(item, history))
                }
            }
        }

        if (undated.isNotEmpty()) {
            rows.add(HomeworkRow.DateHeader("No due date"))
            undated.forEach { rows.add(itemRow(it, history)) }
        }

        return rows
    }

    private fun itemRow(item: DashboardItem, history: ItemHistory.Data) =
        HomeworkRow.Item(item, history.versions["${item.type}:${item.id}"] ?: emptyList())

    /** Homework that was due on [day] but has since been deleted. */
    private fun deletedOn(day: java.util.Date, history: ItemHistory.Data): List<DeletedHomework> =
        history.deleted.filter { d ->
            DueDateFormat.parse(d.deadline)?.let { startOfDay(it).time == day.time } == true
        }

    private fun startOfDay(date: java.util.Date): java.util.Date {
        val cal = java.util.Calendar.getInstance()
        cal.time = date
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.time
    }

    private fun loadUnreadMessages() {
        if (!api.hasCredentials() || !NetworkUtil.isConnected(this)) return

        CoroutineScope(Dispatchers.IO).launch {
            // The same request the real site's home screen uses for its unread list.
            val json = RegisterApi(this@HomeworkActivity).fetchUnreadNotifications()
            val unread = json?.let {
                try {
                    UnreadNotification.parse(it).filter { n -> n.type == "message" }.map { n ->
                        MessageSummary(
                            id = n.objectId,
                            fromName = n.messageSender,
                            subject = n.messageSubject,
                            timeSent = n.timeSent,
                            isUnread = true,
                            bodyPreview = "",
                            fullBody = "" // loaded when the message is opened
                        )
                    }
                } catch (e: Exception) {
                    null
                }
            }
            withContext(Dispatchers.Main) {
                // On a failed request keep what is already shown rather than wiping it.
                if (unread != null) {
                    unreadMessages = unread
                    render()
                }
            }
        }
    }

    /** Fetches the full text and attachments of an unread message for its row to show. */
    private fun loadFullMessage(message: MessageSummary, callback: (MessageSummary?) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            val full = RegisterApi(this@HomeworkActivity).fetchMessages()?.let {
                try {
                    MessageParser.parse(it).firstOrNull { m -> m.id == message.id }
                } catch (e: Exception) {
                    null
                }
            }
            withContext(Dispatchers.Main) { callback(full) }
        }
    }

    private fun markMessageRead(message: MessageSummary) {
        CoroutineScope(Dispatchers.IO).launch {
            val freshApi = RegisterApi(this@HomeworkActivity)
            val ok = freshApi.markMessageAsRead(message.id)
            withContext(Dispatchers.Main) {
                if (ok) {
                    unreadMessages = unreadMessages.filter { it.id != message.id }
                    render()
                } else {
                    Toast.makeText(
                        this@HomeworkActivity,
                        ErrorText.friendly(freshApi.lastError, "mark this as read"),
                        Toast.LENGTH_SHORT
                    ).show()
                    render() // re-enable the button row
                }
            }
        }
    }

    companion object {
        const val EXTRA_CATEGORY = "category"
        const val EXTRA_SEARCH = "search"
        const val EXTRA_SHOW_UPDATE = "show_update"
    }
}
