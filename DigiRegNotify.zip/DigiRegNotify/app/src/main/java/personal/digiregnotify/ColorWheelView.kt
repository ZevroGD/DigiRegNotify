package personal.digiregnotify

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * A colour picker made of a hue ring with a saturation/brightness triangle inside it.
 * Drag on the ring to choose the hue (the triangle stays put and takes on that colour); drag inside the triangle
 * to choose how bright and how saturated: one corner is the pure hue, one white, one black.
 */
class ColorWheelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Called with the new colour whenever the user changes it by touch (not by setColor). */
    var onColorChanged: ((Int) -> Unit)? = null

    private var hue = 0f
    private var sat = 1f
    private var value = 1f

    private val density = resources.displayMetrics.density

    // Geometry, set in onSizeChanged.
    private var cx = 0f
    private var cy = 0f
    private var outerR = 0f
    private var ringWidth = 0f
    private var ringInnerR = 0f
    private var triR = 0f

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val trianglePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val trianglePath = Path()
    private val knobFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val knobRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 3f * density
    }
    private val knobShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x66000000
        strokeWidth = 5f * density
    }

    // The triangle is painted into a small bitmap (colour per pixel), redone when the hue changes.
    private var triBitmap: Bitmap? = null
    private var bitmapHue = -1f
    private val bitmapScale = 0.5f

    private var dragMode = DRAG_NONE

    /** Sets the shown colour (for example when the hex field is edited). */
    fun setColor(color: Int) {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        // A grey or black has no hue of its own; keep the current one instead of jumping to red.
        if (hsv[1] > 0.001f && hsv[2] > 0.001f) hue = hsv[0]
        sat = hsv[1]
        value = hsv[2]
        invalidate()
    }

    fun getColor(): Int = Color.HSVToColor(floatArrayOf(hue, sat, value))

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = resolveSize((280 * density).toInt(), widthMeasureSpec)
        val h = resolveSize((280 * density).toInt(), heightMeasureSpec)
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cx = w / 2f
        cy = h / 2f
        val pad = 14f * density // room for the knobs at the edge
        outerR = (minOf(w, h) / 2f - pad).coerceAtLeast(10f)
        ringWidth = outerR * 0.18f
        ringInnerR = outerR - ringWidth
        triR = ringInnerR - 8f * density
        ringPaint.strokeWidth = ringWidth
        ringPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(
                Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED
            ),
            null
        )
        bitmapHue = -1f
    }

    // The triangle's corners: pure hue (right), white (top left) and black (bottom left). The
    // triangle stays upright; only its colours change with the hue.
    private fun cornerX(offsetDegrees: Float) = cx + triR * Math.cos(Math.toRadians(offsetDegrees.toDouble())).toFloat()
    private fun cornerY(offsetDegrees: Float) = cy + triR * Math.sin(Math.toRadians(offsetDegrees.toDouble())).toFloat()

    private fun rebuildTriangleBitmap() {
        if (triR <= 0f) return
        val size = (2 * triR * bitmapScale).toInt().coerceAtLeast(2)
        val bitmap = triBitmap?.takeIf { it.width == size } ?: Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val px = cornerX(0f); val py = cornerY(0f)   // pure hue
        val wx = cornerX(240f); val wy = cornerY(240f) // white
        val kx = cornerX(120f); val ky = cornerY(120f) // black
        val denom = (wy - ky) * (px - kx) + (kx - wx) * (py - ky)
        val pure = Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
        val pr = Color.red(pure); val pg = Color.green(pure); val pb = Color.blue(pure)
        val left = cx - triR
        val top = cy - triR
        val pixels = IntArray(size * size)
        for (j in 0 until size) {
            val y = top + (j + 0.5f) / bitmapScale
            for (i in 0 until size) {
                val x = left + (i + 0.5f) / bitmapScale
                var a = ((wy - ky) * (x - kx) + (kx - wx) * (y - ky)) / denom
                var b = ((ky - py) * (x - kx) + (px - kx) * (y - ky)) / denom
                var c = 1f - a - b
                // Outside the triangle: use the nearest inside colour, so the anti-aliased edge
                // of the path never shows a gap.
                if (a < 0f || b < 0f || c < 0f) {
                    a = a.coerceAtLeast(0f); b = b.coerceAtLeast(0f); c = c.coerceAtLeast(0f)
                    val sum = a + b + c
                    if (sum > 0f) { a /= sum; b /= sum }
                }
                val r = (a * pr + b * 255f).toInt().coerceIn(0, 255)
                val g = (a * pg + b * 255f).toInt().coerceIn(0, 255)
                val bl = (a * pb + b * 255f).toInt().coerceIn(0, 255)
                pixels[j * size + i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
            }
        }
        bitmap.setPixels(pixels, 0, size, 0, 0, size, size)
        triBitmap = bitmap

        val shader = BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val matrix = Matrix().apply {
            setScale(1f / bitmapScale, 1f / bitmapScale)
            postTranslate(left, top)
        }
        shader.setLocalMatrix(matrix)
        trianglePaint.shader = shader
        trianglePath.reset()
        trianglePath.moveTo(px, py)
        trianglePath.lineTo(wx, wy)
        trianglePath.lineTo(kx, ky)
        trianglePath.close()
        bitmapHue = hue
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (outerR <= 0f) return
        if (bitmapHue != hue) rebuildTriangleBitmap()

        canvas.drawCircle(cx, cy, outerR - ringWidth / 2f, ringPaint)
        canvas.drawPath(trianglePath, trianglePaint)

        // Knob on the ring: the pure hue.
        val ringKnobR = outerR - ringWidth / 2f
        val kx = cx + ringKnobR * Math.cos(Math.toRadians(hue.toDouble())).toFloat()
        val ky = cy + ringKnobR * Math.sin(Math.toRadians(hue.toDouble())).toFloat()
        knobFill.color = Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
        val knobR = 11f * density
        canvas.drawCircle(kx, ky, knobR, knobShadow)
        canvas.drawCircle(kx, ky, knobR, knobFill)
        canvas.drawCircle(kx, ky, knobR, knobRing)

        // Knob in the triangle: the current colour.
        val a = sat * value
        val b = (1f - sat) * value
        val c = 1f - value
        val tx = a * cornerX(0f) + b * cornerX(240f) + c * cornerX(120f)
        val ty = a * cornerY(0f) + b * cornerY(240f) + c * cornerY(120f)
        knobFill.color = getColor()
        canvas.drawCircle(tx, ty, knobR, knobShadow)
        canvas.drawCircle(tx, ty, knobR, knobFill)
        canvas.drawCircle(tx, ty, knobR, knobRing)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val d = Math.hypot((event.x - cx).toDouble(), (event.y - cy).toDouble()).toFloat()
                dragMode = when {
                    d >= ringInnerR - 6f * density && d <= outerR + 24f * density -> DRAG_HUE
                    d <= triR + 14f * density -> DRAG_TRIANGLE
                    else -> DRAG_NONE
                }
                if (dragMode == DRAG_NONE) {
                    parent?.requestDisallowInterceptTouchEvent(false)
                    return false
                }
                applyTouch(event.x, event.y)
            }
            MotionEvent.ACTION_MOVE -> if (dragMode != DRAG_NONE) applyTouch(event.x, event.y)
            MotionEvent.ACTION_UP -> {
                dragMode = DRAG_NONE
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
            }
            MotionEvent.ACTION_CANCEL -> {
                dragMode = DRAG_NONE
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun applyTouch(x: Float, y: Float) {
        if (dragMode == DRAG_HUE) {
            val degrees = Math.toDegrees(Math.atan2((y - cy).toDouble(), (x - cx).toDouble())).toFloat()
            hue = (degrees + 360f) % 360f
        } else {
            val px = cornerX(0f); val py = cornerY(0f)
            val wx = cornerX(240f); val wy = cornerY(240f)
            val kx = cornerX(120f); val ky = cornerY(120f)
            val denom = (wy - ky) * (px - kx) + (kx - wx) * (py - ky)
            var a = ((wy - ky) * (x - kx) + (kx - wx) * (y - ky)) / denom
            var b = ((ky - py) * (x - kx) + (px - kx) * (y - ky)) / denom
            var c = 1f - a - b
            // A touch outside the triangle is pulled onto its edge.
            a = a.coerceAtLeast(0f); b = b.coerceAtLeast(0f); c = c.coerceAtLeast(0f)
            val sum = a + b + c
            if (sum > 0f) { a /= sum; b /= sum }
            value = (a + b).coerceIn(0f, 1f)
            sat = if (a + b > 0.0001f) (a / (a + b)).coerceIn(0f, 1f) else sat
        }
        invalidate()
        onColorChanged?.invoke(getColor())
    }

    private companion object {
        const val DRAG_NONE = 0
        const val DRAG_HUE = 1
        const val DRAG_TRIANGLE = 2
    }
}
