package personal.digiregnotify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.SystemClock

object AlarmScheduler {

    private const val REQUEST_CODE = 100
    private const val PREFS = "digireg_settings"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun setIntervalHours(context: Context, hours: Int) {
        prefs(context).edit().putInt("interval_hours", hours).apply()
    }

    fun getIntervalHours(context: Context): Int =
        prefs(context).getInt("interval_hours", 2) // default: every 2 hours

    fun setPollingEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("polling_enabled", enabled).apply()
    }

    fun isPollingEnabled(context: Context): Boolean =
        prefs(context).getBoolean("polling_enabled", true) // on by default

    fun canScheduleExact(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = context.getSystemService(AlarmManager::class.java)
            return am.canScheduleExactAlarms()
        }
        return true
    }

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, CheckAlarmReceiver::class.java)
        return PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Schedules (or reschedules) the repeating check based on the saved interval.
     *  Does nothing if polling has been turned off in Settings. */
    fun scheduleRepeating(context: Context) {
        if (!isPollingEnabled(context)) return

        val am = context.getSystemService(AlarmManager::class.java)
        val intervalMillis = getIntervalHours(context) * 60L * 60L * 1000L
        val triggerAt = SystemClock.elapsedRealtime() + intervalMillis

        val pi = pendingIntent(context)

        // setExactAndAllowWhileIdle fires once; the receiver reschedules the
        // next one itself, which is more reliable across Doze than a single
        // long-lived repeating alarm.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            // Fall back to an inexact alarm if the user hasn't granted the
            // "alarms & reminders" permission; still works, just less precise.
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
        }
    }

    /** Schedules the next check only if none is pending. Safe to call whenever the app is
     *  opened: it revives a chain that died (new APK installed, force-stop, etc.) without
     *  pushing back an alarm that's already waiting. */
    fun ensureScheduled(context: Context) {
        if (!isPollingEnabled(context)) return
        val pending = PendingIntent.getBroadcast(
            context, REQUEST_CODE, Intent(context, CheckAlarmReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending == null) scheduleRepeating(context)
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(AlarmManager::class.java)
        am.cancel(pendingIntent(context))
    }
}
