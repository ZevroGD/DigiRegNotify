package personal.digiregnotify

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.checkbox.MaterialCheckBox

private const val VIEW_TYPE_HEADER = 0
private const val VIEW_TYPE_ITEM = 1

class HomeworkAdapter(private var rows: List<HomeworkRow>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    class HeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val label: TextView = view as TextView
    }

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val checkbox: MaterialCheckBox = view.findViewById(R.id.itemCheckbox)
        val category: TextView = view.findViewById(R.id.itemCategory)
        val subject: TextView = view.findViewById(R.id.itemSubject)
    }

    fun updateRows(newRows: List<HomeworkRow>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int =
        when (rows[position]) {
            is HomeworkRow.DateHeader -> VIEW_TYPE_HEADER
            is HomeworkRow.Item -> VIEW_TYPE_ITEM
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == VIEW_TYPE_HEADER) {
            HeaderViewHolder(inflater.inflate(R.layout.item_homework_header, parent, false))
        } else {
            ItemViewHolder(inflater.inflate(R.layout.item_homework, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is HomeworkRow.DateHeader -> {
                (holder as HeaderViewHolder).label.text = row.label
            }
            is HomeworkRow.Item -> {
                val h = holder as ItemViewHolder
                val item = row.item

                // "Hausaufgabe" / "Prüfung" etc. as a small eyebrow label,
                // the actual content (subtitle) as the main line. No exact
                // time shown here on purpose — homework is a "sometime before
                // this day" thing, not an appointment.
                h.category.text = item.title.ifBlank { "Item" }
                h.subject.text = item.subtitle.ifBlank { "(no description)" }

                // Reflects the server's last-known state; not yet wired to write
                // changes back (that needs the "mark done" request captured).
                h.checkbox.setOnCheckedChangeListener(null)
                h.checkbox.isChecked = item.checked
                h.checkbox.isEnabled = item.checkable
                h.checkbox.setOnCheckedChangeListener { box, _ ->
                    box.setOnCheckedChangeListener(null)
                    box.isChecked = item.checked
                    box.setOnCheckedChangeListener { _, _ -> }
                    Toast.makeText(
                        box.context,
                        "Marking homework done isn't wired up to the server yet",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    override fun getItemCount(): Int = rows.size
}
