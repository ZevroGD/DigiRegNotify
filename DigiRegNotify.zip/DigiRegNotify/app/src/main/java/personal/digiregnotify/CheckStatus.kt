package personal.digiregnotify

import android.content.Context
import java.text.DateFormat
import java.util.Date

/** Remembers when checks last ran and how they went, so Settings can show whether the
 *  background checks are actually happening. */
object CheckStatus {

    private const val PREFS = "digireg_check_status"

    enum class Source(val label: String) { BACKGROUND("background"), MANUAL("manual"), REFRESH("refresh") }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun record(context: Context, source: Source, result: CheckResult) {
        val summary = when (result) {
            is CheckResult.Success -> "OK, ${result.newItems} new"
            is CheckResult.NoConnection -> "no connection"
            is CheckResult.Failure -> "failed"
        }
        val now = System.currentTimeMillis()
        val editor = prefs(context).edit()
            .putLong("last_time", now)
            .putString("last_source", source.label)
            .putString("last_summary", summary)
        if (source == Source.BACKGROUND) {
            editor.putLong("bg_time", now).putString("bg_summary", summary)
        }
        editor.apply()
    }

    /** Two lines: the latest check of any kind, and the latest one run by the alarm. */
    fun describe(context: Context): String {
        val p = prefs(context)
        val fmt = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        val last = p.getLong("last_time", 0L)
        val bg = p.getLong("bg_time", 0L)
        val lastLine = if (last == 0L) "Last check: never"
        else "Last check: ${fmt.format(Date(last))} (${p.getString("last_source", "")}) — ${p.getString("last_summary", "")}"
        val bgLine = if (bg == 0L) "Last background check: never"
        else "Last background check: ${fmt.format(Date(bg))} — ${p.getString("bg_summary", "")}"
        return "$lastLine\n$bgLine"
    }
}
