package personal.digiregnotify

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.ScrollView
import com.google.android.material.button.MaterialButtonToggleGroup

/**
 * Picks the Custom theme's primary and secondary colour on a colour wheel (hue ring with a
 * brightness/saturation triangle) or with a hex code. The colour you pick is kept exactly as
 * picked; the theme itself uses the closest of the prepared colours (see CustomColors), and the
 * preview strip shows that result. Save selects the Custom palette.
 */
object CustomThemeDialog {

    fun show(activity: Activity, onSaved: () -> Unit) {
        val view = activity.layoutInflater.inflate(R.layout.dialog_custom_theme, null)
        val previewPrimary = view.findViewById<View>(R.id.customPreviewPrimary)
        val previewSecondary = view.findViewById<View>(R.id.customPreviewSecondary)
        val toggle = view.findViewById<MaterialButtonToggleGroup>(R.id.customColorToggle)
        val wheel = view.findViewById<ColorWheelView>(R.id.customWheel)
        val hex = view.findViewById<EditText>(R.id.customHex)

        val picked = intArrayOf(
            PaletteManager.getCustomPickedPrimary(activity),
            PaletteManager.getCustomPickedSecondary(activity)
        )
        var editing = 0
        var updating = false // stops the wheel and the hex field from feeding each other

        fun refreshPreview() {
            previewPrimary.setBackgroundColor(CustomColors.argb[CustomColors.nearestIndex(picked[0])])
            (previewSecondary.background.mutate() as GradientDrawable)
                .setColor(CustomColors.argb[CustomColors.nearestIndex(picked[1])])
        }

        fun loadControls() {
            updating = true
            wheel.setColor(picked[editing])
            hex.setText(String.format("#%06X", picked[editing] and 0xFFFFFF))
            updating = false
        }

        wheel.onColorChanged = { color ->
            picked[editing] = color
            updating = true
            hex.setText(String.format("#%06X", color and 0xFFFFFF))
            updating = false
            refreshPreview()
        }

        hex.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (updating) return
                val text = s.toString().trimStart('#')
                if (text.length != 6) return // wait until a full code is typed
                val parsed = try {
                    Color.parseColor("#$text")
                } catch (e: Exception) {
                    return
                }
                picked[editing] = parsed
                wheel.setColor(parsed)
                refreshPreview()
            }
        })

        toggle.check(R.id.customEditPrimary)
        toggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            editing = if (checkedId == R.id.customEditPrimary) 0 else 1
            loadControls()
        }

        refreshPreview()
        loadControls()

        SlideDialogBuilder(activity)
            .setTitle("Custom colors")
            .setView(ScrollView(activity).apply { addView(view) })
            .setPositiveButton("Save") { _, _ ->
                PaletteManager.setCustomColors(activity, picked[0], picked[1])
                PaletteManager.setSelectedKey(activity, PaletteManager.CUSTOM_KEY)
                onSaved()
            }
            .setNeutralButton("Reset") { _, _ ->
                PaletteManager.setCustomColors(
                    activity, CustomColors.DEFAULT_PRIMARY_ARGB, CustomColors.DEFAULT_SECONDARY_ARGB
                )
                PaletteManager.setSelectedKey(activity, PaletteManager.CUSTOM_KEY)
                onSaved()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
