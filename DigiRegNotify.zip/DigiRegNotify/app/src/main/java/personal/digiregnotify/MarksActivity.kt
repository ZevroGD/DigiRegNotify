package personal.digiregnotify

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MarksActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var adapter: MarksAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_marks)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.marksEmptyText)
        swipeRefresh = findViewById(R.id.marksSwipeRefresh)

        val recyclerView = findViewById<RecyclerView>(R.id.marksRecyclerView)
        adapter = MarksAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        swipeRefresh.setOnRefreshListener { loadMarks() }
        findViewById<ImageButton>(R.id.marksBackButton).setOnClickListener { finish() }
        loadMarks()
    }

    private fun loadMarks() {
        if (!api.hasCredentials()) {
            emptyText.text = "Sign in from the main screen first"
            emptyText.visibility = TextView.VISIBLE
            swipeRefresh.isRefreshing = false
            return
        }

        if (!NetworkUtil.isConnected(this)) {
            swipeRefresh.isRefreshing = false
            emptyText.text = "No internet connection right now"
            emptyText.visibility = TextView.VISIBLE
            return
        }

        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            val json = api.fetchAllSubjects()
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (json == null) {
                    emptyText.text = ErrorText.friendly(api.lastError, "load marks")
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@MarksActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    return@withContext
                }

                val subjects = try {
                    AllSubjectsParser.parse(json)
                } catch (e: Exception) {
                    emptyText.text = "Could not read the marks data"
                    emptyText.visibility = TextView.VISIBLE
                    return@withContext
                }

                val bySubject = subjects
                    .filter { it.grades.isNotEmpty() }
                    .map { s ->
                        SubjectMarks(
                            subject = s.name.ifBlank { "Subject ${s.subjectId}" },
                            grades = s.grades.map { it.value },
                            latestAssessment = s.grades.last().type,
                            serverAverage = s.averageSemester ?: s.averageYear
                        )
                    }
                    .sortedBy { it.subject }

                adapter.updateSubjects(bySubject)
                emptyText.visibility = if (bySubject.isEmpty()) TextView.VISIBLE else TextView.GONE
                emptyText.text = "No grades found yet"
            }
        }
    }
}
