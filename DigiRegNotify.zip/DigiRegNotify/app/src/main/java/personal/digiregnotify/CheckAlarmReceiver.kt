package personal.digiregnotify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CheckAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // Always reschedule the next check first, so a crash/failure below
        // doesn't silently kill the whole chain.
        AlarmScheduler.scheduleRepeating(context)

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                runCheck(context)
            } catch (e: Exception) {
                Log.e("DigiReg", "Check failed", e)
                NotificationHelper.notifyError(context, e.message ?: "Unknown error")
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun runCheck(context: Context) {
        val api = RegisterApi(context)
        if (!api.hasCredentials()) return

        val dashboardJson = api.fetchDashboardWithAutoLogin() ?: run {
            NotificationHelper.notifyError(context, "Could not log in or fetch data")
            return
        }

        val differ = DashboardDiffer(context)
        val items = differ.parseItems(dashboardJson)
        val newItems = differ.findNewItems(items)

        val filtered = newItems.filter { item ->
            when {
                item.type == "grade" -> NotificationPrefs.isGradesEnabled(context)
                item.type == "gradeGroup" -> NotificationPrefs.isHomeworkEnabled(context)
                else -> true
            }
        }

        NotificationHelper.notifyNewItems(context, filtered)
    }
}
