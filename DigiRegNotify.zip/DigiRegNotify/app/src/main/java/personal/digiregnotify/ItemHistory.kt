package personal.digiregnotify

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** What a homework item said before an edit. [ts] is when the app noticed the edit. */
data class ItemVersion(val ts: Long, val title: String, val subtitle: String, val deadline: String)

/** A homework item that vanished from the feed while it was still due. [ts] = noticed at. */
data class DeletedHomework(
    val key: String,
    val label: String,
    val title: String,
    val subtitle: String,
    val deadline: String,
    val ts: Long
)

/**
 * Per-item edit history and deleted-homework markers, shown right on the Homework screen
 * (an info button on the edited item, a marker on the date a deleted item was due) instead
 * of a separate change log. Only what the app actually saw is known: edits made before
 * the first check, or while no check ran, can't be recovered.
 */
object ItemHistory {

    private const val PREFS = "digireg_item_history"
    private const val KEY_VERSIONS = "versions"
    private const val KEY_DELETED = "deleted"
    private const val MAX_VERSIONS_PER_ITEM = 10
    private const val MAX_DELETED = 60
    private const val VERSIONS_KEEP_DAYS = 90L
    private const val DELETED_KEEP_DAYS = 35L

    data class Data(
        val versions: Map<String, List<ItemVersion>>, // oldest first
        val deleted: List<DeletedHomework>
    )

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun load(context: Context): Data = Data(readVersions(context), readDeleted(context))

    @Synchronized
    fun addVersion(context: Context, key: String, version: ItemVersion) {
        val all = readVersions(context).toMutableMap()
        all[key] = ((all[key] ?: emptyList()) + version).takeLast(MAX_VERSIONS_PER_ITEM)
        writeVersions(context, all)
    }

    @Synchronized
    fun addDeleted(context: Context, item: DeletedHomework) {
        val list = (readDeleted(context).filter { it.key != item.key } + item).takeLast(MAX_DELETED)
        writeDeleted(context, list)
    }

    /**
     * One-time carry-over from the old "Change history" screen, which no longer exists: its
     * "changed" entries are matched to today's homework by wording and become edit markers
     * (the old wording itself was never stored). Then the old log is deleted.
     */
    @Synchronized
    fun importOldChangeLog(context: Context, current: Map<String, DashboardItem>) {
        val p = prefs(context)
        if (p.getBoolean("old_log_imported", false)) return
        val old = context.getSharedPreferences("digireg_change_log", Context.MODE_PRIVATE)
        val raw = old.getString("entries", null)
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (o.optString("type") != "changed" || o.optString("itemType") != "gradeGroup") continue
                    val text = o.optString("summary").removePrefix("Homework — ")
                    val match = current.entries.firstOrNull { (_, item) ->
                        "${item.label} — ${item.title}: ${item.subtitle}" == text
                    } ?: continue
                    val existing = readVersions(context)[match.key] ?: emptyList()
                    val ts = o.optLong("ts")
                    if (existing.any { it.ts == ts }) continue
                    addVersion(context, match.key,
                        ItemVersion(ts, "", "Earlier wording wasn't recorded", ""))
                }
            } catch (e: Exception) {
                // A malformed old log just means nothing is carried over.
            }
        }
        old.edit().clear().apply()
        p.edit().putBoolean("old_log_imported", true).apply()
    }

    fun clear(context: Context) {
        prefs(context).edit().remove(KEY_VERSIONS).remove(KEY_DELETED).apply()
    }

    /**
     * Housekeeping. Edit history is kept for [VERSIONS_KEEP_DAYS] days after the last edit, and a
     * deleted-homework marker for [DELETED_KEEP_DAYS] days after its due day — long enough to
     * still show on the History screen once the item has left the live feed.
     */
    @Synchronized
    fun prune(context: Context, todayStartMillis: Long) {
        val dayMs = 24L * 60 * 60 * 1000
        val versions = readVersions(context).filterValues { list ->
            (list.maxOfOrNull { it.ts } ?: 0L) >= System.currentTimeMillis() - VERSIONS_KEEP_DAYS * dayMs
        }
        writeVersions(context, versions)
        val deleted = readDeleted(context).filter {
            val due = DueDateFormat.parse(it.deadline)?.time ?: return@filter false
            due >= todayStartMillis - DELETED_KEEP_DAYS * dayMs
        }
        writeDeleted(context, deleted)
    }

    private fun readVersions(context: Context): Map<String, List<ItemVersion>> {
        val raw = prefs(context).getString(KEY_VERSIONS, null) ?: return emptyMap()
        return try {
            val obj = JSONObject(raw)
            obj.keys().asSequence().associateWith { k ->
                val arr = obj.getJSONArray(k)
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    ItemVersion(o.optLong("ts"), o.optString("title"), o.optString("subtitle"), o.optString("deadline"))
                }
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun writeVersions(context: Context, map: Map<String, List<ItemVersion>>) {
        val obj = JSONObject()
        for ((k, list) in map) {
            val arr = JSONArray()
            for (v in list) arr.put(JSONObject().put("ts", v.ts).put("title", v.title)
                .put("subtitle", v.subtitle).put("deadline", v.deadline))
            obj.put(k, arr)
        }
        prefs(context).edit().putString(KEY_VERSIONS, obj.toString()).apply()
    }

    private fun readDeleted(context: Context): List<DeletedHomework> {
        val raw = prefs(context).getString(KEY_DELETED, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                DeletedHomework(
                    o.optString("key"), o.optString("label"), o.optString("title"),
                    o.optString("subtitle"), o.optString("deadline"), o.optLong("ts")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeDeleted(context: Context, list: List<DeletedHomework>) {
        val arr = JSONArray()
        for (d in list) arr.put(JSONObject().put("key", d.key).put("label", d.label).put("title", d.title)
            .put("subtitle", d.subtitle).put("deadline", d.deadline).put("ts", d.ts))
        prefs(context).edit().putString(KEY_DELETED, arr.toString()).apply()
    }
}
