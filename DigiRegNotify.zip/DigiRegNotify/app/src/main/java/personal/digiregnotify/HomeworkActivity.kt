package personal.digiregnotify

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** The app's real home screen once signed in: today's and upcoming homework. */
class HomeworkActivity : AppCompatActivity() {

    private lateinit var api: RegisterApi
    private lateinit var adapter: HomeworkAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homework)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.homeworkEmptyText)
        swipeRefresh = findViewById(R.id.swipeRefresh)

        val recyclerView = findViewById<RecyclerView>(R.id.homeworkRecyclerView)
        adapter = HomeworkAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<TextView>(R.id.marksNavButton).setOnClickListener {
            startActivity(Intent(this, MarksActivity::class.java))
        }
        findViewById<TextView>(R.id.settingsNavButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        swipeRefresh.setOnRefreshListener { loadHomework() }
        loadHomework()
    }

    override fun onResume() {
        super.onResume()
        // If the user signed out from Settings, bounce back to the login screen.
        if (!api.hasCredentials()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun loadHomework() {
        if (!api.hasCredentials()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            val dashboardJson = api.fetchDashboardWithAutoLogin()
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (dashboardJson == null) {
                    emptyText.text = "Could not load homework:\n${api.lastError}"
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@HomeworkActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    return@withContext
                }

                val differ = DashboardDiffer(this@HomeworkActivity)
                val allItems = differ.parseItems(dashboardJson)
                val homeworkItems = allItems.filter { it.type == "gradeGroup" }

                val rows = buildRows(homeworkItems)
                adapter.updateRows(rows)
                emptyText.visibility = if (homeworkItems.isEmpty()) TextView.VISIBLE else TextView.GONE
                emptyText.text = "No homework found"
            }
        }
    }

    /** Groups items by due date, inserting a header row before each new day. */
    private fun buildRows(items: List<DashboardItem>): List<HomeworkRow> {
        val withDates = items.map { item ->
            val date = DueDateFormat.parse(item.deadline)
            Triple(item, date, date?.let { DueDateFormat.timeLabel(it) })
        }.sortedBy { it.second?.time ?: Long.MAX_VALUE }

        val rows = mutableListOf<HomeworkRow>()
        var lastDayLabel: String? = null

        for ((item, date, timeLabel) in withDates) {
            val dayLabel = date?.let { DueDateFormat.dayLabel(it) } ?: "No due date"
            if (dayLabel != lastDayLabel) {
                rows.add(HomeworkRow.DateHeader(dayLabel))
                lastDayLabel = dayLabel
            }
            rows.add(HomeworkRow.Item(item, timeLabel))
        }
        return rows
    }
}
