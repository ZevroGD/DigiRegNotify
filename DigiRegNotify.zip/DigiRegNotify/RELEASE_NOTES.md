## What's new

**Changed**
- Messages now stretch open inside the list, like the subjects on the Marks screen: tap a message and its box slides down to show the full text and attachments. This applies to the Messages screen and to the unread messages on Home (the *Open* button). They stay open when the list refreshes.
