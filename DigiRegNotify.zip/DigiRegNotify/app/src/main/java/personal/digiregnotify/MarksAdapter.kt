package personal.digiregnotify

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

data class SubjectMarks(
    val subject: String,
    val grades: List<Float> // in the order received (most recent activity first from the API,
                             // reversed to chronological before display)
) {
    val average: Float get() = if (grades.isEmpty()) 0f else grades.sum() / grades.size
}

class MarksAdapter(private var subjects: List<SubjectMarks>) :
    RecyclerView.Adapter<MarksAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.subjectName)
        val average: TextView = view.findViewById(R.id.subjectAverage)
        val chart: GradeChartView = view.findViewById(R.id.subjectChart)
    }

    fun updateSubjects(newSubjects: List<SubjectMarks>) {
        subjects = newSubjects
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_subject_marks, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val subject = subjects[position]
        holder.name.text = subject.subject
        holder.average.text = String.format(Locale.getDefault(), "%.2f", subject.average)
        // Reverse so the chart reads left-to-right in chronological order,
        // since the API returns most-recent-first.
        holder.chart.setValues(subject.grades.reversed())
    }

    override fun getItemCount(): Int = subjects.size
}
