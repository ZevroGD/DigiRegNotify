package personal.digiregnotify

/**
 * The prepared colours behind the Custom theme: 12 levels per colour channel, 12 x 12 x 12 =
 * 1,728 colours spread evenly through the whole RGB cube (greys included). A theme can't take
 * colours chosen at runtime, so each of these has a ready-made overlay style
 * (res/values/custom_palette.xml, generated in the same order). Whatever colour the user picks
 * is matched to the closest one, which is never more than about 20 steps away in RGB.
 */
object CustomColors {
    const val DEFAULT_PRIMARY_ARGB = 0xFF2A5CAA.toInt()   // a deep blue
    const val DEFAULT_SECONDARY_ARGB = 0xFFF28C28.toInt() // an orange

    private const val LEVELS = 12
    private val level = IntArray(LEVELS) { Math.round(it * 255f / (LEVELS - 1)) }

    /** Colour number i is (red, green, blue) = (i / 144, i / 12 % 12, i % 12) in level steps. */
    val argb: IntArray = IntArray(LEVELS * LEVELS * LEVELS) { i ->
        val r = level[i / (LEVELS * LEVELS)]
        val g = level[(i / LEVELS) % LEVELS]
        val b = level[i % LEVELS]
        (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    /** Index of the prepared colour closest to [color]: each channel snaps to its nearest level. */
    fun nearestIndex(color: Int): Int {
        fun snap(channel: Int) = Math.round(channel * (LEVELS - 1) / 255f).coerceIn(0, LEVELS - 1)
        val r = snap((color shr 16) and 0xFF)
        val g = snap((color shr 8) and 0xFF)
        val b = snap(color and 0xFF)
        return (r * LEVELS + g) * LEVELS + b
    }
}
