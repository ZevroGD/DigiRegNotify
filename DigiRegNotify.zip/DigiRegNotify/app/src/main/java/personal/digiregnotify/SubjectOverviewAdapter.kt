package personal.digiregnotify

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class SubjectOverviewRow(
    val summary: SubjectSummary,
    val displayName: String,
    val color: Int,
    val averageText: String
)

class SubjectOverviewAdapter(
    private var rows: List<SubjectOverviewRow>,
    private val onClick: (SubjectSummary) -> Unit
) : RecyclerView.Adapter<SubjectOverviewAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val dot: View = view.findViewById(R.id.overviewRowColorDot)
        val name: TextView = view.findViewById(R.id.overviewRowName)
        val detail: TextView = view.findViewById(R.id.overviewRowDetail)
        val average: TextView = view.findViewById(R.id.overviewRowAverage)
    }

    fun updateRows(newRows: List<SubjectOverviewRow>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_subject_overview_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val row = rows[position]
        holder.name.text = row.displayName
        holder.average.text = row.averageText
        val count = row.summary.grades.size
        holder.detail.text = when (count) {
            0 -> "No grades yet"
            1 -> "1 grade"
            else -> "$count grades"
        }
        holder.average.alpha = if (count == 0) 0.4f else 1f
        (holder.dot.background.mutate() as GradientDrawable).setColor(row.color)
        holder.itemView.setOnClickListener { onClick(row.summary) }
    }

    override fun getItemCount(): Int = rows.size
}
