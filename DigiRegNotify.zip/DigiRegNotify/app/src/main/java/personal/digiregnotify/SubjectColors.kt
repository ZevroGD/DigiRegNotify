package personal.digiregnotify

import android.content.Context
import android.graphics.Color

/** Per-subject colors, keyed by the subject's short code (e.g. "H") — the one identifier
 *  that's actually shared across the dashboard, marks, and timetable data, so a subject
 *  gets the same color everywhere instead of drifting between screens. */
object SubjectColors {

    // A fixed, visually distinct palette, cycled through by default, pickable in Settings.
    val palette = listOf(
        "#C98A3E", "#35507A", "#4B7A51", "#A23B3B", "#6E3B5C",
        "#1F6F78", "#B45A2E", "#7C9CCF", "#8FBF9B", "#D98A4E"
    ).map { Color.parseColor(it) }

    private const val PREFS = "digireg_subject_colors"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Stable color for a subject: a saved override if one is set in Settings, otherwise a
     *  palette color chosen deterministically from the code so it's at least consistent. */
    fun colorForCode(context: Context, code: String): Int {
        val saved = prefs(context).getInt("subject_code_$code", Int.MIN_VALUE)
        if (saved != Int.MIN_VALUE) return saved
        val index = ((code.hashCode() % palette.size) + palette.size) % palette.size
        return palette[index]
    }

    fun setColorForCode(context: Context, code: String, color: Int) {
        prefs(context).edit().putInt("subject_code_$code", color).apply()
    }

    fun hasCustomColor(context: Context, code: String): Boolean =
        prefs(context).contains("subject_code_$code")

    fun clearColorForCode(context: Context, code: String) {
        prefs(context).edit().remove("subject_code_$code").apply()
    }

    /** Black or white text, whichever contrasts better against a given background. */
    fun readableTextColor(bgColor: Int): Int {
        val r = Color.red(bgColor)
        val g = Color.green(bgColor)
        val b = Color.blue(bgColor)
        val luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
        return if (luminance > 0.6) Color.BLACK else Color.WHITE
    }
}
