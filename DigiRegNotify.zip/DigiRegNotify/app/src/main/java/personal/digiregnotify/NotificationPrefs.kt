package personal.digiregnotify

import android.content.Context

object NotificationPrefs {

    private const val PREFS = "digireg_notification_prefs"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isGradesEnabled(context: Context): Boolean =
        prefs(context).getBoolean("notify_grades", true)

    fun setGradesEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("notify_grades", enabled).apply()
    }

    fun isHomeworkEnabled(context: Context): Boolean =
        prefs(context).getBoolean("notify_homework", true)

    fun setHomeworkEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("notify_homework", enabled).apply()
    }

    // Calendar/timetable changes aren't implemented yet — reserved for when
    // that feature lands, so Settings can show the toggle as "coming soon".
    fun isCalendarEnabled(context: Context): Boolean =
        prefs(context).getBoolean("notify_calendar", true)

    fun setCalendarEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("notify_calendar", enabled).apply()
    }
}
