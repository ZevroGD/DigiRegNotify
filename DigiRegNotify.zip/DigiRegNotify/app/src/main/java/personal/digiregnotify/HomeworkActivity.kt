package personal.digiregnotify

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.ImageButton
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** The app's real home screen once signed in: today's and upcoming homework. */
class HomeworkActivity : BaseActivity() {

    private lateinit var api: RegisterApi
    private lateinit var adapter: HomeworkAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView
    private lateinit var moreButton: ImageButton
    private lateinit var searchBarContainer: android.widget.LinearLayout
    private lateinit var searchInput: TextInputEditText

    private var allHomeworkItems: List<DashboardItem> = emptyList()
    private var history = ItemHistory.Data(emptyMap(), emptyList())
    private var firstResume = true
    private var unreadMessages: List<MessageSummary> = emptyList()
    private var activeCategory: String? = null // null = show all categories
    private var searchQuery: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homework)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.homeworkEmptyText)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        moreButton = findViewById(R.id.moreNavButton)
        searchBarContainer = findViewById(R.id.searchBarContainer)
        searchInput = findViewById(R.id.searchInput)

        val recyclerView = findViewById<RecyclerView>(R.id.homeworkRecyclerView)
        adapter = HomeworkAdapter(
            emptyList(),
            onToggle = { item, value -> onHomeworkToggled(item, value) },
            onOpenMessage = { message -> openMessage(message) },
            onMarkMessageRead = { message -> markMessageRead(message) }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<ImageButton>(R.id.messagesNavButton).setOnClickListener {
            startActivity(Intent(this, MessagesActivity::class.java))
        }
        moreButton.setOnClickListener { showMoreMenu() }
        findViewById<ImageButton>(R.id.searchNavButton).setOnClickListener { toggleSearchBar() }

        // Opened from a "new homework" notification: pre-apply its filter so the exact
        // item that was announced is what you land on.
        intent.getStringExtra(EXTRA_CATEGORY)?.let { activeCategory = it }
        intent.getStringExtra(EXTRA_SEARCH)?.let { query ->
            searchQuery = query
            searchInput.setText(query)
            searchBarContainer.visibility = android.view.View.VISIBLE
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString().orEmpty()
                render()
            }
        })

        // loadUnreadMessages() is deliberately NOT called here alongside loadHomework() —
        // "Check now" in Settings (one clean, isolated request) works reliably, while this
        // screen firing homework and messages as two concurrent requests on the same session
        // occasionally doesn't. loadHomework() now kicks off the messages load itself once
        // it's genuinely finished, instead of both racing each other from the start.
        swipeRefresh.setOnRefreshListener { loadHomework() }
        loadHomework()
    }

    /** Sort/Timetable/Marks/Settings, consolidated so the top bar can't overflow regardless
     *  of screen width — six separate buttons there was one too many. */
    /** A themed row list instead of a plain system PopupMenu, so it actually looks like the
     *  rest of the app (icon + label + a subtitle for Sort showing the active filter) rather
     *  than generic platform styling. */
    private fun showMoreMenu() {
        val dialog = SlideDialogBuilder(this).create()

        val items = listOf(
            MoreMenuItem(
                R.drawable.ic_menu_sort, "Sort",
                activeCategory?.let { "Currently: $it" }
            ) { showSortMenu() },
            MoreMenuItem(R.drawable.ic_menu_timetable, "Timetable", null) {
                startActivity(Intent(this, TimetableActivity::class.java))
            },
            MoreMenuItem(R.drawable.ic_menu_history, "History", "Past month") {
                startActivity(Intent(this, HomeworkHistoryActivity::class.java))
            },
            MoreMenuItem(R.drawable.ic_menu_marks, "Marks", null) {
                startActivity(Intent(this, MarksActivity::class.java))
            },
            MoreMenuItem(R.drawable.ic_settings_gear, "Settings", null) {
                startActivity(Intent(this, SettingsActivity::class.java))
            }
        )

        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val primary = com.google.android.material.color.MaterialColors.getColor(
            this, com.google.android.material.R.attr.colorPrimary, android.graphics.Color.GRAY
        )
        val onSurface = com.google.android.material.color.MaterialColors.getColor(
            this, com.google.android.material.R.attr.colorOnSurface, android.graphics.Color.GRAY
        )

        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(14))
        }
        container.addView(TextView(this).apply {
            text = "Menu"
            textSize = 20f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setTextColor(onSurface)
            setPadding(dp(4), 0, 0, dp(14))
        })

        // A two-column grid of tiles: tinted rounded card, accent icon, label, optional note.
        fun tile(item: MoreMenuItem): android.view.View =
            android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                minimumHeight = dp(92)
                setPadding(dp(16), dp(14), dp(16), dp(14))
                background = android.graphics.drawable.RippleDrawable(
                    android.content.res.ColorStateList.valueOf(androidx.core.graphics.ColorUtils.setAlphaComponent(primary, 50)),
                    android.graphics.drawable.GradientDrawable().apply {
                        cornerRadius = dp(16).toFloat()
                        setColor(androidx.core.graphics.ColorUtils.setAlphaComponent(primary, 28))
                    },
                    null
                )
                isClickable = true
                isFocusable = true
                setOnClickListener { dialog.dismiss(); item.action() }

                addView(android.widget.ImageView(this@HomeworkActivity).apply {
                    setImageResource(item.iconRes)
                    setColorFilter(primary)
                    layoutParams = android.widget.LinearLayout.LayoutParams(dp(26), dp(26))
                })
                addView(TextView(this@HomeworkActivity).apply {
                    text = item.label
                    textSize = 15f
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                    setTextColor(onSurface)
                    setPadding(0, dp(10), 0, 0)
                })
                if (item.subtitle != null) {
                    addView(TextView(this@HomeworkActivity).apply {
                        text = item.subtitle
                        textSize = 11f
                        alpha = 0.6f
                        setTextColor(onSurface)
                    })
                }
            }

        for (pair in items.chunked(2)) {
            val line = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(10) }
            }
            pair.forEachIndexed { index, item ->
                line.addView(tile(item), android.widget.LinearLayout.LayoutParams(
                    0, android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 1f
                ).apply { if (index == 0) marginEnd = dp(5) else marginStart = dp(5) })
            }
            if (pair.size == 1) { // keep a lone last tile at half width
                line.addView(android.view.View(this), android.widget.LinearLayout.LayoutParams(0, 0, 1f))
            }
            container.addView(line)
        }

        dialog.setView(container)
        dialog.show()
    }

    private data class MoreMenuItem(
        val iconRes: Int,
        val label: String,
        val subtitle: String?,
        val action: () -> Unit
    )

    private fun toggleSearchBar() {
        if (searchBarContainer.visibility == android.view.View.VISIBLE) {
            Expand.collapse(searchBarContainer)
            searchInput.text?.clear()
            searchQuery = ""
            render()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
        } else {
            Expand.expand(searchBarContainer)
            searchInput.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    override fun onResume() {
        super.onResume()
        // If the user signed out from Settings, bounce back to the login screen.
        if (!api.hasCredentials()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        AlarmScheduler.ensureScheduled(this) // revive the background chain if it died
        // On the first resume loadHomework() (from onCreate) loads the messages itself once
        // it finishes; starting a second request here only made the two compete.
        if (firstResume) firstResume = false
        else loadUnreadMessages() // in case something was read on the Messages screen
    }

    private fun loadHomework() {
        if (!api.hasCredentials()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        if (!NetworkUtil.isConnected(this)) {
            swipeRefresh.isRefreshing = false
            emptyText.text = "No internet connection right now"
            emptyText.visibility = TextView.VISIBLE
            return
        }

        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            // Runs the exact same check as Settings' "Check now" and the background alarm
            // (CheckRunner.performCheck), so a pull-to-refresh also fires notifications and
            // logs changes, and all three paths behave identically. It builds a fresh
            // RegisterApi/client each time, avoiding stale pooled connections.
            var result = CheckRunner.performCheck(this@HomeworkActivity)

            fun homeworkOf(r: CheckResult) =
                (r as? CheckResult.Success)?.items?.filter { it.type == "gradeGroup" }

            // An empty result can still be a stale-session artifact slipping past validation.
            // Rather than show "No homework found" on the first empty result, quietly retry
            // a couple of times first.
            var attempt = 0
            // Same for a hard failure that isn't just "offline": retry quietly before showing it.
            fun needsRetry(r: CheckResult) =
                homeworkOf(r)?.isEmpty() == true || r is CheckResult.Failure
            while (needsRetry(result) && attempt < 2) {
                attempt++
                delay(1500)
                result = CheckRunner.performCheck(this@HomeworkActivity)
            }

            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                val homework = homeworkOf(result)
                if (homework == null) {
                    emptyText.text = when (val r = result) {
                        is CheckResult.NoConnection -> "No internet connection right now"
                        is CheckResult.Failure -> ErrorText.friendly(r.message, "load homework")
                        else -> ErrorText.friendly(null, "load homework")
                    }
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@HomeworkActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    loadUnreadMessages() // still worth trying, even though homework failed
                    return@withContext
                }

                allHomeworkItems = homework
                SubjectRegistry.recordCodes(this@HomeworkActivity, allHomeworkItems.map { it.label })

                render()
                loadUnreadMessages() // only now, after the check has fully finished
            }
        }
    }

    /** Shows a menu of categories actually present (e.g. Hausaufgabe, Prüfung) to filter by. */
    private fun showSortMenu() {
        val categories = allHomeworkItems
            .map { it.title.ifBlank { "Other" } }
            .distinct()
            .sorted()

        if (categories.isEmpty()) {
            Toast.makeText(this, "Nothing to sort yet", Toast.LENGTH_SHORT).show()
            return
        }

        val popup = PopupMenu(this, moreButton, Gravity.END)
        popup.menu.add(0, 0, 0, "All")
        categories.forEachIndexed { index, category ->
            popup.menu.add(0, index + 1, index + 1, category)
        }

        popup.setOnMenuItemClickListener { menuItem ->
            activeCategory = if (menuItem.itemId == 0) null else menuItem.title.toString()
            render()
            true
        }
        popup.show()
    }

    /** Applies the active category filter and search query, groups by due date, puts unread
     *  messages at the top as real rows (so they scroll away like everything else), and
     *  pushes the result to the adapter. */
    private fun render() {
        var filtered = if (activeCategory == null) {
            allHomeworkItems
        } else {
            allHomeworkItems.filter { it.title.ifBlank { "Other" } == activeCategory }
        }

        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim()
            filtered = filtered.filter {
                it.title.contains(q, ignoreCase = true) || it.subtitle.contains(q, ignoreCase = true)
            }
        }

        history = ItemHistory.load(this)
        val messageRows = unreadMessages.map { HomeworkRow.UnreadMessage(it) }
        val rows = buildRows(filtered, fillEmptyDays = activeCategory == null && searchQuery.isBlank())
        adapter.updateRows(messageRows + rows)

        emptyText.visibility = if (filtered.isEmpty() && unreadMessages.isEmpty()) TextView.VISIBLE else TextView.GONE
        emptyText.text = when {
            allHomeworkItems.isEmpty() -> "No homework found"
            searchQuery.isNotBlank() -> "Nothing matches \"$searchQuery\""
            else -> "Nothing in this category"
        }
    }

    /** Sends a tick/untick to the server, then re-renders so every box shows the real state. */
    private fun onHomeworkToggled(item: DashboardItem, value: Boolean) {
        CoroutineScope(Dispatchers.IO).launch {
            val freshApi = RegisterApi(this@HomeworkActivity)
            val ok = freshApi.toggleReminder(item.id, item.type, value)
            withContext(Dispatchers.Main) {
                if (ok) {
                    allHomeworkItems = allHomeworkItems.map {
                        if (it.id == item.id && it.type == item.type) it.copy(checked = value) else it
                    }
                } else {
                    Toast.makeText(
                        this@HomeworkActivity,
                        ErrorText.friendly(freshApi.lastError, "update this"),
                        Toast.LENGTH_SHORT
                    ).show()
                }
                render()
            }
        }
    }

    /** Fills in every day from today through the furthest due date (capped) — but only for the
     *  full, unfiltered list. When searching or sorting, [fillEmptyDays] is false: a search for
     *  something due in a month shouldn't generate a month of "Nothing due" placeholder rows. */
    private fun buildRows(items: List<DashboardItem>, fillEmptyDays: Boolean): List<HomeworkRow> {
        val withDates = items.map { item -> item to DueDateFormat.parse(item.deadline) }
        val dated = withDates.filter { it.second != null }
        val undated = withDates.filter { it.second == null }.map { it.first }

        val rows = mutableListOf<HomeworkRow>()

        if (dated.isNotEmpty()) {
            if (fillEmptyDays) {
                val maxFilledDays = 14
                val today = startOfDay(java.util.Date())
                val maxDueDay = startOfDay(java.util.Date(dated.maxOf { it.second!!.time }))

                val daySpan = ((maxDueDay.time - today.time) / (24 * 60 * 60 * 1000)).toInt().coerceAtLeast(0)
                val filledSpan = daySpan.coerceAtMost(maxFilledDays)

                val cursor = java.util.Calendar.getInstance().apply { time = today }
                repeat(filledSpan + 1) {
                    val dayStart = startOfDay(cursor.time)
                    val dayEnd = dayStart.time + 24 * 60 * 60 * 1000
                    val dayItems = dated
                        .filter { it.second!!.time in dayStart.time until dayEnd }
                        .sortedBy { it.second!!.time }

                    rows.add(HomeworkRow.DateHeader(DueDateFormat.dayLabel(dayStart), deletedOn(dayStart)))
                    if (dayItems.isEmpty()) {
                        rows.add(HomeworkRow.EmptyNote("Nothing due"))
                    } else {
                        dayItems.forEach { rows.add(itemRow(it.first)) }
                    }
                    cursor.add(java.util.Calendar.DAY_OF_YEAR, 1)
                }

                // Anything further out than the fill cap: still shown, just not
                // gap-filled day by day (avoids a huge list for a far-off item).
                if (daySpan > maxFilledDays) {
                    val beyondCutoff = cursor.timeInMillis
                    val beyond = dated
                        .filter { it.second!!.time >= beyondCutoff }
                        .sortedBy { it.second!!.time }
                    var lastLabel: String? = null
                    for ((item, date) in beyond) {
                        val label = DueDateFormat.dayLabel(date!!)
                        if (label != lastLabel) {
                            rows.add(HomeworkRow.DateHeader(label))
                            lastLabel = label
                        }
                        rows.add(itemRow(item))
                    }
                }
            } else {
                // Filtered view: just group by the days that actually have a match.
                val sorted = dated.sortedBy { it.second!!.time }
                var lastLabel: String? = null
                for ((item, date) in sorted) {
                    val label = DueDateFormat.dayLabel(date!!)
                    if (label != lastLabel) {
                        rows.add(HomeworkRow.DateHeader(label))
                        lastLabel = label
                    }
                    rows.add(itemRow(item))
                }
            }
        }

        if (undated.isNotEmpty()) {
            rows.add(HomeworkRow.DateHeader("No due date"))
            undated.forEach { rows.add(itemRow(it)) }
        }

        return rows
    }

    private fun itemRow(item: DashboardItem) =
        HomeworkRow.Item(item, history.versions["${item.type}:${item.id}"] ?: emptyList())

    /** Homework that was due on [day] but has since been deleted. */
    private fun deletedOn(day: java.util.Date): List<DeletedHomework> =
        history.deleted.filter { d ->
            DueDateFormat.parse(d.deadline)?.let { startOfDay(it).time == day.time } == true
        }

    private fun startOfDay(date: java.util.Date): java.util.Date {
        val cal = java.util.Calendar.getInstance()
        cal.time = date
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.time
    }

    private fun loadUnreadMessages() {
        if (!api.hasCredentials() || !NetworkUtil.isConnected(this)) return

        CoroutineScope(Dispatchers.IO).launch {
            // The same request the real site's home screen uses for its unread list.
            val json = RegisterApi(this@HomeworkActivity).fetchUnreadNotifications()
            val unread = json?.let {
                try {
                    UnreadNotification.parse(it).filter { n -> n.type == "message" }.map { n ->
                        MessageSummary(
                            id = n.objectId,
                            fromName = n.messageSender,
                            subject = n.messageSubject,
                            timeSent = n.timeSent,
                            isUnread = true,
                            bodyPreview = "",
                            fullBody = "" // loaded when the message is opened
                        )
                    }
                } catch (e: Exception) {
                    null
                }
            }
            withContext(Dispatchers.Main) {
                // On a failed request keep what is already shown rather than wiping it.
                if (unread != null) {
                    unreadMessages = unread
                    render()
                }
            }
        }
    }

    /** Shows the full message and marks it read — same behavior as opening it in Messages.
     *  The unread list only knows sender and subject, so the body is fetched on demand. */
    private fun openMessage(message: MessageSummary) {
        CoroutineScope(Dispatchers.IO).launch {
            val full = RegisterApi(this@HomeworkActivity).fetchMessages()?.let {
                try {
                    MessageParser.parse(it).firstOrNull { m -> m.id == message.id }
                } catch (e: Exception) {
                    null
                }
            }
            withContext(Dispatchers.Main) {
                if (full == null) {
                    Toast.makeText(this@HomeworkActivity, "Could not load the message", Toast.LENGTH_SHORT).show()
                    return@withContext
                }
                SlideDialogBuilder(this@HomeworkActivity)
                    .setTitle(full.subject.ifBlank { "(no subject)" })
                    .setMessage("${full.fromName}\n\n${full.fullBody.ifBlank { "(empty message)" }}")
                    .setPositiveButton("OK", null)
                    .show()
                markMessageRead(message)
            }
        }
    }

    private fun markMessageRead(message: MessageSummary) {
        CoroutineScope(Dispatchers.IO).launch {
            val freshApi = RegisterApi(this@HomeworkActivity)
            val ok = freshApi.markMessageAsRead(message.id)
            withContext(Dispatchers.Main) {
                if (ok) {
                    unreadMessages = unreadMessages.filter { it.id != message.id }
                    render()
                } else {
                    Toast.makeText(
                        this@HomeworkActivity,
                        ErrorText.friendly(freshApi.lastError, "mark this as read"),
                        Toast.LENGTH_SHORT
                    ).show()
                    render() // re-enable the button row
                }
            }
        }
    }

    companion object {
        const val EXTRA_CATEGORY = "category"
        const val EXTRA_SEARCH = "search"
    }
}
