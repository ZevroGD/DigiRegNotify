package personal.digiregnotify

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var usernameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var statusText: TextView
    private lateinit var api: RegisterApi

    private val notificationPermissionRequestCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        api = RegisterApi(this)

        usernameInput = findViewById(R.id.usernameInput)
        passwordInput = findViewById(R.id.passwordInput)
        intervalInput = findViewById(R.id.intervalInput)
        statusText = findViewById(R.id.statusText)

        intervalInput.setText(AlarmScheduler.getIntervalHours(this).toString())
        refreshStatus()

        requestNotificationPermissionIfNeeded()

        findViewById<Button>(R.id.saveButton).setOnClickListener { onSave() }
        findViewById<Button>(R.id.testButton).setOnClickListener { onTestNow() }
        findViewById<Button>(R.id.stopButton).setOnClickListener { onStop() }
    }

    private fun refreshStatus() {
        statusText.text = if (api.hasCredentials()) {
            "Signed in · checking every ${AlarmScheduler.getIntervalHours(this)}h"
        } else {
            "Not signed in"
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    notificationPermissionRequestCode
                )
            }
        }
    }

    private fun requestExactAlarmPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(AlarmManager::class.java)
            if (!am.canScheduleExactAlarms()) {
                Toast.makeText(
                    this,
                    "Please allow exact alarms so checks stay on schedule",
                    Toast.LENGTH_LONG
                ).show()
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        }
    }

    private fun onSave() {
        val username = usernameInput.text.toString().trim()
        val password = passwordInput.text.toString()
        val hours = intervalInput.text.toString().toIntOrNull() ?: 2

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter your username and password", Toast.LENGTH_SHORT).show()
            return
        }

        api.saveCredentials(username, password)
        AlarmScheduler.setIntervalHours(this, hours.coerceIn(1, 24))
        requestExactAlarmPermissionIfNeeded()
        AlarmScheduler.scheduleRepeating(this)

        passwordInput.text.clear()
        refreshStatus()
        Toast.makeText(this, "Saved. Checking every $hours hour(s).", Toast.LENGTH_SHORT).show()
    }

    private fun onTestNow() {
        if (!api.hasCredentials()) {
            Toast.makeText(this, "Save your credentials first", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Checking now…", Toast.LENGTH_SHORT).show()
        CoroutineScope(Dispatchers.IO).launch {
            val ok = api.login()
            val result = if (ok) {
                val dashboard = api.fetchDashboard()
                if (dashboard != null) {
                    val differ = DashboardDiffer(this@MainActivity)
                    val items = differ.parseItems(dashboard)
                    val newItems = differ.findNewItems(items)
                    NotificationHelper.notifyNewItems(this@MainActivity, newItems)
                    "Checked OK — ${items.size} items, ${newItems.size} new"
                } else {
                    "Login OK, but dashboard fetch failed"
                }
            } else {
                "Login failed — check your username/password"
            }
            withContext(Dispatchers.Main) {
                Toast.makeText(this@MainActivity, result, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun onStop() {
        AlarmScheduler.cancel(this)
        api.clearCredentials()
        refreshStatus()
        Toast.makeText(this, "Stopped and signed out", Toast.LENGTH_SHORT).show()
    }
}
