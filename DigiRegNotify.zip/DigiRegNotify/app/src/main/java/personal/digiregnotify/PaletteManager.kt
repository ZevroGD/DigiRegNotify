package personal.digiregnotify

import android.app.Activity
import android.content.Context
import android.content.res.Configuration

object PaletteManager {

    const val CUSTOM_KEY = "custom"

    data class Palette(
        val key: String,
        val displayName: String,
        val styleResId: Int,
        val amoledStyleResId: Int,
        // Color RESOURCE ids (not literal ints) so the preview swatch always
        // matches the color that's actually active in the current light/dark mode.
        val previewPrimaryRes: Int,
        val previewSecondaryRes: Int
    )

    val palettes = listOf(
        Palette(
            "ledger", "Ledger",
            R.style.Theme_DigiRegNotify, R.style.Theme_DigiRegNotify_Amoled,
            R.color.ink, R.color.amber
        ),
        Palette(
            "harbor", "Harbor",
            R.style.Theme_DigiRegNotify_Harbor, R.style.Theme_DigiRegNotify_Harbor_Amoled,
            R.color.harbor_primary, R.color.harbor_secondary
        ),
        Palette(
            "moss", "Moss",
            R.style.Theme_DigiRegNotify_Moss, R.style.Theme_DigiRegNotify_Moss_Amoled,
            R.color.moss_primary, R.color.moss_secondary
        ),
        Palette(
            "plum", "Plum",
            R.style.Theme_DigiRegNotify_Plum, R.style.Theme_DigiRegNotify_Plum_Amoled,
            R.color.plum_primary, R.color.plum_secondary
        ),
        Palette(
            "ember", "Ember",
            R.style.Theme_DigiRegNotify_Ember, R.style.Theme_DigiRegNotify_Ember_Amoled,
            R.color.ember_primary, R.color.ember_secondary
        ),
        Palette(
            "crimson", "Crimson",
            R.style.Theme_DigiRegNotify_Crimson, R.style.Theme_DigiRegNotify_Crimson_Amoled,
            R.color.crimson_primary, R.color.crimson_secondary
        ),
        Palette(
            "indigo", "Indigo",
            R.style.Theme_DigiRegNotify_Indigo, R.style.Theme_DigiRegNotify_Indigo_Amoled,
            R.color.indigo_primary, R.color.indigo_secondary
        ),
        Palette(
            "rose", "Rose",
            R.style.Theme_DigiRegNotify_Rose, R.style.Theme_DigiRegNotify_Rose_Amoled,
            R.color.rose_primary, R.color.rose_secondary
        ),
        Palette(
            "lagoon", "Lagoon",
            R.style.Theme_DigiRegNotify_Lagoon, R.style.Theme_DigiRegNotify_Lagoon_Amoled,
            R.color.lagoon_primary, R.color.lagoon_secondary
        ),
        Palette(
            "violet", "Violet",
            R.style.Theme_DigiRegNotify_Violet, R.style.Theme_DigiRegNotify_Violet_Amoled,
            R.color.violet_primary, R.color.violet_secondary
        ),
        // Always last. Its two colors are picked by the user (see CustomThemeDialog).
        Palette(
            CUSTOM_KEY, "Custom",
            R.style.Theme_DigiRegNotify_Custom, R.style.Theme_DigiRegNotify_Custom_Amoled,
            R.color.harbor_primary, R.color.harbor_primary // unused: the swatch shows the chosen colours
        )
    )

    private const val PREFS = "digireg_settings"
    private const val KEY_PALETTE = "palette_key"
    private const val KEY_AMOLED = "amoled_enabled"
    private const val KEY_CUSTOM_PRIMARY = "custom_primary_idx"
    private const val KEY_CUSTOM_SECONDARY = "custom_secondary_idx"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Index (0-55) into [CustomColors.argb] of the chosen primary / secondary colour. */
    fun getCustomPrimaryIndex(context: Context): Int =
        prefs(context).getInt(KEY_CUSTOM_PRIMARY, CustomColors.DEFAULT_PRIMARY)
            .coerceIn(0, CustomColors.argb.size - 1)

    fun getCustomSecondaryIndex(context: Context): Int =
        prefs(context).getInt(KEY_CUSTOM_SECONDARY, CustomColors.DEFAULT_SECONDARY)
            .coerceIn(0, CustomColors.argb.size - 1)

    fun getCustomPrimary(context: Context): Int = CustomColors.argb[getCustomPrimaryIndex(context)]
    fun getCustomSecondary(context: Context): Int = CustomColors.argb[getCustomSecondaryIndex(context)]

    fun setCustomColors(context: Context, primaryIndex: Int, secondaryIndex: Int) {
        prefs(context).edit()
            .putInt(KEY_CUSTOM_PRIMARY, primaryIndex)
            .putInt(KEY_CUSTOM_SECONDARY, secondaryIndex)
            .apply()
    }

    /** Changes whenever the look changes — screens compare it to know when to recreate. */
    fun getAppearanceSignature(context: Context): String {
        val key = getSelectedKey(context)
        return if (key == CUSTOM_KEY) "$key:${getCustomPrimaryIndex(context)}:${getCustomSecondaryIndex(context)}" else key
    }

    /**
     * The Custom theme. A theme's colours can't be chosen at runtime, so every colour of the
     * fixed grid has a ready-made overlay style (res/values/custom_palette.xml). This layers
     * the chosen two on top of the activity's theme: plain theme mechanics, the same as the
     * other palettes, and nothing is swapped in the app's resources. Must run right after
     * setTheme(), before the layout is inflated.
     */
    fun applyCustomOverlays(activity: Activity) {
        if (getSelectedKey(activity) != CUSTOM_KEY) return
        val primary = overlayStyle(activity, "CustomPrimary_${getCustomPrimaryIndex(activity)}")
        val secondary = overlayStyle(activity, "CustomSecondary_${getCustomSecondaryIndex(activity)}")
        if (primary != 0) activity.theme.applyStyle(primary, true)
        if (secondary != 0) activity.theme.applyStyle(secondary, true)
    }

    private fun overlayStyle(context: Context, name: String): Int =
        context.resources.getIdentifier(name, "style", context.packageName)

    fun getSelectedKey(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PALETTE, "ledger") ?: "ledger"

    fun setSelectedKey(context: Context, key: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_PALETTE, key).apply()
    }

    fun isAmoledEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_AMOLED, false)

    fun setAmoledEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_AMOLED, enabled).apply()
    }

    private fun isNightModeActive(context: Context): Boolean {
        val flags = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return flags == Configuration.UI_MODE_NIGHT_YES
    }

    fun getSelectedPalette(context: Context): Palette =
        palettes.find { it.key == getSelectedKey(context) } ?: palettes.first()

    /** The style to actually apply, accounting for the AMOLED toggle —
     *  which only takes effect while dark mode is currently active. */
    fun getStyleResId(context: Context): Int {
        val palette = getSelectedPalette(context)
        return if (isAmoledEnabled(context) && isNightModeActive(context)) {
            palette.amoledStyleResId
        } else {
            palette.styleResId
        }
    }
}
