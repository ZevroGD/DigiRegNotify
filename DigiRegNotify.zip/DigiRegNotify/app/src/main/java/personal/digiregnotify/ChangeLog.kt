package personal.digiregnotify

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ChangeLogEntry(
    val timestamp: Long,
    val type: String,     // "changed" or "deleted"
    val itemType: String, // "grade" or "gradeGroup"
    val summary: String
)

object ChangeLog {
    private const val PREFS = "digireg_change_log"
    private const val KEY = "entries"
    private const val MAX_ENTRIES = 150

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun append(context: Context, entries: List<ChangeLogEntry>) {
        if (entries.isEmpty()) return
        val combined = (entries + getAll(context)).take(MAX_ENTRIES) // newest first
        save(context, combined)
    }

    fun getAll(context: Context): List<ChangeLogEntry> {
        val raw = prefs(context).getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                ChangeLogEntry(
                    timestamp = o.optLong("ts"),
                    type = o.optString("type"),
                    itemType = o.optString("itemType"),
                    summary = o.optString("summary")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun clear(context: Context) {
        prefs(context).edit().remove(KEY).apply()
    }

    private fun save(context: Context, entries: List<ChangeLogEntry>) {
        val arr = JSONArray()
        for (e in entries) {
            arr.put(JSONObject().apply {
                put("ts", e.timestamp)
                put("type", e.type)
                put("itemType", e.itemType)
                put("summary", e.summary)
            })
        }
        prefs(context).edit().putString(KEY, arr.toString()).apply()
    }
}
