## What's new in 1.2

**New**
- **Updates from inside the app.** Settings → Updates finds the newest release on GitHub, shows its notes and installs it. It can also check automatically about twice a day and notify you, and you can choose which installer app does the installing (Developer menu → Update installer).
- **A smoother timetable.** Swipe sideways through the weeks, with a Today button, double hours shown as one tall tile, and every period kept in its row.
- **Teacher observations (Beobachtungen)** under each subject on the Marks screen, with their real text in History, plus a notification for new ones.
