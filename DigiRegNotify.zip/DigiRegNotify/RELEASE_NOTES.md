## What's new

**Changed**
- When the school's server can't be reached, Home shows the last saved homework list, with a note of when it was saved and why it couldn't refresh.
- Clearer messages: no internet, school server not answering, school server error, signed out, or sign-in rejected.
- Failing faster: the connection attempt gives up after 8 seconds, and an unreachable server is no longer retried straight away or followed by a pointless login.

**Fixed**
- The chart inside a subject's marks now really shows the grade lines, numbers and each mark's value. It only covers the range of the marks.
