package personal.digiregnotify

import org.json.JSONArray
import org.json.JSONObject

data class MessageSummary(
    val id: Long,
    val fromName: String,
    val subject: String,
    val timeSent: String,
    val isUnread: Boolean,
    val bodyPreview: String
)

object MessageParser {

    fun parse(json: String): List<MessageSummary> {
        val array = JSONArray(json)
        val result = mutableListOf<MessageSummary>()
        for (i in 0 until array.length()) {
            val m = array.optJSONObject(i) ?: continue
            result.add(
                MessageSummary(
                    id = m.optLong("id"),
                    fromName = m.optString("fromName"),
                    subject = m.optString("subject"),
                    timeSent = m.optString("timeSent"),
                    isUnread = m.isNull("timeRead") || !m.has("timeRead"),
                    bodyPreview = extractPlainText(m.optString("text")).take(180)
                )
            )
        }
        // Newest first.
        return result.sortedByDescending { it.timeSent }
    }

    /** The body is Quill "delta" JSON ({"ops":[{"insert":"..."},...]}) — pull the plain text out. */
    private fun extractPlainText(deltaJson: String): String {
        if (deltaJson.isBlank()) return ""
        return try {
            val ops = JSONObject(deltaJson).optJSONArray("ops") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until ops.length()) {
                val insert = ops.optJSONObject(i)?.opt("insert")
                if (insert is String) sb.append(insert)
            }
            sb.toString().replace(Regex("\\s+"), " ").trim()
        } catch (e: Exception) {
            deltaJson.take(180) // not delta JSON after all — show it raw rather than nothing
        }
    }
}
