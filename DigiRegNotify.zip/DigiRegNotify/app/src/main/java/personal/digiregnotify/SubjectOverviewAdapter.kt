package personal.digiregnotify

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Locale

data class SubjectOverviewRow(
    val summary: SubjectSummary,
    val displayName: String,
    val color: Int,
    val averageText: String
)

/** One row per subject; tapping a subject that has grades slides open its exact marks. */
class SubjectOverviewAdapter(
    private var rows: List<SubjectOverviewRow>
) : RecyclerView.Adapter<SubjectOverviewAdapter.ViewHolder>() {

    private val expandedIds = mutableSetOf<Int>()
    private val isoDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val shortDate = SimpleDateFormat("dd.MM.yy", Locale.getDefault())

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val header: View = view.findViewById(R.id.overviewRowHeader)
        val dot: View = view.findViewById(R.id.overviewRowColorDot)
        val name: TextView = view.findViewById(R.id.overviewRowName)
        val detail: TextView = view.findViewById(R.id.overviewRowDetail)
        val average: TextView = view.findViewById(R.id.overviewRowAverage)
        val chevron: TextView = view.findViewById(R.id.overviewRowChevron)
        val expanded: View = view.findViewById(R.id.overviewRowExpanded)
        val chart: GradeChartView = view.findViewById(R.id.overviewRowChart)
        val grades: LinearLayout = view.findViewById(R.id.overviewRowGrades)
    }

    fun updateRows(newRows: List<SubjectOverviewRow>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_subject_overview_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val row = rows[position]
        val summary = row.summary
        val count = summary.grades.size
        val id = summary.subjectId

        holder.name.text = row.displayName
        holder.average.text = row.averageText
        holder.detail.text = when (count) {
            0 -> "No grades yet"
            1 -> "1 grade"
            else -> "$count grades"
        }
        holder.average.alpha = if (count == 0) 0.4f else 1f
        (holder.dot.background.mutate() as GradientDrawable).setColor(row.color)

        val expandable = count > 0
        holder.chevron.visibility = if (expandable) View.VISIBLE else View.INVISIBLE
        if (!expandable) expandedIds.remove(id)
        val isOpen = id in expandedIds

        // The marks themselves, newest first.
        holder.grades.removeAllViews()
        val inflater = LayoutInflater.from(holder.itemView.context)
        for (g in summary.grades.asReversed()) {
            val line = inflater.inflate(R.layout.item_grade_line, holder.grades, false)
            val date = try {
                isoDate.parse(g.date)?.let { shortDate.format(it) } ?: g.date
            } catch (e: Exception) {
                g.date
            }
            val title = listOf(g.type, g.description).filter { it.isNotBlank() }.joinToString(" · ")
            line.findViewById<TextView>(R.id.gradeLineTitle).text = title.ifBlank { "Grade" }
            val sub = buildString {
                append(date)
                if (g.weight != 100) append(" · ${g.weight}%")
            }
            line.findViewById<TextView>(R.id.gradeLineSub).text = sub
            line.findViewById<TextView>(R.id.gradeLineValue).text = formatValue(g.value)
            holder.grades.addView(line)
        }
        if (count >= 2) {
            holder.chart.visibility = View.VISIBLE
            holder.chart.setValues(summary.grades.map { it.value })
        } else {
            holder.chart.visibility = View.GONE
        }

        // Restore state without animating (rows get re-bound while scrolling).
        holder.expanded.visibility = if (isOpen) View.VISIBLE else View.GONE
        holder.expanded.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
        holder.expanded.alpha = 1f
        Expand.rotateChevron(holder.chevron, isOpen, animate = false)

        holder.header.setOnClickListener {
            if (!expandable) return@setOnClickListener
            if (id in expandedIds) {
                expandedIds.remove(id)
                Expand.collapse(holder.expanded)
                Expand.rotateChevron(holder.chevron, false)
            } else {
                expandedIds.add(id)
                Expand.expand(holder.expanded)
                Expand.rotateChevron(holder.chevron, true)
            }
        }
    }

    /** 8.0 -> "8", 8.75 -> "8.75", 8.5 -> "8.5". */
    private fun formatValue(v: Float): String =
        String.format(Locale.getDefault(), "%.2f", v).trimEnd('0').trimEnd('.', ',')

    override fun getItemCount(): Int = rows.size
}
