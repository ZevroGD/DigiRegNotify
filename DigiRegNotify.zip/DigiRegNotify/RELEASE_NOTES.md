## What's new

**Fixed**
- The "All subjects" and "Chart lines" headers on the Marks screen no longer show a grainy grey square when tapped. They get a soft rounded highlight instead, and so do the subject rows inside.
