package personal.digiregnotify

import android.content.Context
import android.util.Log
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

sealed class CheckResult {
    data class Success(
        val totalItems: Int,
        val newItems: Int,
        val newMessages: Int = 0,
        val timetableChanged: Boolean = false
    ) : CheckResult()

    object NoConnection : CheckResult()
    data class Failure(val message: String) : CheckResult()
}

object CheckRunner {

    private const val TAG = "DigiReg"

    /**
     * One full check: dashboard (new grades / homework / teacher notes), unread messages,
     * and timetable changes. Used by both the scheduled alarm and the manual button, so
     * "run a check" always means exactly the same thing.
     */
    fun performCheck(context: Context): CheckResult {
        val api = RegisterApi(context)
        if (!api.hasCredentials()) return CheckResult.Failure("Not signed in")

        if (!NetworkUtil.isConnected(context)) {
            return CheckResult.NoConnection
        }

        val dashboardJson = api.fetchDashboardWithAutoLogin()
            ?: return CheckResult.Failure(api.lastError ?: "Could not log in or fetch data")

        val differ = DashboardDiffer(context)
        val items = differ.parseItems(dashboardJson)
        val newItems = differ.findNewItems(items)

        // Isolated: a bug here should never break the main check above.
        try {
            ChangeDetector.detectAndLog(context, items)
        } catch (e: Exception) {
            Log.w(TAG, "Change detection failed", e)
        }

        val filtered = newItems.filter { item ->
            when (item.type) {
                "grade" -> NotificationPrefs.isGradesEnabled(context)
                "gradeGroup", "observation" -> NotificationPrefs.isHomeworkEnabled(context)
                else -> true
            }
        }
        // Separate notifications per kind, so each has a single, unambiguous tap target
        // (Marks for grades, Home for homework/notes) instead of one that can't deep-link.
        val (newGrades, newHomework) = filtered.partition { it.type == "grade" }
        NotificationHelper.notifyNewGrades(context, newGrades)
        NotificationHelper.notifyNewHomework(context, newHomework)

        // The extras below must never break the main check above, so each is isolated.
        val newMessages = try {
            checkMessages(context, api)
        } catch (e: Exception) {
            Log.w(TAG, "Message check failed", e)
            0
        }
        val timetableChanged = try {
            checkTimetable(context, api)
        } catch (e: Exception) {
            Log.w(TAG, "Timetable check failed", e)
            false
        }

        return CheckResult.Success(items.size, filtered.size, newMessages, timetableChanged)
    }

    /** Notifies about unread messages we haven't announced yet. Returns how many were announced. */
    private fun checkMessages(context: Context, api: RegisterApi): Int {
        val unreadJson = api.fetchUnreadNotifications() ?: return 0
        val array = JSONArray(unreadJson)

        // notification id -> the message's id
        val unread = mutableMapOf<String, Long>()
        for (i in 0 until array.length()) {
            val n = array.optJSONObject(i) ?: continue
            if (n.optString("type") == "message") {
                unread[n.optString("id")] = n.optLong("objectId")
            }
        }

        // Always record what we've seen, even with the toggle off, so switching it on
        // later doesn't suddenly announce old messages.
        val newIds = ChangeTracker.newMessageNotificationIds(context, unread.keys.toSet())
        if (newIds.isEmpty() || !NotificationPrefs.isMessagesEnabled(context)) return 0

        // The notification itself only says "new message"; look up sender and subject
        // in the inbox (read-only: we never mark anything as read).
        val wanted = newIds.mapNotNull { unread[it] }.toSet()
        val previews = mutableListOf<MessagePreview>()
        api.fetchMessages()?.let { text ->
            val messages = JSONArray(text)
            for (i in 0 until messages.length()) {
                val m = messages.optJSONObject(i) ?: continue
                if (m.optLong("id") in wanted) {
                    previews.add(MessagePreview(m.optLong("id"), m.optString("fromName"), m.optString("subject")))
                }
            }
        }
        val toShow = if (previews.isNotEmpty()) previews else newIds.mapNotNull { unread[it] }.map { MessagePreview(it, "", "") }

        NotificationHelper.notifyMessages(context, toShow)
        return toShow.size
    }

    /** Compares this and next week's timetable with the last check. Returns true if it notified. */
    private fun checkTimetable(context: Context, api: RegisterApi): Boolean {
        if (!NotificationPrefs.isCalendarEnabled(context)) {
            // So that switching it back on starts from a fresh baseline.
            ChangeTracker.clearTimetableSnapshot(context)
            return false
        }

        val format = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val monday = Calendar.getInstance()
        monday.add(Calendar.DAY_OF_YEAR, -((monday.get(Calendar.DAY_OF_WEEK) + 5) % 7))
        val thisWeek = format.format(monday.time)
        monday.add(Calendar.DAY_OF_YEAR, 7)
        val nextWeek = format.format(monday.time)

        // Need both weeks, otherwise a half snapshot would look like lessons vanishing.
        val first = api.fetchCalendarWeek(thisWeek) ?: return false
        val second = api.fetchCalendarWeek(nextWeek) ?: return false
        val a = TimetableParser.parseWeek(first)
        val b = TimetableParser.parseWeek(second)

        val summary = TimetableChanges.detect(
            context = context,
            lessons = a.lessons + b.lessons,
            fetchedDates = (a.dates + b.dates).toSet(),
            today = format.format(Calendar.getInstance().time)
        ) ?: return false

        NotificationHelper.notifyTimetableChanged(context, summary)
        return true
    }
}
