package personal.digiregnotify

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class DashboardItem(
    val id: String,
    val type: String,
    val title: String,
    val subtitle: String,
    val label: String = "",
    val grade: String? = null,
    val deadline: String? = null,
    val checkable: Boolean = false,
    val checked: Boolean = false,
    /** The day group this item came under (yyyy-MM-dd). Marks and observations only have this. */
    val date: String = "",
    /** Attachments ("Anhang") of a homework item: description text, links, files. */
    val submissions: List<Submission> = emptyList()
)

/**
 * Remembers which dashboard item ids we've already seen, so we can figure
 * out which ones are new since the last check.
 */
class DashboardDiffer(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("digireg_seen_items", Context.MODE_PRIVATE)

    /** Parses the dashboard JSON (an array, or an array-of-groups) into a flat item list. */
    fun parseItems(dashboardJson: String): List<DashboardItem> {
        val items = mutableListOf<DashboardItem>()
        val root = JSONArray(dashboardJson)
        for (i in 0 until root.length()) {
            val group = root.optJSONObject(i) ?: continue
            val groupItems = group.optJSONArray("items") ?: continue
            for (j in 0 until groupItems.length()) {
                val item = groupItems.optJSONObject(j) ?: continue
                items.add(
                    DashboardItem(
                        id = item.optString("id", item.optString("category", "")),
                        type = item.optString("type", ""),
                        title = item.optString("title", ""),
                        subtitle = item.optString("subtitle", ""),
                        label = item.optString("label", ""),
                        grade = if (item.has("grade") && !item.isNull("grade")) item.optString("grade") else null,
                        deadline = if (item.has("deadline") && !item.isNull("deadline")) item.optString("deadline") else null,
                        checkable = item.optBoolean("checkable", false),
                        checked = item.optBoolean("checked", false),
                        date = group.optString("date", ""),
                        submissions = Submission.parseList(item.optJSONArray("gradeGroupSubmissions"), "gradeGroupId")
                    )
                )
            }
        }
        return items
    }

    /** Returns only the items not seen on a previous check, then remembers all current items. */
    fun findNewItems(items: List<DashboardItem>): List<DashboardItem> {
        // Keys include the type: grades and homework come from different tables, so a bare
        // id can collide (a new homework item numbered like an old grade would be treated
        // as already seen and never notified).
        fun key(item: DashboardItem) = "${item.type}:${item.id}"

        val hadBaseline = prefs.contains("seen_keys")
        // An empty list can be a stale-session artifact. Don't forget everything we've announced:
        // the next real list would then look entirely new and notify about all of it.
        if (items.isEmpty() && hadBaseline) return emptyList()
        val seen = prefs.getStringSet("seen_keys", emptySet()) ?: emptySet()

        val newItems = items.filter { key(it) !in seen }

        prefs.edit().putStringSet("seen_keys", items.map { key(it) }.toSet()).apply()

        // The very first run only records a baseline, so you aren't notified about
        // everything that already existed.
        return if (!hadBaseline) emptyList() else newItems
    }
}
