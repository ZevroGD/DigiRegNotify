package personal.digiregnotify

import android.content.Context
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** MaterialAlertDialogBuilder whose dialogs slide down in and up out. The animation is set on
 *  the dialog window directly, so it doesn't depend on theme resolution. */
class SlideDialogBuilder(context: Context) : MaterialAlertDialogBuilder(context) {
    override fun create(): AlertDialog {
        val dialog = super.create()
        dialog.window?.setWindowAnimations(R.style.Animation_DigiReg_Dialog)
        return dialog
    }
}
