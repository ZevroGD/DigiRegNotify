package personal.digiregnotify

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : BaseActivity() {

    private lateinit var api: RegisterApi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        api = RegisterApi(this)

        setUpChecking()
        setUpNotifications()
        setUpTheme()
        setUpAmoled()
        setUpPalette()
        setUpUpdates()

        findViewById<MaterialButton>(R.id.signOutButton).setOnClickListener {
            AlarmScheduler.cancel(this)
            api.clearCredentials()
            Toast.makeText(this, "Stopped and signed out", Toast.LENGTH_SHORT).show()
            finish()
        }

        findViewById<ImageButton>(R.id.backButton).setOnClickListener { finish() }
        findViewById<MaterialButton>(R.id.developerMenuButton).setOnClickListener {
            startActivity(Intent(this, DeveloperActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.manageSubjectsButton).setOnClickListener {
            startActivity(Intent(this, SubjectSettingsActivity::class.java))
        }
    }

    private fun setUpChecking() {
        val slider = findViewById<Slider>(R.id.intervalSlider)
        val valueText = findViewById<TextView>(R.id.intervalValueText)
        val pollingSwitch = findViewById<MaterialSwitch>(R.id.pollingSwitch)

        val currentHours = AlarmScheduler.getIntervalHours(this)
        slider.value = currentHours.toFloat()
        valueText.text = describeInterval(currentHours)

        val pollingEnabled = AlarmScheduler.isPollingEnabled(this)
        pollingSwitch.isChecked = pollingEnabled
        slider.isEnabled = pollingEnabled

        pollingSwitch.setOnCheckedChangeListener { _, isChecked ->
            slider.isEnabled = isChecked
            AlarmScheduler.setPollingEnabled(this, isChecked)
            if (isChecked) {
                if (api.hasCredentials()) AlarmScheduler.scheduleRepeating(this)
            } else {
                AlarmScheduler.cancel(this)
            }
        }

        slider.addOnChangeListener { _, value, fromUser ->
            val hours = value.toInt()
            valueText.text = describeInterval(hours)
            if (fromUser) {
                AlarmScheduler.setIntervalHours(this, hours)
                if (api.hasCredentials() && AlarmScheduler.isPollingEnabled(this)) {
                    AlarmScheduler.scheduleRepeating(this)
                }
            }
        }

        findViewById<MaterialButton>(R.id.openNotificationSettingsButton).setOnClickListener {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:$packageName"))
            }
            startActivity(intent)
        }

        findViewById<MaterialButton>(R.id.checkNowButton).setOnClickListener { runManualCheck() }
        showLastCheck()
    }

    private fun showLastCheck() {
        findViewById<TextView>(R.id.lastCheckText).text = CheckStatus.describe(this)
    }

    private fun runManualCheck() {
        val button = findViewById<MaterialButton>(R.id.checkNowButton)
        button.isEnabled = false
        button.text = "Checking…"

        CoroutineScope(Dispatchers.IO).launch {
            val result = CheckRunner.performCheck(this@SettingsActivity, CheckStatus.Source.MANUAL)
            withContext(Dispatchers.Main) {
                button.isEnabled = true
                button.text = "Check now"
                showLastCheck()

                val message = when (result) {
                    is CheckResult.Success ->
                        "Checked OK — ${result.totalItems} items, ${result.newItems} new"
                    is CheckResult.NoConnection ->
                        "No internet connection right now"
                    is CheckResult.Failure ->
                        "Check failed:\n\n${result.message}"
                }

                SlideDialogBuilder(this@SettingsActivity)
                    .setTitle("Check result")
                    .setMessage(message)
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    private fun setUpNotifications() {
        val gradesSwitch = findViewById<MaterialSwitch>(R.id.notifyGradesSwitch)
        val homeworkSwitch = findViewById<MaterialSwitch>(R.id.notifyHomeworkSwitch)
        val messagesSwitch = findViewById<MaterialSwitch>(R.id.notifyMessagesSwitch)
        val calendarSwitch = findViewById<MaterialSwitch>(R.id.notifyCalendarSwitch)

        gradesSwitch.isChecked = NotificationPrefs.isGradesEnabled(this)
        homeworkSwitch.isChecked = NotificationPrefs.isHomeworkEnabled(this)
        messagesSwitch.isChecked = NotificationPrefs.isMessagesEnabled(this)
        calendarSwitch.isChecked = NotificationPrefs.isCalendarEnabled(this)

        gradesSwitch.setOnCheckedChangeListener { _, isChecked ->
            NotificationPrefs.setGradesEnabled(this, isChecked)
        }
        homeworkSwitch.setOnCheckedChangeListener { _, isChecked ->
            NotificationPrefs.setHomeworkEnabled(this, isChecked)
        }
        messagesSwitch.setOnCheckedChangeListener { _, isChecked ->
            NotificationPrefs.setMessagesEnabled(this, isChecked)
        }
        calendarSwitch.setOnCheckedChangeListener { _, isChecked ->
            NotificationPrefs.setCalendarEnabled(this, isChecked)
        }
    }

    private fun setUpTheme() {
        val systemButton = findViewById<MaterialButton>(R.id.themeSystemButton)
        val lightButton = findViewById<MaterialButton>(R.id.themeLightButton)
        val darkButton = findViewById<MaterialButton>(R.id.themeDarkButton)

        val currentButtonId = when (ThemeManager.getMode(this)) {
            ThemeManager.MODE_LIGHT -> R.id.themeLightButton
            ThemeManager.MODE_DARK -> R.id.themeDarkButton
            else -> R.id.themeSystemButton
        }
        findViewById<com.google.android.material.button.MaterialButtonToggleGroup>(R.id.themeToggleGroup)
            .check(currentButtonId)

        systemButton.setOnClickListener { ThemeManager.setMode(this, ThemeManager.MODE_SYSTEM) }
        lightButton.setOnClickListener { ThemeManager.setMode(this, ThemeManager.MODE_LIGHT) }
        darkButton.setOnClickListener { ThemeManager.setMode(this, ThemeManager.MODE_DARK) }
    }

    private fun describeInterval(hours: Int): String =
        if (hours == 1) "Every hour" else "Every $hours hours"

    private fun setUpAmoled() {
        val amoledSwitch = findViewById<MaterialSwitch>(R.id.amoledSwitch)
        amoledSwitch.isChecked = PaletteManager.isAmoledEnabled(this)
        amoledSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked != PaletteManager.isAmoledEnabled(this)) {
                PaletteManager.setAmoledEnabled(this, isChecked)
                recreate()
            }
        }
    }

    private fun setUpPalette() {
        val container = findViewById<android.widget.LinearLayout>(R.id.paletteContainer)
        val selectedKey = PaletteManager.getSelectedKey(this)
        val inflater = layoutInflater

        container.removeAllViews()
        for (palette in PaletteManager.palettes) {
            val swatchView = inflater.inflate(R.layout.item_palette_swatch, container, false)

            val card = swatchView.findViewById<com.google.android.material.card.MaterialCardView>(R.id.swatchCard)
            val primaryView = swatchView.findViewById<android.view.View>(R.id.swatchPrimary)
            val secondaryView = swatchView.findViewById<android.view.View>(R.id.swatchSecondary)
            val label = swatchView.findViewById<TextView>(R.id.swatchLabel)

            // Resolve from color RESOURCES (not fixed literals) so the preview
            // matches whichever of light/dark mode is actually active right now.
            val isCustom = palette.key == PaletteManager.CUSTOM_KEY
            val primaryColor = if (isCustom) PaletteManager.getCustomPrimary(this)
                else androidx.core.content.ContextCompat.getColor(this, palette.previewPrimaryRes)
            val secondaryColor = if (isCustom) PaletteManager.getCustomSecondary(this)
                else androidx.core.content.ContextCompat.getColor(this, palette.previewSecondaryRes)

            primaryView.setBackgroundColor(primaryColor)
            // The dot has a real oval shape (dot_shape.xml) — tint it in place
            // rather than setBackgroundColor, which would flatten it to a square.
            (secondaryView.background.mutate() as android.graphics.drawable.GradientDrawable)
                .setColor(secondaryColor)
            label.text = palette.displayName

            val isSelected = palette.key == selectedKey
            card.strokeWidth = if (isSelected) 4 else 2
            card.strokeColor = if (isSelected) {
                secondaryColor
            } else {
                androidx.core.content.ContextCompat.getColor(this, R.color.hairline)
            }

            swatchView.setOnClickListener {
                if (isCustom) {
                    // Always opens the color picker; saving it selects the Custom palette.
                    CustomThemeDialog.show(this) { recreate() }
                } else if (palette.key != PaletteManager.getSelectedKey(this)) {
                    PaletteManager.setSelectedKey(this, palette.key)
                    recreate()
                }
            }

            container.addView(swatchView)
            (swatchView.layoutParams as android.widget.LinearLayout.LayoutParams).marginEnd = 12
        }
    }
    // ---- Updates ---------------------------------------------------------------------------

    private fun setUpUpdates() {
        val status = findViewById<TextView>(R.id.updateStatusText)
        val autoSwitch = findViewById<MaterialSwitch>(R.id.updateAutoSwitch)
        status.text = "Version ${UpdateChecker.currentVersion(this)}"
        autoSwitch.isChecked = UpdateChecker.isAutoCheckEnabled(this) && UpdateChecker.hasToken(this)

        autoSwitch.setOnCheckedChangeListener { button, checked ->
            if (checked && !UpdateChecker.hasToken(this)) {
                // Automatic checking needs the token first; switch on only once it is saved.
                button.isChecked = false
                showAccessDialog { autoSwitch.isChecked = true }
                return@setOnCheckedChangeListener
            }
            UpdateChecker.setAutoCheck(this, checked)
        }
        findViewById<MaterialButton>(R.id.updateTokenButton).setOnClickListener { showAccessDialog() }
        findViewById<MaterialButton>(R.id.checkUpdateButton).setOnClickListener { runUpdateCheck() }

    }

    /** Repository and read-only token for the private GitHub repo. Saved encrypted on this phone. */
    private fun showAccessDialog(onSaved: () -> Unit = {}) {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val column = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        val repoField = android.widget.EditText(this).apply {
            hint = "Repository (owner/name)"
            setText(UpdateChecker.getRepo(this@SettingsActivity))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        val tokenField = android.widget.EditText(this).apply {
            hint = if (UpdateChecker.hasToken(this@SettingsActivity)) "Token (saved; type to replace)" else "Token"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        column.addView(repoField)
        column.addView(tokenField)

        SlideDialogBuilder(this)
            .setTitle("GitHub access")
            .setView(column)
            .setPositiveButton("Save") { _, _ ->
                val repo = repoField.text.toString().trim()
                val token = tokenField.text.toString().trim()
                if (!repo.contains("/")) {
                    Toast.makeText(this, "Use the form owner/name", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                UpdateChecker.saveAccess(this, repo, token.ifBlank { null })
                if (UpdateChecker.hasToken(this)) onSaved()
            }
            .setNeutralButton("Remove token") { _, _ ->
                UpdateChecker.clearToken(this)
                UpdateChecker.setAutoCheck(this, false)
                findViewById<MaterialSwitch>(R.id.updateAutoSwitch).isChecked = false
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun runUpdateCheck() {
        if (!UpdateChecker.hasToken(this)) {
            showAccessDialog { runUpdateCheck() }
            return
        }
        val button = findViewById<MaterialButton>(R.id.checkUpdateButton)
        val status = findViewById<TextView>(R.id.updateStatusText)
        button.isEnabled = false
        button.text = "Checking…"
        CoroutineScope(Dispatchers.IO).launch {
            val result = UpdateChecker.check(this@SettingsActivity)
            withContext(Dispatchers.Main) {
                button.isEnabled = true
                button.text = "Check for update"
                when (result) {
                    is UpdateResult.NoToken -> showAccessDialog { runUpdateCheck() }
                    is UpdateResult.NoConnection -> status.text = "No connection"
                    is UpdateResult.UpToDate -> status.text = "Up to date · ${result.version}"
                    is UpdateResult.Available -> {
                        status.text = "Update available · ${result.info.version}"
                        UpdateDialogs.show(this@SettingsActivity, result.info)
                    }
                    is UpdateResult.Failure -> {
                        status.text = "Couldn't check"
                        Toast.makeText(this@SettingsActivity, result.message, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }
}
