package personal.digiregnotify

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Everything needed to talk to Digitales Register, based on the real
 * requests captured from the browser:
 *   POST /v2/api/auth/login            {"username":..,"password":..} -> sets cookies
 *   POST /v2/api/student/dashboard/dashboard  {"viewFuture":true}    -> grades/homework
 */
class RegisterApi(context: Context) {

    private val baseUrl = "https://franziskanergymnasium.digitalesregister.it/v2"
    private val origin = "https://franziskanergymnasium.digitalesregister.it"

    /** Set after any failed login/fetch, so the UI can show what actually went wrong. */
    var lastError: String? = null
        private set

    // Cookies persisted across app/process restarts, since AlarmManager
    // wakes up a fresh process each time.
    private val cookiePrefs: SharedPreferences = encryptedPrefs(context, "digireg_cookies")
    private val credPrefs: SharedPreferences = encryptedPrefs(context, "digireg_credentials")

    private fun encryptedPrefs(context: Context, name: String): SharedPreferences {
        // MasterKey touches the Android Keystore, which is slow enough to matter given how
        // often a new RegisterApi gets created (every screen, every background check). Reused
        // across instances instead of rederiving it each time.
        val masterKey = cachedMasterKey ?: MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build().also { cachedMasterKey = it }
        return EncryptedSharedPreferences.create(
            context, name, masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    companion object {
        @Volatile
        private var cachedMasterKey: MasterKey? = null
    }

    private val persistentCookieJar = object : CookieJar {
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            val editor = cookiePrefs.edit()
            for (c in cookies) {
                editor.putString(c.name, "${c.value}|${c.expiresAt}")
            }
            editor.apply()
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val result = mutableListOf<Cookie>()
            for ((name, raw) in cookiePrefs.all) {
                val value = raw as? String ?: continue
                val parts = value.split("|")
                val cookieValue = parts.getOrNull(0) ?: continue
                result.add(
                    Cookie.Builder()
                        .name(name)
                        .value(cookieValue)
                        .domain(url.host)
                        .path("/")
                        .build()
                )
            }
            return result
        }
    }

    private val client = OkHttpClient.Builder()
        .cookieJar(persistentCookieJar)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMedia = "application/json;charset=utf-8".toMediaType()

    fun saveCredentials(username: String, password: String) {
        credPrefs.edit()
            .putString("username", username)
            .putString("password", password)
            .apply()
    }

    fun hasCredentials(): Boolean =
        credPrefs.getString("username", null) != null &&
            credPrefs.getString("password", null) != null

    fun clearCredentials() {
        credPrefs.edit().clear().apply()
        cookiePrefs.edit().clear().apply()
    }

    /** Logs in fresh. If username/password are omitted, uses the saved credentials.
     *  Only persists new credentials when explicitly told to via saveCredentials(). */
    fun login(username: String? = null, password: String? = null): Boolean {
        val user = username ?: credPrefs.getString("username", null) ?: return false
        val pass = password ?: credPrefs.getString("password", null) ?: return false

        val body = JSONObject()
            .put("username", user)
            .put("password", pass)
            .toString()
            .toRequestBody(jsonMedia)

        val request = Request.Builder()
            .url("$baseUrl/api/auth/login")
            .header("Accept", "application/json, text/plain, */*")
            .header("Content-Type", "application/json;charset=utf-8")
            .header("Origin", "https://franziskanergymnasium.digitalesregister.it")
            .header("Referer", "https://franziskanergymnasium.digitalesregister.it/v2/login")
            .post(body)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "login HTTP ${response.code}: ${response.body?.string()?.take(200)}"
                    return false
                }
                val text = response.body?.string() ?: run {
                    lastError = "login: empty response body"
                    return false
                }
                val json = JSONObject(text)
                val loggedIn = json.optBoolean("loggedIn", false)
                if (!loggedIn) {
                    lastError = "login response: ${text.take(200)}"
                }
                return loggedIn
            }
        } catch (e: Exception) {
            lastError = "login exception: ${e.javaClass.simpleName}: ${e.message}"
            return false
        }
    }

    /** Fetches the dashboard (grades, homework, etc). Returns raw JSON text, or null on failure. */
    fun fetchDashboard(): String? {
        val body = JSONObject()
            .put("viewFuture", true)
            .toString()
            .toRequestBody(jsonMedia)

        val request = Request.Builder()
            .url("$baseUrl/api/student/dashboard/dashboard")
            .header("Accept", "application/json, text/plain, */*")
            .header("Content-Type", "application/json;charset=utf-8")
            .header("Origin", "https://franziskanergymnasium.digitalesregister.it")
            .header("Referer", "https://franziskanergymnasium.digitalesregister.it/v2/")
            .post(body)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "dashboard HTTP ${response.code}: ${response.body?.string()?.take(200)}"
                    return null
                }
                return response.body?.string()
            }
        } catch (e: Exception) {
            lastError = "dashboard exception: ${e.javaClass.simpleName}: ${e.message}"
            return null
        }
    }

    /**
     * Convenience: tries the dashboard with existing cookies; if that looks
     * like it failed (empty/invalid), logs in fresh and retries once.
     */
    /** The dashboard is always a JSON array of day-groups — requiring that specifically
     *  (not just "starts with a bracket") is what catches a stale/expired session, which
     *  can come back as a thin JSON object instead of throwing an outright error. This was
     *  the one endpoint still using the old loose check, despite being the most-used one. */
    fun fetchDashboardWithAutoLogin(): String? {
        val isValidDashboard: (String) -> Boolean = { text ->
            try {
                JSONArray(text); true
            } catch (e: Exception) {
                false
            }
        }
        val first = fetchDashboard()
        if (first != null && isValidDashboard(first)) return first
        if (!login()) return null
        val second = fetchDashboard()
        return if (second != null && isValidDashboard(second)) second else null
    }

    // ---------------------------------------------------------------------
    // Generic helpers for the endpoints below (all captured from the real site)
    // ---------------------------------------------------------------------

    /** POST JSON to /v2/api/<path>. Returns the response text, or null (see lastError). */
    private fun postApi(path: String, body: JSONObject): String? {
        val request = Request.Builder()
            .url("$baseUrl/api/$path")
            .header("Accept", "application/json, text/plain, */*")
            .header("Content-Type", "application/json;charset=utf-8")
            .header("Origin", origin)
            .header("Referer", "$origin/v2/")
            .post(body.toString().toRequestBody(jsonMedia))
            .build()
        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "$path HTTP ${response.code}: ${response.body?.string()?.take(200)}"
                    null
                } else {
                    response.body?.string()
                }
            }
        } catch (e: Exception) {
            lastError = "$path exception: ${e.javaClass.simpleName}: ${e.message}"
            null
        }
    }

    /** Like postApi, but if the reply doesn't look like real data (expired session — which
     *  can come back as an HTML login page, a 401, OR a thin/empty-looking JSON object that
     *  passes a naive "starts with { or [" check but isn't actually the data asked for) logs
     *  in once and retries. [isValid] lets each endpoint define what "real data" looks like;
     *  the default is deliberately loose, so endpoints that need better certainty pass their
     *  own check (e.g. "has a 'subjects' key", "has at least one date key"). */
    private fun postApiWithAutoLogin(
        path: String,
        body: JSONObject,
        isValid: (String) -> Boolean = ::looksValid
    ): String? {
        val first = postApi(path, body)
        if (first != null && isValid(first)) return first
        if (!login()) return null
        val second = postApi(path, body)
        return if (second != null && isValid(second)) second else null
    }

    /**
     * Ticks / unticks a homework item on the server.
     *   POST /api/student/dashboard/toggle_reminder {"id":..,"type":"gradeGroup","value":true}
     *   -> {"success":true}
     */
    fun toggleReminder(id: String, type: String, value: Boolean): Boolean {
        val idValue: Any = id.toLongOrNull() ?: id
        fun attempt(): Boolean {
            val body = JSONObject().put("id", idValue).put("type", type).put("value", value)
            val text = postApi("student/dashboard/toggle_reminder", body) ?: return false
            return try {
                JSONObject(text).optBoolean("success", false)
            } catch (e: Exception) {
                lastError = "toggle_reminder: unexpected reply"
                false
            }
        }
        if (attempt()) return true
        if (!login()) return false
        return attempt()
    }

    /**
     * The student's numeric id, which the marks endpoints require. It isn't in any API
     * reply we can rely on, but the app's HTML page embeds it as `var currentUserId=...;`.
     */
    fun getStudentId(): Long? {
        credPrefs.getString("student_id", null)?.toLongOrNull()?.let { return it }

        val request = Request.Builder()
            .url("$baseUrl/")
            .header("Accept", "text/html")
            .build()
        val html: String? = try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) response.body?.string() else null
            }
        } catch (e: Exception) {
            lastError = "student id exception: ${e.javaClass.simpleName}: ${e.message}"
            null
        }
        if (html == null) return null

        val id = Regex("""currentUserId\s*=\s*(\d+)""").find(html)?.groupValues?.get(1)?.toLongOrNull()
        if (id == null) {
            lastError = "could not find the student id (session expired?)"
            return null
        }
        credPrefs.edit().putString("student_id", id.toString()).apply()
        return id
    }

    /** All subjects with their grades and (server-weighted) averages, for whichever
     *  semester is currently active server-side. */
    fun fetchAllSubjects(): String? {
        var studentId = getStudentId()
        if (studentId == null) {
            if (!login()) return null
            studentId = getStudentId() ?: return null
        }
        return postApiWithAutoLogin(
            "student/all_subjects", JSONObject().put("studentId", studentId),
            isValid = { text ->
                try {
                    JSONObject(text).has("subjects")
                } catch (e: Exception) {
                    false
                }
            }
        )
    }

    /**
     * Switches which semester the server returns from subsequent calls (the site itself
     * does this via a plain page navigation, not a JSON API — there's no response body
     * to check, just whether the request succeeded).
     */
    fun switchSemester(semester: Int): Boolean {
        val request = Request.Builder()
            .url("$baseUrl/?semesterWechsel=$semester")
            .header("Accept", "text/html")
            .build()
        return try {
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            lastError = "switchSemester exception: ${e.javaClass.simpleName}: ${e.message}"
            false
        }
    }

    /** Fetches semester 1 and semester 2 in turn, leaving the server on semester 1 afterwards
     *  (so anything else that reads "the current semester" isn't left switched behind us). */
    fun fetchAllSubjectsBothSemesters(): Pair<String?, String?> {
        val first = fetchAllSubjects()
        if (!switchSemester(2)) return first to null
        val second = fetchAllSubjects()
        switchSemester(1)
        return first to second
    }

    /** Unread notifications (new marks and messages). */
    fun fetchUnreadNotifications(): String? =
        postApiWithAutoLogin("notification/unread", JSONObject())

    /** The inbox. Read-only unless you explicitly call markMessageAsRead. */
    fun fetchMessages(): String? =
        postApiWithAutoLogin("message/getMyMessages", JSONObject().put("filterByLabelName", ""))

    /** POST /api/message/markAsRead {"messageId":N} -> {"success":true,...} */
    fun markMessageAsRead(messageId: Long): Boolean {
        val text = postApiWithAutoLogin("message/markAsRead", JSONObject().put("messageId", messageId))
            ?: return false
        return try {
            JSONObject(text).optBoolean("success", false)
        } catch (e: Exception) {
            lastError = "markAsRead: unexpected reply"
            false
        }
    }

    /** One timetable week; [startDate] is that week's Monday as yyyy-MM-dd. A genuinely empty
     *  week (holidays) is rare and still has date keys with empty contents, so requiring at
     *  least one top-level key is a safe way to reject an auth-failure "{}" without false-
     *  positiving on real but lesson-free weeks. */
    fun fetchCalendarWeek(startDate: String): String? =
        postApiWithAutoLogin(
            "calendar/student", JSONObject().put("startDate", startDate),
            isValid = { text ->
                try {
                    JSONObject(text).length() > 0
                } catch (e: Exception) {
                    false
                }
            }
        )

    private fun looksValid(text: String): Boolean {
        val trimmed = text.trim()
        return trimmed.startsWith("[") || trimmed.startsWith("{")
    }
}
