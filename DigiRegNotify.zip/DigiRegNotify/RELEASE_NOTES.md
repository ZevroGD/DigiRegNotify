## What's new

**Changed**
- Timetable tiles are now all the same height per period.
- Lessons with an exam or test get a red stripe on the left.
- The edit history on homework cards only shows what it said before, not the "After" line.
- Tapping the mark chart now morphs the card into the full-screen chart, and back.
- The chart inside a subject's marks now has grade lines with numbers on the left, and each mark's value by its dot. It only covers the range of the marks (7+ to 9- shows 7 to 9).
