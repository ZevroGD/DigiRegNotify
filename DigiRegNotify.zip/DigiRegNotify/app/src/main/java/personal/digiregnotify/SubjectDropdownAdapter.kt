package personal.digiregnotify

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

data class SubjectRowState(
    val subjectId: Int,
    val name: String,
    val average: Float?,
    val color: Int,
    val thickness: Int // 1..5
)

class SubjectDropdownAdapter(
    private var rows: List<SubjectRowState>,
    private val onThicknessChanged: (subjectId: Int, newThickness: Int) -> Unit
) : RecyclerView.Adapter<SubjectDropdownAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val dot: View = view.findViewById(R.id.rowColorDot)
        val name: TextView = view.findViewById(R.id.rowSubjectName)
        val average: TextView = view.findViewById(R.id.rowAverage)
        val thinner: TextView = view.findViewById(R.id.rowThinnerButton)
        val thicker: TextView = view.findViewById(R.id.rowThickerButton)
        val value: TextView = view.findViewById(R.id.rowThicknessValue)
    }

    fun updateRows(newRows: List<SubjectRowState>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_subject_dropdown_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val row = rows[position]
        holder.name.text = row.name
        holder.average.text = row.average?.let { String.format(Locale.getDefault(), "%.2f", it) } ?: "–"
        (holder.dot.background.mutate() as GradientDrawable).setColor(row.color)
        holder.value.text = row.thickness.toString()

        holder.thinner.setOnClickListener {
            if (row.thickness > 1) onThicknessChanged(row.subjectId, row.thickness - 1)
        }
        holder.thicker.setOnClickListener {
            if (row.thickness < 5) onThicknessChanged(row.subjectId, row.thickness + 1)
        }
    }

    override fun getItemCount(): Int = rows.size
}
