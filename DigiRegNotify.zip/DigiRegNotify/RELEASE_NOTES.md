## What's new in 1.1

**New**
- **Attachments ("Anhang")** on homework and messages: descriptions, links and files open right from the item. Homework shows a 📎; messages list them in their popup.
- **History** screen (More menu): the past month of homework, marks and teacher notes, with search.
- **Edit and delete markers** on homework: an ⓘ shows what an edit changed (before and after), and a deleted homework is marked on its due day. Both stay visible after the homework leaves the list.
- **Custom theme** as the last theme choice (pick any two of 56 colours), and a free colour picker for subject colours.
- **Developer menu** (Settings): live status, a log of checks and requests, crash reports, and a shareable report for troubleshooting.
- **New marks notifications**: new marks now notify, using the same feed the website shows.
- **Marks screen** redesigned: tap a subject to see its exact marks; the chart axis only goes as low as needed.
- **Slide-down animations** for popups and dropdown panels, and a tile-style More menu.

**Improved**
- Pull-to-refresh, "Check now" and the background check now run the same check.
- Background checks restart themselves after an app update and whenever you open the app.
- Settings shows when the last check and the last background check ran.
- Homework text can be selected and copied.

**Fixed**
- Settings was missing from the More menu, and its tile was stretched.
- The Chart lines sliders on the Marks screen could crash the app.
- Occasional "Failed to load" on the Homework screen.
- Ticking a homework box no longer counts as an edit.
