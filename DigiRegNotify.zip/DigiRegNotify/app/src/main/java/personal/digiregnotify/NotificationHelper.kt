package personal.digiregnotify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

/** Sender + subject of a new message (either can be blank if we couldn't look it up). */
data class MessagePreview(val from: String, val subject: String)

object NotificationHelper {

    private const val CHANNEL_ID = "digireg_updates"
    private const val CHANNEL_NAME = "Digitales Register updates"

    private const val ID_ITEMS = 1
    private const val ID_ERROR = 2
    private const val ID_MESSAGES = 3
    private const val ID_TIMETABLE = 4

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH
            )
            manager.createNotificationChannel(channel)
        }
    }

    private fun post(context: Context, id: Int, title: String, body: String, icon: Int) {
        ensureChannel(context)

        val openAppIntent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(icon)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(NotificationManager::class.java)
        manager.notify(id, notification)
    }

    fun notifyNewItems(context: Context, items: List<DashboardItem>) {
        if (items.isEmpty()) return
        val title = if (items.size == 1) "New in Digitales Register" else "${items.size} new items"
        val body = items.joinToString(" • ") { describeItem(it) }.take(200)
        post(context, ID_ITEMS, title, body, android.R.drawable.ic_dialog_info)
    }

    fun notifyMessages(context: Context, messages: List<MessagePreview>) {
        if (messages.isEmpty()) return
        val title = if (messages.size == 1) "New message" else "${messages.size} new messages"
        val body = messages.joinToString(" • ") { m ->
            when {
                m.from.isNotBlank() && m.subject.isNotBlank() -> "${m.from}: ${m.subject}"
                m.subject.isNotBlank() -> m.subject
                m.from.isNotBlank() -> "From ${m.from}"
                else -> "Open Digitales Register to read it"
            }
        }.take(200)
        post(context, ID_MESSAGES, title, body, android.R.drawable.ic_dialog_email)
    }

    fun notifyTimetableChanged(context: Context, summary: String) {
        post(context, ID_TIMETABLE, "Timetable changed", summary, android.R.drawable.ic_dialog_info)
    }

    /** "item.title" is the category the school assigned: Hausaufgabe, Test, Schularbeit, Referat... */
    private fun describeItem(item: DashboardItem): String {
        val subject = if (item.label.isNotBlank()) " (${item.label})" else ""
        val due = DueDateFormat.parse(item.deadline)?.let { " — due ${DueDateFormat.dayLabel(it)}" } ?: ""
        return when (item.type) {
            "grade" ->
                "New grade$subject — ${item.subtitle}" + (item.grade?.let { ": $it" } ?: "")
            "gradeGroup" ->
                "New ${item.title.ifBlank { "homework" }}$subject — ${item.subtitle}$due"
            "observation" ->
                "New teacher note$subject"
            else ->
                "${item.title}: ${item.subtitle}"
        }
    }

    fun notifyError(context: Context, message: String) {
        post(context, ID_ERROR, "Register+ check failed", message, android.R.drawable.ic_dialog_alert)
    }
}
