package personal.digiregnotify

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors

/**
 * A menu card that flies in from above the screen, overshoots a little and settles back, and
 * flies out upwards when closed. The animation runs on the card inside a full-screen
 * transparent window, so it doesn't depend on the system's dialog animations (which some
 * phones replace with their own) and the card is never clipped while it moves.
 */
class FlyInDialog(private val activity: Activity, content: View) {

    private val dialog = Dialog(activity, R.style.DigiReg_FlyDialog)
    private val root = FrameLayout(activity)
    private val card = MaterialCardView(activity)
    private val density = activity.resources.displayMetrics.density
    private var closing = false

    init {
        val surface = MaterialColors.getColor(activity, com.google.android.material.R.attr.colorSurface, Color.DKGRAY)
        card.apply {
            radius = 28f * density
            cardElevation = 8f * density
            setCardBackgroundColor(
                MaterialColors.getColor(activity, com.google.android.material.R.attr.colorSurfaceContainerHigh, surface)
            )
            isClickable = true // taps on the card must not count as taps outside it
            addView(content)
            visibility = View.INVISIBLE // shown once measured, so there is no flash in place
        }
        val screenWidth = activity.resources.displayMetrics.widthPixels
        val width = minOf(screenWidth - (48 * density).toInt(), (420 * density).toInt())
        root.addView(card, FrameLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        root.setOnClickListener { dismiss() } // a tap outside the card closes it
    }

    fun show() {
        dialog.setContentView(root)
        dialog.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.55f)
            setWindowAnimations(0)
        }
        dialog.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                dismiss()
                true
            } else {
                false
            }
        }
        dialog.show()

        // Once the card has its size: park it just above the top edge, then let it fly in.
        root.viewTreeObserver.addOnGlobalLayoutListener(object : android.view.ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                if (root.height == 0 || card.height == 0) return
                root.viewTreeObserver.removeOnGlobalLayoutListener(this)
                card.translationY = -offscreenDistance()
                card.visibility = View.VISIBLE
                card.animate()
                    .translationY(0f)
                    .setInterpolator(OvershootInterpolator(1.6f)) // past its spot, then back
                    .setDuration(700)
                    .start()
            }
        })
    }

    /** Flies out upwards, then closes. */
    fun dismiss() {
        if (closing) return
        closing = true
        card.animate()
            .translationY(-offscreenDistance())
            .setInterpolator(AccelerateInterpolator(1.4f))
            .setDuration(240)
            .withEndAction {
                if (!activity.isFinishing && !activity.isDestroyed) {
                    try {
                        dialog.dismiss()
                    } catch (e: Exception) {
                        // already gone
                    }
                }
            }
            .start()
    }

    /** How far up the card must move to be completely above the screen. */
    private fun offscreenDistance(): Float = root.height / 2f + card.height / 2f + 16f * density
}
