## What's new

**Changed**
- A quieter, more minimal interface: the explanatory sentences under settings, on the sign-in screen, in the subject list and above the charts are gone, and the sign-in button is simply "Sign in".
- The search, messages and menu buttons at the top of Home now have the same colour and size (the search icon used to look darker and the envelope brighter).
- The search field has an X button that clears it, puts the cursor back in the field and brings up the keyboard. Opening the search also brings up the keyboard straight away.
- Settings moved from the menu grid to a gear in the menu's top right corner, so the four menu tiles form an even grid.
- Cards now have an outline in your palette's colour (a soft version of the primary colour) instead of a fixed grey-beige one, so the theme shows on every card, including with the Custom theme.
- The colour wheel's triangle now points up (white at the top, black at the bottom left, the pure colour at the bottom right) and stays that way while you change the hue.
- The Custom theme now has 1,728 prepared colours instead of 204, so the colour you get is much closer to the one you picked. Before, muted colours such as greyish blues could turn into plain grey or a much brighter blue.
