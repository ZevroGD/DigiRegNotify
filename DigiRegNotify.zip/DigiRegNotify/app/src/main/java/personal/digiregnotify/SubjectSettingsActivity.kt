package personal.digiregnotify

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class SubjectSettingsActivity : BaseActivity() {

    private lateinit var adapter: SubjectSettingsAdapter
    private lateinit var emptyText: TextView
    private val density by lazy { resources.displayMetrics.density }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subject_settings)

        emptyText = findViewById(R.id.subjectsEmptyText)
        val recyclerView = findViewById<RecyclerView>(R.id.subjectsRecyclerView)

        adapter = SubjectSettingsAdapter(
            emptyList(),
            onRename = { code -> showRenameDialog(code) },
            onRecolor = { code -> showColorPicker(code) }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<ImageButton>(R.id.subjectsBackButton).setOnClickListener { finish() }

        render()
    }

    private fun render() {
        val codes = SubjectRegistry.getAllCodes(this)
        val rows = codes.map { code ->
            SubjectSettingsRow(
                code = code,
                name = SubjectNames.nameFor(this, code),
                color = SubjectColors.colorForCode(this, code)
            )
        }
        adapter.updateRows(rows)
        emptyText.visibility = if (rows.isEmpty()) TextView.VISIBLE else TextView.GONE
    }

    private fun showRenameDialog(code: String) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setText(SubjectNames.nameFor(this@SubjectSettingsActivity, code))
            setSelection(text.length)
            val pad = (20 * density).toInt()
            setPadding(pad, pad / 2, pad, pad / 2)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Rename \"$code\"")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                // An empty name just reverts to showing the raw code.
                SubjectNames.setNameFor(this, code, input.text.toString())
                render()
            }
            .setNeutralButton("Reset") { _, _ ->
                SubjectNames.setNameFor(this, code, "")
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showColorPicker(code: String) {
        // Wrap into rows of 5 so the palette colors fit without overflowing a narrow dialog.
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        container.addView(row)

        lateinit var dialog: androidx.appcompat.app.AlertDialog

        SubjectColors.palette.forEachIndexed { index, color ->
            if (index > 0 && index % 5 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                container.addView(row)
            }
            val swatch = android.widget.FrameLayout(this).apply {
                val size = (40 * density).toInt()
                val margin = (6 * density).toInt()
                layoutParams = LinearLayout.LayoutParams(size, size).apply {
                    setMargins(margin, margin, margin, margin)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(color)
                }
                setOnClickListener {
                    SubjectColors.setColorForCode(this@SubjectSettingsActivity, code, color)
                    render()
                    dialog.dismiss()
                }
            }
            row.addView(swatch)
        }

        // Last "swatch": a rainbow circle that opens a free color picker for any color.
        if (SubjectColors.palette.size % 5 == 0) {
            row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            container.addView(row)
        }
        val customSwatch = android.widget.FrameLayout(this).apply {
            val size = (40 * density).toInt()
            val margin = (6 * density).toInt()
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                setMargins(margin, margin, margin, margin)
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                gradientType = GradientDrawable.SWEEP_GRADIENT
                colors = intArrayOf(
                    0xFFE53935.toInt(), 0xFFFDD835.toInt(), 0xFF43A047.toInt(),
                    0xFF00ACC1.toInt(), 0xFF1E88E5.toInt(), 0xFF8E24AA.toInt(), 0xFFE53935.toInt()
                )
            }
            contentDescription = "Pick any color"
            addView(TextView(this@SubjectSettingsActivity).apply {
                text = "+"
                setTextColor(android.graphics.Color.WHITE)
                textSize = 20f
                gravity = android.view.Gravity.CENTER
                layoutParams = android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT
                )
            })
            setOnClickListener {
                dialog.dismiss()
                ColorPickerDialog.show(
                    this@SubjectSettingsActivity,
                    "Color for \"${SubjectNames.nameFor(this@SubjectSettingsActivity, code)}\"",
                    SubjectColors.colorForCode(this@SubjectSettingsActivity, code)
                ) { picked ->
                    SubjectColors.setColorForCode(this@SubjectSettingsActivity, code, picked)
                    render()
                }
            }
        }
        row.addView(customSwatch)

        val pad = (16 * density).toInt()
        container.setPadding(pad, pad, pad, pad)

        dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Color for \"${SubjectNames.nameFor(this, code)}\"")
            .setView(container)
            .setNeutralButton("Use default") { _, _ ->
                SubjectColors.clearColorForCode(this, code)
                render()
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show()
    }
}
