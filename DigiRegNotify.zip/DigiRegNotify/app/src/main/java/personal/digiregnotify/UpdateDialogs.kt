package personal.digiregnotify

import android.app.Activity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** The "new version" popup (version, release notes, Download) and the download progress. */
object UpdateDialogs {

    fun show(activity: Activity, info: UpdateInfo) {
        if (activity.isFinishing || activity.isDestroyed) return
        SlideDialogBuilder(activity)
            .setTitle("Version ${info.version}")
            .setMessage(info.notes.ifBlank { "A newer version is available." })
            .setPositiveButton("Download") { _, _ -> download(activity, info) }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun download(activity: Activity, info: UpdateInfo) {
        val density = activity.resources.displayMetrics.density
        val bar = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = true // until the first percentage arrives
        }
        val holder = LinearLayout(activity).apply {
            val pad = (24 * density).toInt()
            setPadding(pad, (8 * density).toInt(), pad, 0)
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val dialog = SlideDialogBuilder(activity)
            .setTitle("Downloading ${info.version}")
            .setView(holder)
            .setCancelable(false)
            .create()
        dialog.show()

        CoroutineScope(Dispatchers.IO).launch {
            val file = UpdateChecker.download(activity, info) { percent ->
                activity.runOnUiThread {
                    bar.isIndeterminate = false
                    bar.progress = percent
                }
            }
            withContext(Dispatchers.Main) {
                if (!activity.isFinishing && !activity.isDestroyed) {
                    try {
                        dialog.dismiss()
                    } catch (e: Exception) {
                        // already gone
                    }
                    if (file == null) {
                        Toast.makeText(activity, "Download failed", Toast.LENGTH_LONG).show()
                    } else {
                        UpdateChecker.install(activity, file)
                    }
                }
            }
        }
    }
}
