## What's new

**Fixed**
- Tapping a new-homework notification no longer searches or filters the list. Home opens with everything as usual, scrolled to that homework, and its outline briefly glows.
