## What's new

**Changed**
- When you open a message, its short preview now brightens to the colour of the full text as it slides away, instead of fading out.

**Fixed**
- Marking a new mark as read no longer reports a failure when it actually worked.
