package personal.digiregnotify

import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException

/** Logs every request's method, path, status and duration to [DevLog]. No headers, cookies
 *  or bodies are ever recorded. */
class DevLogInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val start = System.nanoTime()
        val label = "${request.method} ${request.url.encodedPath}"
        try {
            val response = chain.proceed(request)
            val ms = (System.nanoTime() - start) / 1_000_000
            val line = "$label -> ${response.code} (${ms} ms)"
            if (response.isSuccessful) DevLog.i("Net", line) else DevLog.w("Net", line)
            return response
        } catch (e: IOException) {
            val ms = (System.nanoTime() - start) / 1_000_000
            DevLog.w("Net", "$label failed after ${ms} ms: ${e.javaClass.simpleName}: ${e.message}")
            throw e
        }
    }
}
