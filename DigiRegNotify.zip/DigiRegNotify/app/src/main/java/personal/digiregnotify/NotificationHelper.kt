package personal.digiregnotify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

object NotificationHelper {

    private const val CHANNEL_ID = "digireg_updates"
    private const val CHANNEL_NAME = "Digitales Register updates"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH
            )
            manager.createNotificationChannel(channel)
        }
    }

    fun notifyNewItems(context: Context, items: List<DashboardItem>) {
        if (items.isEmpty()) return
        ensureChannel(context)

        val openAppIntent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (items.size == 1) "New in Digitales Register" else "${items.size} new items"
        val body = items.joinToString(" • ") { describeItem(it) }.take(200)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(NotificationManager::class.java)
        manager.notify(1, notification)
    }

    private fun describeItem(item: DashboardItem): String {
        return when {
            item.type == "grade" && item.grade != null ->
                "New grade — ${item.subtitle}: ${item.grade}"
            item.type == "gradeGroup" && item.checkable ->
                "New homework — ${item.subtitle}" + (item.deadline?.let { " (due $it)" } ?: "")
            item.type == "gradeGroup" ->
                "New — ${item.subtitle}" + (item.deadline?.let { " ($it)" } ?: "")
            else -> "${item.title}: ${item.subtitle}"
        }
    }

    fun notifyError(context: Context, message: String) {
        ensureChannel(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("DigiReg check failed")
            .setContentText(message)
            .setAutoCancel(true)
            .build()
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.notify(2, notification)
    }
}
