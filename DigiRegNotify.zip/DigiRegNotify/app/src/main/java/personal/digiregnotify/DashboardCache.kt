package personal.digiregnotify

import android.content.Context
import java.io.File

/**
 * The last dashboard the school sent, kept on the phone so the homework list can still be shown
 * when the school's server can't be reached. Written after every successful check, removed on
 * sign-out. The file's modified time is when it was saved.
 */
object DashboardCache {

    private const val FILE = "dashboard_cache.json"

    class Saved(val json: String, val savedAt: Long)

    fun save(context: Context, json: String) {
        try {
            val target = File(context.filesDir, FILE)
            val temp = File(context.filesDir, "$FILE.tmp")
            temp.writeText(json)
            if (!temp.renameTo(target)) { // fall back to a plain copy if rename can't replace
                target.writeText(json)
                temp.delete()
            }
        } catch (e: Exception) {
            DevLog.w("Cache", "could not save the dashboard: ${e.javaClass.simpleName}")
        }
    }

    fun load(context: Context): Saved? {
        return try {
            val file = File(context.filesDir, FILE)
            if (!file.exists()) null else Saved(file.readText(), file.lastModified())
        } catch (e: Exception) {
            null
        }
    }

    fun clear(context: Context) {
        try {
            File(context.filesDir, FILE).delete()
        } catch (e: Exception) {
            // nothing to do
        }
    }
}
