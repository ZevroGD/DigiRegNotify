package personal.digiregnotify

import android.content.Context

/** Lets a subject's short code (e.g. "H") be shown as something readable (e.g. "History")
 *  instead, wherever there's room for it. The code itself stays the real key everywhere
 *  else (coloring, grid cells) — this is purely a display-layer override. */
object SubjectNames {

    private const val PREFS = "digireg_subject_names"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** The custom name if one's been set, otherwise the raw code itself. */
    fun nameFor(context: Context, code: String): String =
        prefs(context).getString("subject_name_$code", null)?.takeIf { it.isNotBlank() } ?: code

    fun hasCustomName(context: Context, code: String): Boolean =
        prefs(context).contains("subject_name_$code")

    fun setNameFor(context: Context, code: String, name: String) {
        if (name.isBlank()) {
            prefs(context).edit().remove("subject_name_$code").apply()
        } else {
            prefs(context).edit().putString("subject_name_$code", name.trim()).apply()
        }
    }
}
