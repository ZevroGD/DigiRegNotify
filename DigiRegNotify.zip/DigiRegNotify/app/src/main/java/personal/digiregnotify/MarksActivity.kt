package personal.digiregnotify

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MarksActivity : AppCompatActivity() {

    private lateinit var api: RegisterApi
    private lateinit var adapter: MarksAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_marks)

        api = RegisterApi(this)
        emptyText = findViewById(R.id.marksEmptyText)
        swipeRefresh = findViewById(R.id.marksSwipeRefresh)

        val recyclerView = findViewById<RecyclerView>(R.id.marksRecyclerView)
        adapter = MarksAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        swipeRefresh.setOnRefreshListener { loadMarks() }
        loadMarks()
    }

    private fun loadMarks() {
        if (!api.hasCredentials()) {
            emptyText.text = "Sign in from the main screen first"
            emptyText.visibility = TextView.VISIBLE
            swipeRefresh.isRefreshing = false
            return
        }

        swipeRefresh.isRefreshing = true
        CoroutineScope(Dispatchers.IO).launch {
            val dashboardJson = api.fetchDashboardWithAutoLogin()
            withContext(Dispatchers.Main) {
                swipeRefresh.isRefreshing = false
                if (dashboardJson == null) {
                    emptyText.text = "Could not load marks — check your connection or login"
                    emptyText.visibility = TextView.VISIBLE
                    Toast.makeText(this@MarksActivity, "Failed to load", Toast.LENGTH_SHORT).show()
                    return@withContext
                }

                val differ = DashboardDiffer(this@MarksActivity)
                val allItems = differ.parseItems(dashboardJson)

                val bySubject = allItems
                    .filter { it.type == "grade" && it.grade != null }
                    .groupBy { it.subtitle.ifBlank { it.title } }
                    .mapNotNull { (subject, items) ->
                        val values = items.mapNotNull { parseGrade(it.grade) }
                        if (values.isEmpty()) null else SubjectMarks(subject, values)
                    }
                    .sortedBy { it.subject }

                adapter.updateSubjects(bySubject)
                emptyText.visibility = if (bySubject.isEmpty()) TextView.VISIBLE else TextView.GONE
                emptyText.text = "No grades found yet"
            }
        }
    }

    /** Handles both "8.75" and German-style "8,75" formats. */
    private fun parseGrade(raw: String?): Float? {
        if (raw.isNullOrBlank()) return null
        return raw.replace(",", ".").toFloatOrNull()
    }
}
