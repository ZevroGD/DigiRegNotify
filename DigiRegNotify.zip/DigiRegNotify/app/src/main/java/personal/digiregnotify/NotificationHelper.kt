package personal.digiregnotify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

/** Sender + subject of a new message. [id] enables deep-linking to it; -1 if unknown. */
data class MessagePreview(val id: Long, val from: String, val subject: String)

object NotificationHelper {

    private const val CHANNEL_ID = "digireg_updates"
    private const val CHANNEL_NAME = "Digitales Register updates"

    private const val ID_HOMEWORK = 1
    private const val ID_ERROR = 2
    private const val ID_MESSAGES = 3
    private const val ID_TIMETABLE = 4
    private const val ID_GRADES = 5

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH
            )
            manager.createNotificationChannel(channel)
        }
    }

    private fun post(context: Context, id: Int, title: String, body: String, icon: Int, target: Intent) {
        ensureChannel(context)

        val pendingIntent = PendingIntent.getActivity(
            context, id, target, // requestCode = id, so each kind gets its own PendingIntent
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(icon)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(NotificationManager::class.java)
        manager.notify(id, notification)
    }

    /** New homework or teacher notes. Deep-links to that exact item on Home when there's just one. */
    fun notifyNewHomework(context: Context, items: List<DashboardItem>) {
        if (items.isEmpty()) return
        val title = if (items.size == 1) "New in Digitales Register" else "${items.size} new items"
        val body = items.joinToString(" • ") { describeItem(it) }.take(200)

        val target = Intent(context, HomeworkActivity::class.java)
        if (items.size == 1) {
            val item = items.first()
            target.putExtra(HomeworkActivity.EXTRA_CATEGORY, item.title)
            target.putExtra(HomeworkActivity.EXTRA_SEARCH, item.subtitle)
        }
        post(context, ID_HOMEWORK, title, body, android.R.drawable.ic_dialog_info, target)
    }

    /** New grades. There's no reliable subject id on dashboard items to deep-link a specific
     *  card, so this just opens Marks — the grade will be visible on its subject's card there. */
    fun notifyNewGrades(context: Context, items: List<DashboardItem>) {
        if (items.isEmpty()) return
        val title = if (items.size == 1) "New grade" else "${items.size} new grades"
        val body = items.joinToString(" • ") { describeItem(it) }.take(200)
        post(context, ID_GRADES, title, body, android.R.drawable.ic_dialog_info,
            Intent(context, MarksActivity::class.java))
    }

    /** New marks as announced by the site's own unread-notification list. */
    fun notifyNewGradeTexts(context: Context, texts: List<String>) {
        if (texts.isEmpty()) return
        val title = if (texts.size == 1) "New grade" else "${texts.size} new grades"
        post(context, ID_GRADES, title, texts.joinToString(" • ").take(200),
            android.R.drawable.ic_dialog_info, Intent(context, MarksActivity::class.java))
    }

    fun notifyMessages(context: Context, messages: List<MessagePreview>) {
        if (messages.isEmpty()) return
        val title = if (messages.size == 1) "New message" else "${messages.size} new messages"
        val body = messages.joinToString(" • ") { m ->
            when {
                m.from.isNotBlank() && m.subject.isNotBlank() -> "${m.from}: ${m.subject}"
                m.subject.isNotBlank() -> m.subject
                m.from.isNotBlank() -> "From ${m.from}"
                else -> "Open Digitales Register to read it"
            }
        }.take(200)

        val target = Intent(context, MessagesActivity::class.java)
        if (messages.size == 1 && messages.first().id > 0) {
            target.putExtra(MessagesActivity.EXTRA_MESSAGE_ID, messages.first().id)
        }
        post(context, ID_MESSAGES, title, body, android.R.drawable.ic_dialog_email, target)
    }

    fun notifyTimetableChanged(context: Context, summary: String) {
        post(context, ID_TIMETABLE, "Timetable changed", summary, android.R.drawable.ic_dialog_info,
            Intent(context, TimetableActivity::class.java))
    }

    /** "item.title" is the category the school assigned: Hausaufgabe, Test, Schularbeit, Referat... */
    private fun describeItem(item: DashboardItem): String {
        val subject = if (item.label.isNotBlank()) " (${item.label})" else ""
        val due = DueDateFormat.parse(item.deadline)?.let { " — due ${DueDateFormat.dayLabel(it)}" } ?: ""
        return when (item.type) {
            "grade" ->
                "New grade$subject — ${item.subtitle}" + (item.grade?.let { ": $it" } ?: "")
            "gradeGroup" ->
                "New ${item.title.ifBlank { "homework" }}$subject — ${item.subtitle}$due"
            "observation" ->
                "New teacher note$subject"
            else ->
                "${item.title}: ${item.subtitle}"
        }
    }

    fun notifyError(context: Context, message: String) {
        post(context, ID_ERROR, "Register+ check failed", message, android.R.drawable.ic_dialog_alert,
            Intent(context, MainActivity::class.java))
    }
}
