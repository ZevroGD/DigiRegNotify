package personal.digiregnotify

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

data class UpdateInfo(
    val version: String,    // e.g. "1.1.14"
    val notes: String,
    val assetId: Long,
    val assetName: String
)

sealed class UpdateResult {
    object NoToken : UpdateResult()
    object NoConnection : UpdateResult()
    data class UpToDate(val version: String) : UpdateResult()
    data class Available(val info: UpdateInfo) : UpdateResult()
    data class Failure(val message: String) : UpdateResult()
}

/**
 * Looks for a newer release of this app on GitHub and installs it. The repository is private, so
 * it needs a read-only access token, which is kept encrypted on the phone (like the login).
 * Updates install over the old app because every build is signed with the same key.
 */
object UpdateChecker {

    const val DEFAULT_REPO = "ZevroGD/DigiRegNotify"
    private const val AUTO_CHECK_EVERY_MS = 11L * 60 * 60 * 1000 // about twice a day
    private const val POPUP_EVERY_MS = 12L * 60 * 60 * 1000       // the in-app popup, at most twice a day

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(DevLogInterceptor()) // logs path and status only, never the token
        .build()

    private fun state(context: Context) =
        context.getSharedPreferences("digireg_update_state", Context.MODE_PRIVATE)

    private fun secret(context: Context) = EncryptedSharedPreferences.create(
        context.applicationContext, "digireg_update_secret",
        MasterKey.Builder(context.applicationContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getRepo(context: Context): String = state(context).getString("repo", DEFAULT_REPO) ?: DEFAULT_REPO

    fun getToken(context: Context): String? = try {
        secret(context).getString("token", null)?.takeIf { it.isNotBlank() }
    } catch (e: Exception) {
        null
    }

    fun hasToken(context: Context) = getToken(context) != null

    /** [token] null keeps the saved one. */
    fun saveAccess(context: Context, repo: String, token: String?) {
        state(context).edit().putString("repo", repo.trim()).apply()
        if (!token.isNullOrBlank()) secret(context).edit().putString("token", token.trim()).apply()
    }

    fun clearToken(context: Context) {
        try {
            secret(context).edit().remove("token").apply()
        } catch (e: Exception) {
            // nothing to clear
        }
    }

    fun isAutoCheckEnabled(context: Context) = state(context).getBoolean("auto", false)
    fun setAutoCheck(context: Context, on: Boolean) = state(context).edit().putBoolean("auto", on).apply()

    fun currentVersion(context: Context): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0"
    } catch (e: Exception) {
        "0"
    }

    /** True if [remote] (like "v1.1.14") is a higher version than [local] (like "1.1.13"). */
    fun isNewer(remote: String, local: String): Boolean {
        fun parts(v: String) = v.trim().trimStart('v', 'V').split('.')
            .map { it.takeWhile { c -> c.isDigit() }.toIntOrNull() ?: 0 }
        val a = parts(remote)
        val b = parts(local)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    private fun apiRequest(context: Context, url: String, accept: String): Request? {
        val token = getToken(context) ?: return null
        return Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .header("Accept", accept)
            .header("X-GitHub-Api-Version", "2022-11-28")
            .build()
    }

    /** Asks GitHub for the latest release. Blocking: call it off the main thread. */
    fun check(context: Context): UpdateResult {
        val request = apiRequest(
            context, "https://api.github.com/repos/${getRepo(context)}/releases/latest",
            "application/vnd.github+json"
        ) ?: return UpdateResult.NoToken
        return try {
            client.newCall(request).execute().use { response ->
                when {
                    response.code == 401 || response.code == 403 ->
                        UpdateResult.Failure("GitHub rejected the token (HTTP ${response.code})")
                    response.code == 404 ->
                        UpdateResult.Failure("No release found. Check the repository name and that the token can read it.")
                    !response.isSuccessful -> UpdateResult.Failure("GitHub answered HTTP ${response.code}")
                    else -> parse(context, response.body?.string().orEmpty())
                }
            }
        } catch (e: IOException) {
            DevLog.w("Update", "check failed", e)
            if (NetworkUtil.isConnected(context)) UpdateResult.Failure(e.javaClass.simpleName) else UpdateResult.NoConnection
        } catch (e: Exception) {
            DevLog.w("Update", "check failed", e)
            UpdateResult.Failure(e.javaClass.simpleName)
        }
    }

    private fun parse(context: Context, body: String): UpdateResult {
        val json = JSONObject(body)
        val version = json.optString("tag_name").trimStart('v', 'V')
        if (version.isBlank()) return UpdateResult.Failure("The release has no version")
        val current = currentVersion(context)
        if (!isNewer(version, current)) {
            clearPending(context)
            return UpdateResult.UpToDate(current)
        }

        val assets = json.optJSONArray("assets")
        var assetId = 0L
        var assetName = ""
        if (assets != null) {
            for (i in 0 until assets.length()) {
                val asset = assets.optJSONObject(i) ?: continue
                if (asset.optString("name").endsWith(".apk", ignoreCase = true)) {
                    assetId = asset.optLong("id")
                    assetName = asset.optString("name")
                    break
                }
            }
        }
        if (assetId == 0L) return UpdateResult.Failure("The release $version has no APK attached")
        val info = UpdateInfo(version, plainNotes(json.optString("body")), assetId, assetName)
        savePending(context, info)
        return UpdateResult.Available(info)
    }

    // ---- the update found by the latest check, so the app can offer it when it is opened ----

    private fun savePending(context: Context, info: UpdateInfo) {
        val json = JSONObject().put("version", info.version).put("notes", info.notes)
            .put("assetId", info.assetId).put("assetName", info.assetName)
        state(context).edit().putString("pending", json.toString()).apply()
    }

    private fun clearPending(context: Context) {
        state(context).edit().remove("pending").apply()
    }

    /** The update found earlier, if it is still newer than the installed app. */
    fun getPending(context: Context): UpdateInfo? {
        val raw = state(context).getString("pending", null) ?: return null
        return try {
            val o = JSONObject(raw)
            val info = UpdateInfo(o.getString("version"), o.optString("notes"), o.getLong("assetId"), o.optString("assetName"))
            if (isNewer(info.version, currentVersion(context))) info else {
                clearPending(context)
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * What the in-app popup should show now: the pending update, but not more than about twice a
     * day (opening the app several times shouldn't nag). [force] ignores that, for a tap on the
     * notification. Showing it counts as shown.
     */
    fun takePendingForPopup(context: Context, force: Boolean): UpdateInfo? {
        val info = getPending(context) ?: return null
        val s = state(context)
        val now = System.currentTimeMillis()
        if (!force && now < s.getLong("popup_after", 0L)) return null
        s.edit().putLong("popup_after", now + POPUP_EVERY_MS).apply()
        return info
    }

    // ---- which app does the installing (chosen in the Developer menu) ----

    /** Package of the chosen installer app, or null for the system installer. */
    fun getInstallerPackage(context: Context): String? = state(context).getString("installer", null)

    fun setInstallerPackage(context: Context, packageName: String?) {
        state(context).edit().apply {
            if (packageName == null) remove("installer") else putString("installer", packageName)
        }.apply()
    }

    private const val APK_MIME = "application/vnd.android.package-archive"

    private fun apkViewIntent(): Intent = Intent(Intent.ACTION_VIEW)

    /** What an installer app's filter looks for: opening an APK through a content address. */
    private fun apkQueryIntent(): Intent =
        Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse("content://installer.query/update.apk"), APK_MIME)

    /** Apps that offer to open an APK (label, package), without Register+ itself. */
    fun listInstallers(context: Context): List<Pair<String, String>> {
        val pm = context.packageManager
        return pm.queryIntentActivities(apkQueryIntent(), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != context.packageName }
            .distinctBy { it.first }
            .map { it.second to it.first }
            .sortedBy { it.first.lowercase() }
    }

    fun installerLabel(context: Context): String {
        val pkg = getInstallerPackage(context) ?: return "System installer"
        return try {
            val pm = context.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            "System installer" // the chosen app was uninstalled
        }
    }

    /** Release notes arrive as Markdown; show them as plain lines. */
    private fun plainNotes(markdown: String): String =
        markdown.replace("\r", "").lines().joinToString("\n") { line ->
            line.trimStart('#', ' ').replace("**", "").replace("*", "").replace(Regex("^- "), "• ")
        }.replace(Regex("\n{3,}"), "\n\n").trim()

    /** Downloads the APK of [info] into the cache. Blocking. Returns null on failure. */
    fun download(context: Context, info: UpdateInfo, onProgress: ((Int) -> Unit)? = null): File? {
        val request = apiRequest(
            context,
            "https://api.github.com/repos/${getRepo(context)}/releases/assets/${info.assetId}",
            "application/octet-stream"
        ) ?: return null
        val dir = File(context.cacheDir, "updates").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() } // only the newest download is kept
        val target = File(dir, info.assetName.ifBlank { "update.apk" })
        return try {
            // GitHub redirects the download to its storage; OkHttp drops the token on that hop.
            client.newCall(request).execute().use { response ->
                val body = response.body
                if (!response.isSuccessful || body == null) {
                    DevLog.w("Update", "download failed: HTTP ${response.code}")
                    null
                } else {
                    val total = body.contentLength()
                    var done = 0L
                    var lastPercent = -1
                    body.byteStream().use { input ->
                        target.outputStream().use { output ->
                            val buffer = ByteArray(32 * 1024)
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                output.write(buffer, 0, n)
                                done += n
                                if (total > 0 && onProgress != null) {
                                    val percent = (done * 100 / total).toInt()
                                    if (percent != lastPercent) {
                                        lastPercent = percent
                                        onProgress(percent)
                                    }
                                }
                            }
                        }
                    }
                    target
                }
            }
        } catch (e: Exception) {
            DevLog.w("Update", "download failed", e)
            null
        }
    }

    /**
     * Hands the APK to the installer chosen in the Developer menu; with none chosen (or if it is
     * gone) to the system installer, which first asks once for "install unknown apps".
     */
    fun install(activity: Activity, apk: File) {
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", apk)
        val intent = apkViewIntent().apply {
            setDataAndType(uri, APK_MIME)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val chosen = getInstallerPackage(activity)
        if (chosen != null) {
            try {
                activity.startActivity(Intent(intent).setPackage(chosen))
                DevLog.i("Update", "installing with $chosen")
                return
            } catch (e: ActivityNotFoundException) {
                DevLog.w("Update", "installer $chosen can't open the APK, using the system installer")
            }
        }

        if (!activity.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(activity, "Allow installing from Register+, then download again", Toast.LENGTH_LONG).show()
            activity.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
            )
            return
        }
        try {
            activity.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(activity, "Couldn't open the installer", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Called after a background check (and when the app is opened): about twice a day, and only when switched on, it
     * looks for a new release and posts one notification per new version ([notify]). It never installs.
     */
    fun autoCheck(context: Context, notify: Boolean = true) {
        if (!isAutoCheckEnabled(context) || !hasToken(context)) return
        val s = state(context)
        val now = System.currentTimeMillis()
        if (now - s.getLong("last_auto", 0L) < AUTO_CHECK_EVERY_MS) return
        s.edit().putLong("last_auto", now).apply()

        val result = check(context)
        DevLog.i("Update", "auto check: " + when (result) {
            is UpdateResult.Available -> "update ${result.info.version}"
            is UpdateResult.UpToDate -> "up to date"
            is UpdateResult.Failure -> "failed (${result.message})"
            else -> "skipped"
        })
        if (notify && result is UpdateResult.Available && s.getString("last_notified", "") != result.info.version) {
            s.edit().putString("last_notified", result.info.version).apply()
            NotificationHelper.notifyUpdate(context, result.info.version)
        }
    }
}
