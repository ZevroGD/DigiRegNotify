package personal.digiregnotify

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.slider.Slider

class SettingsActivity : AppCompatActivity() {

    private lateinit var api: RegisterApi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        api = RegisterApi(this)

        val slider = findViewById<Slider>(R.id.intervalSlider)
        val valueText = findViewById<TextView>(R.id.intervalValueText)

        val currentHours = AlarmScheduler.getIntervalHours(this)
        slider.value = currentHours.toFloat()
        valueText.text = describeInterval(currentHours)

        slider.addOnChangeListener { _, value, fromUser ->
            val hours = value.toInt()
            valueText.text = describeInterval(hours)
            if (fromUser) {
                AlarmScheduler.setIntervalHours(this, hours)
                if (api.hasCredentials()) {
                    // Re-apply immediately so the new interval takes effect
                    // on the next scheduled check, not just after the next fire.
                    AlarmScheduler.scheduleRepeating(this)
                }
            }
        }

        findViewById<MaterialButton>(R.id.openNotificationSettingsButton).setOnClickListener {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(android.net.Uri.parse("package:$packageName"))
            }
            startActivity(intent)
        }

        findViewById<MaterialButton>(R.id.signOutButton).setOnClickListener {
            AlarmScheduler.cancel(this)
            api.clearCredentials()
            Toast.makeText(this, "Stopped and signed out", Toast.LENGTH_SHORT).show()
            finish()
        }

        findViewById<ImageButton>(R.id.backButton).setOnClickListener { finish() }
    }

    private fun describeInterval(hours: Int): String =
        if (hours == 1) "Every hour" else "Every $hours hours"
}
